/**
 * 插件接线单测：用假 Cordis 上下文驱动真实的 `apply()`，验证
 * 「DSH 事件 → 状态机 → 相位」这条链，以及配置规整、清理、诊断日志。
 *
 *   node test/plugin-wiring.test.mjs
 *
 * 不需要 DSH、不需要 koffi、不碰真实任务栏（backend 固定为 none）。
 */

import assert from 'node:assert/strict'
import { existsSync, readFileSync, rmSync } from 'node:fs'
import { tmpdir } from 'node:os'
import path from 'node:path'

import {
  apply,
  name,
  FAILURE_NOTICE_TEXT,
  WECHAT_STATE_ROUTE,
  WECHAT_REFRESH_PARAM,
  WECHAT_LOGIN_ROUTE,
  WECHAT_VERIFY_ROUTE,
  WECHAT_CANCEL_ROUTE,
  WECHAT_DISCONNECT_ROUTE,
  WECHAT_ACTION_ROUTES,
  setWechatNotifierFactory,
} from '../lib/index.js'
import { setToastTransport } from '../lib/notify.js'
import { setActivityProbe } from '../lib/activity.js'
import { PHASE } from '../lib/status-map.js'

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms))

let passed = 0
const check = async (label, fn) => {
  await fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

// ── 假通知发送器（`setToastTransport`）必须在**第一次 apply() 之前**装上 ─────
//
// 它换掉的是 `lib/notify.js` 里的**模块级**实现：装上之前所有通知都走真实实现
// （spawn 一个 PowerShell 弹真 toast）。下面「主场景」里就有一次真故障（④），
// 所以这里必须早装一步 —— 否则**每跑一次这个测试文件，用户的 Windows 通知中心
// 就会多一条「故障，请检查」**（实测：把这一块放在主场景之后，一次运行会真的弹 1 条）。
const toastCalls = []
setToastTransport((options) => {
  toastCalls.push(options)
  return true
})

/** 一个刚好够用的假 Cordis ctx。 */
function createFakeCtx(services = {}) {
  const handlers = new Map()
  const effects = []
  const logs = []
  return {
    logs,
    logger: {
      info: (m) => logs.push(['info', m]),
      warn: (m) => logs.push(['warn', m]),
      error: (m) => logs.push(['error', m]),
    },
    get: (key) => services[key],
    on(event, fn) {
      if (!handlers.has(event)) handlers.set(event, [])
      handlers.get(event).push(fn)
      return () => {
        const list = handlers.get(event) ?? []
        const index = list.indexOf(fn)
        if (index >= 0) list.splice(index, 1)
      }
    },
    effect(fn) {
      const disposer = fn()
      effects.push(disposer)
      return () => disposer?.()
    },
    /** 逐个调用该事件的监听器（waterfall 需要把 next 当最后一个参数传进来）。 */
    async emit(event, ...args) {
      let result
      for (const fn of [...(handlers.get(event) ?? [])]) result = await fn(...args)
      return result
    },
    subscribeCount(event) {
      return (handlers.get(event) ?? []).length
    },
    disposeAll() {
      for (const disposer of effects) {
        try {
          disposer?.()
        } catch (error) {
          console.log('dispose error:', error)
        }
      }
    },
  }
}

/** 从日志里抽出相位序列（状态机会打 "相位 → X"）。 */
const phases = (ctx) =>
  ctx.logs.filter(([, m]) => m.includes('相位 → ')).map(([, m]) => m.split('相位 → ')[1].trim())

console.log('plugin wiring')

await check('导出 name / apply', () => {
  assert.equal(name, 'taskbar-progress')
  assert.equal(typeof apply, 'function')
})

// ── 主场景 ────────────────────────────────────────────────────────────────
const services = {
  agents: {
    list: () => [
      { id: 'top', status: 'idle' },
      { id: 'sub', status: 'idle' },
    ],
    roots: () => [{ id: 'top', status: 'idle' }],
  },
}
const ctx = createFakeCtx(services)
apply(ctx, { backend: 'none', pollMs: 100_000, reassertMs: 0 })
await sleep(30)

await check('订阅了全部预期事件（含等待路径的三条）', () => {
  for (const event of [
    'agent/status',
    'api-session/status',
    'api-session/error',
    'agent/error',
    'api-session/removed',
    'agent/disposed',
    'user-questions/request', // 路径一：ask()
    'tools/execute', // 路径二：askTimed()（交互式提问实际走的）
    'approval/request', // 路径三：审批
  ]) {
    assert.ok(ctx.subscribeCount(event) > 0, `缺少 ${event} 订阅`)
  }
})

await check('启动即对齐为 idle', () => {
  assert.equal(phases(ctx).at(-1), 'idle')
})

await check('agent/status running → working', async () => {
  await ctx.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  assert.equal(phases(ctx).at(-1), 'working')
})

await check('子代理事件被 roots 过滤器挡住', async () => {
  const before = phases(ctx).length
  await ctx.emit('agent/status', { agent: { id: 'sub' }, status: 'running' })
  await ctx.emit('api-session/error', 'sub', 'child blew up')
  assert.equal(phases(ctx).length, before, '子代理不该产生相位变化')
})

await check('tools/execute：ask_user_question 挂起期间 → waiting，结束后回落', async () => {
  let release
  const gate = new Promise((resolve) => {
    release = resolve
  })
  let nextCalled = false
  const exec = { name: 'ask_user_question', callId: 'c1', agent: { id: 'top' } }
  const pending = ctx.emit('tools/execute', exec, async () => {
    nextCalled = true
    await gate
    return { isError: false, value: { answers: [] } }
  })
  await sleep(20)
  assert.equal(phases(ctx).at(-1), 'waiting', '提问挂起时应进入 waiting（黄色）')
  release()
  const result = await pending
  assert.equal(nextCalled, true, '必须原样调用 next()（观察性透传）')
  assert.deepEqual(result, { isError: false, value: { answers: [] } }, '必须原样返回下游结果')
  assert.equal(phases(ctx).at(-1), 'working', '回答后应回到 working')
})

await check('tools/execute：非等待类工具不产生 waiting', async () => {
  const before = phases(ctx).length
  await ctx.emit('tools/execute', { name: 'read', callId: 'c2', agent: { id: 'top' } }, async () => ({ isError: false }))
  assert.equal(phases(ctx).length, before, '普通工具不该触发 waiting')
})

await check('user-questions/request（ask 路径）→ waiting，且透传答案', async () => {
  const answer = { answers: [{ id: 'q1', selected: ['yes'] }] }
  const returned = await ctx.emit(
    'user-questions/request',
    { agent: { id: 'top' }, questions: [] },
    async () => answer,
  )
  assert.deepEqual(returned, answer, '必须原样返回下游答案')
  assert.ok(phases(ctx).includes('waiting'))
  assert.equal(phases(ctx).at(-1), 'working')
})

await check('approval/request → waiting，且透传结果', async () => {
  const outcome = { kind: 'allow' }
  const returned = await ctx.emit('approval/request', { agent: { id: 'top' } }, async () => outcome)
  assert.deepEqual(returned, outcome, '必须原样返回审批结果')
  assert.ok(phases(ctx).includes('waiting'))
  assert.equal(phases(ctx).at(-1), 'working')
})

await check('api-session/error → error（红色），粘性错误不重复触发', async () => {
  await ctx.emit('api-session/error', 'top', 'boom')
  assert.equal(phases(ctx).at(-1), 'error')
  const before = phases(ctx).length
  await ctx.emit('api-session/error', 'top', 'boom')
  await ctx.emit('api-session/error', 'top', 'boom')
  assert.equal(phases(ctx).length, before, '内容没变不该重复触发')
})

await check('重新开跑清掉故障 → working', async () => {
  await ctx.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  assert.equal(phases(ctx).at(-1), 'working')
})

await check('idle → done（完成保持态）', async () => {
  await ctx.emit('agent/status', { agent: { id: 'top' }, status: 'idle' })
  assert.equal(phases(ctx).at(-1), 'done')
})

await check('api-session/removed 清状态，不算完成', async () => {
  await ctx.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  assert.equal(phases(ctx).at(-1), 'working')
  await ctx.emit('api-session/removed', 'top')
  assert.equal(phases(ctx).at(-1), 'idle')
})

await check('插件停用时的清理不会抛错', () => {
  ctx.disposeAll()
})

// ── 配置规整 ──────────────────────────────────────────────────────────────
await check('缺省配置全部走默认值', async () => {
  const c = createFakeCtx()
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0 })
  await sleep(20)
  assert.deepEqual(phases(c), ['idle'])
  c.disposeAll()
})

await check('非法配置被拦下并回落到默认值', async () => {
  const c = createFakeCtx()
  apply(c, {
    backend: 'nonsense',
    scope: 'nonsense',
    completionHoldMs: 'not-a-number',
    flashOnWaiting: 'yes',
    waitingTools: 'ask_user_question',
    unknownKey: 1,
    pollMs: 100_000,
    reassertMs: 0,
  })
  await sleep(20)
  const warnings = c.logs.filter(([level]) => level === 'warn').map(([, m]) => m)
  assert.ok(warnings.some((m) => m.includes("backend") && m.includes('只能是')), `backend 应被拒绝：${warnings}`)
  assert.ok(warnings.some((m) => m.includes("scope")), 'scope 应被拒绝')
  assert.ok(warnings.some((m) => m.includes("completionHoldMs")), 'completionHoldMs 应被拒绝')
  assert.ok(warnings.some((m) => m.includes("flashOnWaiting")), 'flashOnWaiting 应被拒绝')
  assert.ok(warnings.some((m) => m.includes("waitingTools")), 'waitingTools 应被拒绝（需要字符串数组）')
  assert.ok(warnings.some((m) => m.includes("unknownKey")), '未知键应被提示')
  // 关键：坏值没有把插件打挂，仍然正常对齐到 idle
  assert.equal(phases(c).at(-1), 'idle')
  c.disposeAll()
})

await check('enabled=false 直接不接管', async () => {
  const c = createFakeCtx()
  apply(c, { enabled: false })
  await sleep(20)
  assert.equal(phases(c).length, 0, '禁用时不该产生任何相位')
  assert.equal(c.subscribeCount('agent/status'), 0, '禁用时不该订阅事件')
  c.disposeAll()
})

// ── 诊断日志 ──────────────────────────────────────────────────────────────
await check('debugLogFile 打开时会写 JSONL 诊断日志', async () => {
  const file = path.join(tmpdir(), `dsh-taskbar-debug-${process.pid}.jsonl`)
  rmSync(file, { force: true })
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, debugLogFile: file })
  await sleep(30)
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  await sleep(10)
  assert.ok(existsSync(file), '诊断文件应被创建')
  const lines = readFileSync(file, 'utf8').trim().split('\n').map((l) => JSON.parse(l))
  assert.ok(lines.some((l) => l.event === 'apply'), '应记录 apply')
  assert.ok(lines.some((l) => l.event === 'backend-ready'), '应记录 backend-ready')
  assert.ok(lines.some((l) => l.event === 'ev agent/status'), '应记录事件')
  c.disposeAll()
  rmSync(file, { force: true })
})

// ── 「等待用户」超时系统通知 ────────────────────────────────────────────────
// 假发送器（`toastCalls` / `setToastTransport`）已经在文件开头装好了 ——
// 必须在**第一次 apply() 之前**装，否则主场景里的那条真故障会弹真通知。

/** 进入等待 → 返回一个 release 函数，调用后结束等待。 */
async function enterWaiting(c) {
  let release
  const gate = new Promise((resolve) => {
    release = resolve
  })
  const pending = c.emit(
    'tools/execute',
    { name: 'ask_user_question', callId: 'c-wait', agent: { id: 'top' } },
    async () => {
      await gate
      return { isError: false }
    },
  )
  return { release, pending }
}

await check('等待超过阈值 → 弹一次系统通知（标题/正文/来源都对）', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, {
    backend: 'none',
    pollMs: 100_000,
    reassertMs: 0,
    waitingNotifyDelayMs: 80,
    notifyPersona: '大肥鱼',
    waitingNotifyText: '老大请您做出决定',
  })
  await sleep(20)
  const { release, pending } = await enterWaiting(c)
  await sleep(220)
  assert.equal(toastCalls.length, 1, `应恰好弹一次，实际 ${toastCalls.length}`)
  assert.equal(toastCalls[0].title, '大肥鱼')
  assert.equal(toastCalls[0].text, '老大请您做出决定')
  assert.equal(toastCalls[0].aumid, 'com.deepseek.dsh')
  // 仍然在等待 → 不应重复弹
  await sleep(200)
  assert.equal(toastCalls.length, 1, '同一段等待只提醒一次')
  release()
  await pending
  await sleep(20)
  assert.equal(toastCalls.length, 1, '离开等待后不该再弹')
  c.disposeAll()
})

await check('阈值内作答 → 完全不提醒', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingNotifyDelayMs: 400 })
  await sleep(20)
  const { release, pending } = await enterWaiting(c)
  await sleep(60)
  release()
  await pending
  await sleep(500)
  assert.equal(toastCalls.length, 0, '及时作答不该提醒')
  c.disposeAll()
})

await check('waitingNotifyDelayMs=0 → 关闭提醒', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingNotifyDelayMs: 0 })
  await sleep(20)
  const { release, pending } = await enterWaiting(c)
  await sleep(200)
  assert.equal(toastCalls.length, 0, '关闭时不该提醒')
  release()
  await pending
  c.disposeAll()
})

await check('下一段等待会重新计时（用户作答后再问一次仍会提醒）', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingNotifyDelayMs: 80 })
  await sleep(20)
  const first = await enterWaiting(c)
  await sleep(180)
  assert.equal(toastCalls.length, 1, '第一次应提醒')
  first.release()
  await first.pending
  await sleep(30)
  const second = await enterWaiting(c)
  await sleep(180)
  assert.equal(toastCalls.length, 2, '第二次等待应重新提醒')
  second.release()
  await second.pending
  c.disposeAll()
})

// ── 「任务完成」后未操作 DSH → 「老大请验收」 ────────────────────────────────
/** 让假 ctx 走一遍 运行 → 完成，从而点亮 done 相位。 */
async function completeOnce(c) {
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'idle' })
}

await check('完成后未被操作 → 弹「老大请验收」', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 30_000 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, {
    backend: 'none',
    pollMs: 100_000,
    reassertMs: 0,
    waitingNotifyDelayMs: 0,
    reviewNotifyDelayMs: 80,
    notifyPersona: '大肥鱼',
    reviewNotifyText: '老大请验收',
  })
  await sleep(20)
  await completeOnce(c)
  await sleep(260)
  assert.equal(toastCalls.length, 1, `应弹一次，实际 ${toastCalls.length}`)
  assert.equal(toastCalls[0].title, '大肥鱼', '发信人应是配置的 persona')
  assert.equal(toastCalls[0].text, '老大请验收')
  assert.equal(toastCalls[0].aumid, 'com.deepseek.dsh')
  c.disposeAll()
})

await check('完成时正在操作 DSH（前台 + 窗口内有过输入）→ 不打扰', async () => {
  toastCalls.length = 0
  // 同一个 reviewNotifyDelayMs 既是"等多久"，也是"多久内算操作过"的时间窗；
  // 测试里把它压到 300ms，所以模拟"刚输入过"要用更小的 idleMs。
  setActivityProbe(async () => ({ foregroundIsDsh: true, idleMs: 40 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingNotifyDelayMs: 0, reviewNotifyDelayMs: 300 })
  await sleep(20)
  await completeOnce(c)
  await sleep(420)
  assert.equal(toastCalls.length, 0, '正在操作时不该弹')
  c.disposeAll()
})

await check('DSH 在前台但长时间无输入（人走开了）→ 仍然提醒', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: true, idleMs: 60_000 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingNotifyDelayMs: 0, reviewNotifyDelayMs: 80 })
  await sleep(20)
  await completeOnce(c)
  await sleep(260)
  assert.equal(toastCalls.length, 1, '人走开了应该提醒')
  c.disposeAll()
})

await check('探测失败 → fail-open（宁可多提醒，不吞掉完成事件）', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => undefined)
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingNotifyDelayMs: 0, reviewNotifyDelayMs: 80 })
  await sleep(20)
  await completeOnce(c)
  await sleep(260)
  assert.equal(toastCalls.length, 1, '探测失败时应照常提醒')
  c.disposeAll()
})

await check('reviewNotifyDelayMs=0 → 关闭完成提醒', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 99_999 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingNotifyDelayMs: 0, reviewNotifyDelayMs: 0 })
  await sleep(20)
  await completeOnce(c)
  await sleep(220)
  assert.equal(toastCalls.length, 0, '关闭时不该提醒')
  c.disposeAll()
})

await check('完成提醒在离开 done 后取消（不会延迟补弹）', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 99_999 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingNotifyDelayMs: 0, reviewNotifyDelayMs: 300 })
  await sleep(20)
  await completeOnce(c)
  // 在提醒到点前用户又开跑了 → 相位离开 done
  await sleep(60)
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  await sleep(400)
  assert.equal(toastCalls.length, 0, '离开 done 后应取消提醒')
  c.disposeAll()
})

// ── v2.0 ④ 故障提醒：立即发、不可关闭、不可配置 ────────────────────────────
await check('故障 → 立即弹「故障，请检查」', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingNotifyDelayMs: 0 })
  await sleep(20)
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  toastCalls.length = 0
  await c.emit('api-session/error', 'top', 'boom')
  await sleep(80)
  assert.equal(toastCalls.length, 1, `故障应恰好弹一条，实际 ${toastCalls.length}`)
  assert.equal(toastCalls[0].text, '故障，请检查')
  assert.equal(toastCalls[0].text, FAILURE_NOTICE_TEXT)
  assert.equal(toastCalls[0].title, '大肥鱼')
  c.disposeAll()
})

await check('故障提醒没有开关：配置里塞一堆 false 也照样发', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  // 把所有"看起来像开关"的键都设为 false —— 故障提醒依然必须发出（需求：用户不得关闭）
  apply(c, {
    backend: 'none',
    pollMs: 100_000,
    reassertMs: 0,
    waitingNotifyEnabled: false,
    reviewNotifyEnabled: false,
    driftNotifyEnabled: false,
    failureNotifyEnabled: false,
    failureNotifyText: '不该出现',
  })
  await sleep(20)
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  toastCalls.length = 0
  await c.emit('api-session/error', 'top', 'boom')
  await sleep(80)
  assert.equal(toastCalls.length, 1, '故障提醒不可被关闭')
  assert.equal(toastCalls[0].text, '故障，请检查', '故障文案写死，配置改不动')
  c.disposeAll()
})

await check('同一个故障不重复刷屏（粘性错误按内容去重）', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0 })
  await sleep(20)
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  await c.emit('api-session/error', 'top', 'boom')
  await sleep(40)
  assert.equal(toastCalls.length, 1)
  await c.emit('api-session/error', 'top', 'boom')
  await c.emit('api-session/error', 'top', 'boom')
  await sleep(60)
  assert.equal(toastCalls.length, 1, '同一个故障只提醒一次')
  c.disposeAll()
})

// ── v2.1.2 ④ 故障提醒：改成**事件型**（同一次故障只提醒一次）──────────────────
//
// 真机证据（Windows 通知中心历史）：70 条 DSH toast 里约 60 条是「故障，请检查」，成簇出现。
// 老逻辑把 ④ 挂在 `onPhase` 的"相位变成 error"上，于是 `errorHoldMs`（默认 60 秒）到点、
// 粘性错误把相位带回 error 时会**再发一条**，会话只要停在故障态就每 60 秒刷一次。
// 下面三条是端到端的回归保护（真定时器、真 apply()、真事件），机器级用例见 plugin-state。

await check('v2.1.2 故障提醒：两个不同会话各自报错 → 各弹一条（相位本来就是 error 也要发）', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, errorHoldMs: 0 })
  await sleep(20)
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  await c.emit('api-session/error', 'top', 'boom')
  await sleep(40)
  assert.equal(toastCalls.length, 1, `第一个会话应弹一条，实际 ${toastCalls.length}`)
  toastCalls.length = 0
  // 第二个会话报错：此刻相位**本来就是** error（changed=false），老逻辑在这里会漏掉它
  await c.emit('agent/error', { agent: { id: 'other' }, error: new Error('other boom') })
  await sleep(40)
  assert.equal(toastCalls.length, 1, '每个会话各提醒一次：第二个会话也该弹')
  assert.equal(toastCalls[0].text, FAILURE_NOTICE_TEXT)
  c.disposeAll()
})

await check('v2.1.2 故障提醒：会话重新开跑后再次出错 → 再弹一条', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, errorHoldMs: 0 })
  await sleep(20)
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  await c.emit('api-session/error', 'top', 'boom')
  await sleep(40)
  assert.equal(toastCalls.length, 1)
  // 同一次故障期内反复上报（粘性错误）→ 一条都不能再弹
  await c.emit('api-session/error', 'top', 'boom')
  await c.emit('api-session/error', 'top', 'boom')
  await sleep(40)
  assert.equal(toastCalls.length, 1, '同一次故障期内不再弹')
  // 重新开跑 = 恢复正常 → 之后再次出错，允许再提醒一条
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  await c.emit('api-session/error', 'top', 'boom')
  await sleep(40)
  assert.equal(toastCalls.length, 2, `恢复后再出错应再弹一条，实际 ${toastCalls.length}`)
  c.disposeAll()
})

await check('v2.1.2 回归保护：errorHoldMs 消退 → 相位离开 error 又重新进入 → 绝不再弹', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  // errorHoldMs 压到 120ms + 轮询 40ms：让"红条消退（相位离开 error）→ 粘性错误再上报"快速跑完。
  // 这正是真机上每 60 秒刷一条通知的那条路径。
  apply(c, { backend: 'none', pollMs: 40, reassertMs: 0, errorHoldMs: 120 })
  await sleep(20)
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  await c.emit('api-session/error', 'top', 'boom')
  await sleep(40)
  assert.equal(toastCalls.length, 1, `首次故障应弹一条，实际 ${toastCalls.length}`)
  // 等 errorHoldMs 到期，让轮询里的 recompute 把红条消退掉（相位离开 error）
  await sleep(220)
  assert.equal(phases(c).at(-1) === 'error', false, `消退后相位应离开 error，实际序列：${phases(c)}`)
  // 粘性错误再上报：消退把内容签名也清了，所以**灯**会照旧重新亮红
  await c.emit('api-session/error', 'top', 'boom')
  await sleep(60)
  assert.equal(phases(c).at(-1), 'error', '红条照旧重新亮红（视觉行为没改）')
  assert.equal(toastCalls.length, 1, `消退后复亮不得再弹（老逻辑这里会弹第 2 条），实际 ${toastCalls.length}`)
  c.disposeAll()
})

// ── v2.0 ③ 偏离纠正：连续工作太久 ──────────────────────────────────────────
await check('连续工作到点 → 弹「偏离纠正」提醒', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  // 用小数把"10 分钟"压成 ~120ms，测试才跑得动
  apply(c, {
    backend: 'none',
    pollMs: 100_000,
    reassertMs: 0,
    driftNotifyMinutes: 0.002,
    driftNotifyText: '已经连续工作10分钟，建议检查白饭是否被偷',
  })
  await sleep(20)
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  await sleep(320)
  assert.equal(toastCalls.length, 1, `应弹一条，实际 ${toastCalls.length}`)
  assert.equal(toastCalls[0].text, '已经连续工作10分钟，建议检查白饭是否被偷')
  c.disposeAll()
})

await check('中途出现"停止"（等待用户）→ 计时归零，不提醒', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingNotifyDelayMs: 0, driftNotifyMinutes: 0.003 })
  await sleep(20)
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  await sleep(80)
  // 等待用户 = 一次实打实的"停止"
  const { release, pending } = await enterWaiting(c)
  await sleep(200) // 原本 180ms 就该响，但计时已归零
  assert.equal(toastCalls.length, 0, '出现停止后不该再提醒')
  release()
  await pending
  c.disposeAll()
})

await check('③ 关闭偏离纠正 → 不提醒', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, driftNotifyEnabled: false, driftNotifyMinutes: 0.002 })
  await sleep(20)
  await c.emit('agent/status', { agent: { id: 'top' }, status: 'running' })
  await sleep(320)
  assert.equal(toastCalls.length, 0, '关掉后不该提醒')
  c.disposeAll()
})

// ── v2.0：两个可关闭通知的开关 ─────────────────────────────────────────────
await check('① 关闭等待提醒 → 即便超时也不弹', async () => {
  toastCalls.length = 0
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { backend: 'none', pollMs: 100_000, reassertMs: 0, waitingNotifyEnabled: false, waitingNotifyDelayMs: 60 })
  await sleep(20)
  const { release, pending } = await enterWaiting(c)
  await sleep(220)
  assert.equal(toastCalls.length, 0, '关掉等待提醒后不该弹')
  release()
  await pending
  c.disposeAll()
})

await check('② 关闭验收提醒 → 完成后不弹', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 99_999 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, {
    backend: 'none',
    pollMs: 100_000,
    reassertMs: 0,
    waitingNotifyDelayMs: 0,
    reviewNotifyEnabled: false,
    reviewNotifyDelayMs: 80,
  })
  await sleep(20)
  await completeOnce(c)
  await sleep(260)
  assert.equal(toastCalls.length, 0, '关掉验收提醒后不该弹')
  c.disposeAll()
})

// ── v2.1 需求 1 + 需求 2：子智能体 ─────────────────────────────────────────
//
// 判据与 lib/machine.js 的 countWorkingSubagents() 一致：**不在 roots() 里**
// 且 `status === 'running'` 的 agent 才算"还在工作的子智能体"。
// 下面用**假 agents 服务**复现，所以父子关系、状态都是可控且可复现的。
//
// ⚠️ 两条容易踩的测试坑（都是本文件实测出来的）：
//   1. 子智能体的来去靠**轮询**发现（它们的 agent/status 事件不一定送到插件，
//      也可能晚到），而 pollMs 的下限是 250ms —— 所以用例必须把间隔压到 250。
//   2. `reconcileRunning()` 会把 `agents.list()` 里**顶层**会话的状态当权威值。
//      假数据里如果 `top` 一直是 `running`，相位就永远停在 working，
//      主任务"完成"这件事根本没发生过 —— 收尾时必须把 `top` 也置成 idle。

/** 造一个可变的假 AgentRegistry。`root: false` 表示它是子智能体。 */
function makeAgents(specs) {
  const rows = specs.map((spec) => ({
    id: spec.id,
    status: spec.status,
    root: spec.root !== false,
  }))
  const byId = (id) => rows.find((row) => row.id === id)
  return {
    rows,
    list: () => rows.map((row) => ({ id: row.id, status: row.status })),
    roots: () => rows.filter((row) => row.root).map((row) => ({ id: row.id, status: row.status })),
    setStatus(id, status) {
      const row = byId(id)
      if (row !== undefined) row.status = status
    },
    allIdle() {
      for (const row of rows) row.status = 'idle'
    },
  }
}

/** 子智能体相关的用例统一用轮询下限，保证"跑完"能在断言前被发现。 */
const SUBAGENT_POLL_MS = 250

await check('需求 1：完成时还有子智能体在跑 → 正文硬性补上「（还有 N 个…）」', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 30_000 }))
  const agents = makeAgents([
    { id: 'top', status: 'idle', root: true },
    // 两个子智能体还在工作 + 两个已经空闲（可继续的子智能体跑完就是这个样子，不该被数进去）
    { id: 'sub-1', status: 'running', root: false },
    { id: 'sub-finished-1', status: 'idle', root: false },
    { id: 'sub-2', status: 'running', root: false },
    { id: 'sub-finished-2', status: 'idle', root: false },
  ])
  const c = createFakeCtx({ agents })
  apply(c, {
    backend: 'none',
    pollMs: 100_000,
    reassertMs: 0,
    waitingNotifyDelayMs: 0,
    reviewNotifyDelayMs: 80,
    reviewNotifyText: '老大请验收',
    // ⚠️ 故意**关掉**子智能体工作显示：这样主任务一停相位立刻进 done、②很快到点 ——
    // 于是那个后缀必须在"子智能体还在跑"的瞬间就被追加，而不是靠相位拖延。
    subagentDisplayEnabled: false,
  })
  await sleep(20)
  await completeOnce(c)
  await sleep(300)
  assert.equal(toastCalls.length, 1, `应弹一次，实际 ${toastCalls.length}`)
  assert.equal(
    toastCalls[0].text,
    '老大请验收（还有 2 个子智能体仍在工作）',
    '正文后面必须硬性追加，数量只算仍在 running 的子智能体',
  )
  c.disposeAll()
})

await check('需求 1：子智能体数为 0 → 一个字都不加，保持原文案', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 30_000 }))
  const agents = makeAgents([
    { id: 'top', status: 'running', root: true },
    // 子智能体都跑完了（可继续的那种会留在注册表里，但 status 是 idle）
    { id: 'sub-1', status: 'idle', root: false },
    { id: 'sub-2', status: 'idle', root: false },
  ])
  const c = createFakeCtx({ agents })
  apply(c, {
    backend: 'none',
    pollMs: 100_000,
    reassertMs: 0,
    waitingNotifyDelayMs: 0,
    reviewNotifyDelayMs: 80,
    reviewNotifyText: '老大请验收',
  })
  await sleep(20)
  await completeOnce(c)
  await sleep(300)
  assert.equal(toastCalls.length, 1)
  assert.equal(toastCalls[0].text, '老大请验收', '数量为 0 时不该有任何后缀')
  c.disposeAll()
})

await check('需求 1：后缀关不掉 —— 配置里塞任何 subagent*Suffix 键都照加', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 30_000 }))
  const agents = makeAgents([
    { id: 'top', status: 'idle', root: true },
    { id: 'sub-1', status: 'running', root: false },
  ])
  const c = createFakeCtx({ agents })
  apply(c, {
    backend: 'none',
    pollMs: 100_000,
    reassertMs: 0,
    waitingNotifyDelayMs: 0,
    reviewNotifyDelayMs: 80,
    reviewNotifyText: '老大请验收',
    // 这些键根本不认识，只会被 normalizeConfig 当未知项警告后忽略
    subagentSuffix: '',
    subagentSuffixEnabled: false,
    subagentNoticeSuffixEnabled: false,
  })
  await sleep(20)
  await completeOnce(c)
  await sleep(300)
  assert.equal(toastCalls.length, 1)
  assert.ok(
    toastCalls[0].text.endsWith('（还有 1 个子智能体仍在工作）'),
    `后缀是硬性追加的，实际正文：${toastCalls[0].text}`,
  )
  const warnings = c.logs.filter(([level]) => level === 'warn').map(([, m]) => m)
  assert.ok(warnings.some((m) => m.includes('subagentSuffix')), '未知后缀开关应被当作未知配置项提示')
  c.disposeAll()
})

await check('需求 2：开关开 + 子智能体还在跑 → 不点 done、②不发；全跑完才 done 并补发②', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 30_000 }))
  const agents = makeAgents([
    { id: 'top', status: 'running', root: true },
    { id: 'sub-1', status: 'running', root: false },
    { id: 'sub-2', status: 'running', root: false },
  ])
  const c = createFakeCtx({ agents })
  apply(c, {
    backend: 'none',
    pollMs: SUBAGENT_POLL_MS,
    reassertMs: 0,
    waitingNotifyDelayMs: 0,
    reviewNotifyDelayMs: 80,
    completionHoldMs: 30_000, // 拉长保持期，免得 done 在断言前就消退
    reviewNotifyText: '老大请验收',
    subagentDisplayEnabled: true,
    subagentDoneNotifyEnabled: true,
  })
  await sleep(30)
  await completeOnce(c)
  // 主任务完成了，但子智能体还在跑 → 相位必须继续 working，不能进 done
  assert.equal(phases(c).at(-1), 'working', '还有子智能体在跑时不该显示 done（填满）')
  await sleep(600) // 远超 reviewNotifyDelayMs=80，也超过两个轮询周期
  assert.equal(toastCalls.length, 0, '子智能体没跑完时②不许发（即使超过 reviewNotifyDelayMs）')

  // 所有工作都结束了（主任务早就完成，这里轮到子智能体）→ 相位补上 done、②补发
  agents.allIdle()
  await sleep(900)
  assert.equal(phases(c).at(-1), 'done', '全部跑完才点 done')
  assert.equal(toastCalls.length, 1, '全部跑完才补发②，而且只发一条')
  assert.equal(toastCalls[0].text, '老大请验收', '这一刻已经没有在跑的子智能体了，不该有后缀')
  c.disposeAll()
})

await check('需求 2：子选项开 → 子智能体没跑完绝不发②；关 → 主任务完成就按原节奏发', async () => {
  const setup = (doneNotifyEnabled) => {
    const agents = makeAgents([
      { id: 'top', status: 'running', root: true },
      // 子智能体先跑完，好让"主任务完成"真的能走到 done ——
      // 「不点 done」是**父开关** subagentDisplayEnabled 的职责，与子选项无关。
      { id: 'sub-1', status: 'idle', root: false },
    ])
    const c = createFakeCtx({ agents })
    apply(c, {
      backend: 'none',
      pollMs: SUBAGENT_POLL_MS,
      reassertMs: 0,
      waitingNotifyDelayMs: 0,
      reviewNotifyDelayMs: 80,
      completionHoldMs: 30_000,
      reviewNotifyText: '老大请验收',
      subagentDisplayEnabled: true,
      subagentDoneNotifyEnabled: doneNotifyEnabled,
    })
    return { agents, c }
  }

  // 子选项开着：子智能体**还在跑**是父开关压住 done 的原因，②因此不该发
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 30_000 }))
  const running = makeAgents([
    { id: 'top', status: 'running', root: true },
    { id: 'sub-1', status: 'running', root: false },
  ])
  const onCtx = createFakeCtx({ agents: running })
  apply(onCtx, {
    backend: 'none',
    pollMs: SUBAGENT_POLL_MS,
    reassertMs: 0,
    waitingNotifyDelayMs: 0,
    reviewNotifyDelayMs: 80,
    completionHoldMs: 30_000,
    subagentDisplayEnabled: true,
    subagentDoneNotifyEnabled: true,
  })
  await sleep(30)
  await completeOnce(onCtx)
  await sleep(600)
  assert.equal(toastCalls.length, 0, '子选项开着时，子智能体没跑完就不发②')
  onCtx.disposeAll()

  // 子选项关掉：子智能体已经跑完，主任务一完成就照原节奏发
  toastCalls.length = 0
  const off = setup(false)
  await sleep(30)
  await completeOnce(off.c)
  await sleep(600)
  assert.equal(toastCalls.length, 1, '子选项关掉后，主任务完成就该照常提醒')
  assert.equal(toastCalls[0].text, '老大请验收', '这一刻没有在跑的子智能体，不该有后缀')
  off.c.disposeAll()
})

await check('需求 2：默认值下行为与 v2.0 一致（子智能体不拖住 done）', async () => {
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 30_000 }))
  const agents = makeAgents([
    { id: 'top', status: 'running', root: true },
    { id: 'sub-1', status: 'running', root: false },
    { id: 'sub-2', status: 'running', root: false },
  ])
  const c = createFakeCtx({ agents })
  // 不传 subagentDisplayEnabled / subagentDoneNotifyEnabled → 走宿主默认值 false / true
  apply(c, {
    backend: 'none',
    pollMs: 100_000,
    reassertMs: 0,
    waitingNotifyDelayMs: 0,
    reviewNotifyDelayMs: 80,
    completionHoldMs: 30_000,
    reviewNotifyText: '老大请验收',
  })
  await sleep(30)
  await completeOnce(c)
  assert.equal(phases(c).at(-1), 'done', '默认值 = v2.0 行为：主任务一停就 done，不等子智能体')
  await sleep(300)
  assert.equal(toastCalls.length, 1, '默认值下主任务完成就提醒')
  assert.equal(
    toastCalls[0].text,
    '老大请验收（还有 2 个子智能体仍在工作）',
    '默认值只关掉"相位被拖住"；需求 1 的后缀是硬性追加的，照旧出现',
  )
  c.disposeAll()
})

await check('子智能体只影响"数量"，不影响相位汇总（scope=roots 的隔离没被破坏）', async () => {
  toastCalls.length = 0
  const agents = makeAgents([
    { id: 'top', status: 'idle', root: true },
    { id: 'sub-1', status: 'running', root: false },
  ])
  const c = createFakeCtx({ agents })
  // 子智能体工作显示开着，但**主任务从未跑过** → 不能因为子智能体在跑就点 working
  apply(c, {
    backend: 'none',
    pollMs: 100_000,
    reassertMs: 0,
    subagentDisplayEnabled: true,
  })
  await sleep(30)
  assert.equal(phases(c).at(-1), 'idle', '子智能体不该把从未开工的主任务点亮成 working')
  c.disposeAll()
})

setActivityProbe(null)

// ── v2.1 需求 4：微信手机提醒的宿主接线 ─────────────────────────────────────
//
// ⚠️ 这一节**不连微信、不连网**：微信提醒器整体换成假的（`setWechatNotifierFactory`），
// 所以这里断言的是"什么时候调用提醒器、传了什么 sessionId / kind、门控过不过"，
// 而不是"微信插件到底能不能发" —— 后者由 test/wechat.test.mjs 用假 ctx 覆盖。
//
// 提醒器在 `apply()` 里构造，所以工厂必须在这里装好（前面那些用例已经跑完了）。
/**
 * 假提醒器：wechat.js 公开的那几个方法，另外把调用都记下来。
 *
 * v2.2.0 起多出五个独立通道的控制面（`startLogin` / `provideVerifyCode` /
 * `cancelLogin` / `disconnect` / `standaloneStatus`）—— 宿主新增的动作路由就是驱动它们的，
 * 所以这里必须一并提供，否则路由测试只能靠"方法不存在"那条分支。
 */
function makeFakeNotifier(options = {}) {
  const state = {
    available: options.available !== false,
    reason: options.reason ?? '未检测到 dsh-wechat-plugin',
    wechatSessions: new Set(options.wechatSessions ?? []),
    sendResult: options.sendResult !== false,
    // v2.2.0：probe() 的通道选择结果，默认给"联动模式"（与 v2.1.3 的返回形状兼容）
    mode: options.mode ?? (options.available === false ? 'standalone' : 'linked'),
    standalone: options.standalone ?? null,
    standaloneReady: options.standaloneReady !== false,
    standaloneError: options.standaloneError ?? '',
    // v2.2.0：宿主报给界面的"最近一次发送失败"
    lastError: options.lastError ?? '',
    loginResult: options.loginResult ?? { ok: true, phase: 'awaiting-scan' },
    verifyResult: options.verifyResult !== false,
    disconnectResult: options.disconnectResult ?? { ok: true },
  }
  const calls = {
    probe: 0,
    invalidate: 0,
    send: [],
    sessions: [],
    disposed: 0,
    order: [],
    startLogin: 0,
    verify: [],
    cancel: 0,
    disconnect: 0,
  }
  return {
    state,
    calls,
    async probe() {
      calls.probe += 1
      calls.order.push('probe')
      return {
        available: state.available,
        reason: state.available ? '' : state.reason,
        mode: state.mode,
        linked: { available: state.available, reason: state.available ? '' : state.reason },
        standalone: state.standalone,
        standaloneReady: state.standaloneReady,
        standaloneError: state.standaloneError,
        lastError: state.lastError,
      }
    },
    invalidate() {
      calls.invalidate += 1
      calls.order.push('invalidate')
    },
    async isWechatSession(sessionId) {
      calls.sessions.push(sessionId)
      return state.wechatSessions.has(sessionId)
    },
    async sendTaskNotice({ sessionId, kind }) {
      calls.send.push({ sessionId, kind })
      return state.sendResult
    },
    async startLogin() {
      calls.startLogin += 1
      calls.order.push('startLogin')
      return state.loginResult
    },
    provideVerifyCode(code) {
      calls.verify.push(code)
      calls.order.push('verify')
      return state.verifyResult
    },
    cancelLogin() {
      calls.cancel += 1
      calls.order.push('cancel')
    },
    async disconnect() {
      calls.disconnect += 1
      calls.order.push('disconnect')
      return state.disconnectResult
    },
    standaloneStatus() {
      return state.standalone
    },
    dispose() {
      calls.disposed += 1
    },
  }
}

let nextNotifierOptions = {}
const createdNotifiers = []
setWechatNotifierFactory((deps) => {
  assert.equal(typeof deps?.ctx?.get, 'function', '提醒器必须拿到宿主 ctx')
  assert.equal(typeof deps?.log, 'function', '提醒器必须拿到日志出口')
  assert.equal(typeof deps?.debug, 'function', '提醒器必须拿到诊断出口')
  const fake = makeFakeNotifier(nextNotifierOptions)
  createdNotifiers.push(fake)
  return fake
})
/** 用一组探测结果开一个新用例。 */
const withNotifier = (options = {}) => {
  nextNotifierOptions = options
  createdNotifiers.length = 0
  return { last: () => createdNotifiers.at(-1) }
}
const infoLogs = (c) => c.logs.filter(([level]) => level === 'info').map(([, m]) => m)

/** 走一遍"有任务在跑 → 跑完"，并在 api-session 层报上 sessionId。 */
async function completeSession(c, sessionId, agentId = 'top') {
  await c.emit('agent/status', { agent: { id: agentId }, status: 'running' })
  await c.emit('api-session/status', sessionId, true)
  await c.emit('agent/status', { agent: { id: agentId }, status: 'idle' })
  await c.emit('api-session/status', sessionId, false)
}

const wechatBaseConfig = {
  backend: 'none',
  pollMs: 100_000,
  reassertMs: 0,
  waitingNotifyDelayMs: 0,
  reviewNotifyDelayMs: 0,
}

await check('需求 4：默认关闭 —— 完成与等待都不会碰微信', async () => {
  const fake = withNotifier()
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 30_000 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { ...wechatBaseConfig, wechatWaitingDelayMs: 40 })
  await sleep(20)
  await completeSession(c, 's-1')
  const { release, pending } = await enterWaiting(c)
  await sleep(200)
  release()
  await pending
  assert.deepEqual(fake.last().calls.send, [], '两个微信开关默认都是关的（需求硬性要求）')
  assert.equal(fake.last().calls.probe, 0, '关着就不该去探测，别浪费四道闸')
  c.disposeAll()
})

await check('需求 4：完成后按自己的延迟发，sessionId/kind 都对（sessionId 取 api-session 层）', async () => {
  const fake = withNotifier()
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 30_000 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { ...wechatBaseConfig, wechatDoneEnabled: true, wechatDoneDelayMs: 80 })
  await sleep(20)
  await completeSession(c, 's-1')
  await sleep(260)
  assert.equal(fake.last().calls.send.length, 1, `应恰好发一条，实际 ${JSON.stringify(fake.last().calls.send)}`)
  assert.deepEqual(fake.last().calls.send[0], { sessionId: 's-1', kind: 'done' })
  assert.deepEqual(fake.last().calls.sessions, ['s-1'], '发送前必须先问"这是不是微信会话"')
  c.disposeAll()
})

await check('需求 4：拿不到 sessionId 时不发（不瞎发到别的对话），只记一条日志', async () => {
  const fake = withNotifier()
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { ...wechatBaseConfig, wechatWaitingEnabled: true, wechatWaitingDelayMs: 40 })
  await sleep(20)
  // 只从工具流水线进入等待：这条路径不带会话信息，currentSessionId() 仍然为空
  const { release, pending } = await enterWaiting(c)
  await sleep(200)
  release()
  await pending
  assert.deepEqual(fake.last().calls.send, [], '拿不到会话就不发')
  assert.ok(
    infoLogs(c).some((m) => m.includes('拿不到任务所属的会话 id')),
    `应有一条原因日志：${infoLogs(c)}`,
  )
  c.disposeAll()
})

await check('需求 4：等待相位 arm、离开相位取消（各按自己的延迟）', async () => {
  const fake = withNotifier()
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { ...wechatBaseConfig, wechatWaitingEnabled: true, wechatWaitingDelayMs: 300 })
  await sleep(20)
  const { release, pending } = await enterWaiting(c)
  await c.emit('api-session/status', 's-1', true)
  await sleep(80)
  // 还没到点就作答 → 取消
  release()
  await pending
  await sleep(400)
  assert.deepEqual(fake.last().calls.send, [], '离开 waiting 必须取消计时')

  // 再来一段等待，这次等满
  const second = await enterWaiting(c)
  await c.emit('api-session/status', 's-1', true)
  await sleep(420)
  assert.equal(fake.last().calls.send.length, 1)
  assert.deepEqual(fake.last().calls.send[0], { sessionId: 's-1', kind: 'waiting' })
  second.release()
  await second.pending
  c.disposeAll()
})

await check('需求 4：微信与电脑端是两套独立延迟 —— 谁也不取消谁', async () => {
  const fake = withNotifier()
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 30_000 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, {
    ...wechatBaseConfig,
    reviewNotifyEnabled: true,
    reviewNotifyDelayMs: 60, // 电脑端很快
    wechatDoneEnabled: true,
    wechatDoneDelayMs: 420, // 微信明显更慢
  })
  await sleep(20)
  await completeSession(c, 's-1')
  await sleep(200)
  assert.equal(toastCalls.length, 1, '电脑端 60ms 就该弹了')
  assert.deepEqual(fake.last().calls.send, [], '微信那条还没到点，不能被电脑端带出来')
  await sleep(400)
  assert.equal(toastCalls.length, 1, '电脑端只弹一次')
  assert.deepEqual(fake.last().calls.send, [{ sessionId: 's-1', kind: 'done' }], '微信那条按自己的延迟发出')
  c.disposeAll()
})

await check('需求 4：完成后你正在操作 DSH → 复用②的活动探测，不震手机', async () => {
  const fake = withNotifier()
  toastCalls.length = 0
  setActivityProbe(async () => ({ foregroundIsDsh: true, idleMs: 40 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { ...wechatBaseConfig, wechatDoneEnabled: true, wechatDoneDelayMs: 80 })
  await sleep(20)
  await completeSession(c, 's-1')
  await sleep(260)
  assert.deepEqual(fake.last().calls.send, [], '你就在 DSH 前面，不必再发手机')
  assert.equal(toastCalls.length, 0, '电脑端同理（同一条活动探测语义）')
  c.disposeAll()
})

await check('需求 4：探测失败 → fail-open，照发（与②同一条原则）', async () => {
  const fake = withNotifier()
  setActivityProbe(async () => undefined)
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { ...wechatBaseConfig, wechatDoneEnabled: true, wechatDoneDelayMs: 80 })
  await sleep(20)
  await completeSession(c, 's-1')
  await sleep(260)
  assert.equal(fake.last().calls.send.length, 1, '探测失败不能把"任务完成了"这件事吞掉')
  c.disposeAll()
})

await check('需求 4：微信会话自身不发（不回声）', async () => {
  const fake = withNotifier({ wechatSessions: ['s-wechat'] })
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { ...wechatBaseConfig, wechatWaitingEnabled: true, wechatWaitingDelayMs: 40 })
  await sleep(20)
  await c.emit('api-session/status', 's-wechat', true)
  const { release, pending } = await enterWaiting(c)
  await sleep(200)
  release()
  await pending
  assert.deepEqual(fake.last().calls.send, [], '目标是微信对话本身，再推一遍就是回声')
  assert.ok(
    infoLogs(c).some((m) => m.includes('不回声')),
    `应说明为什么跳过：${infoLogs(c)}`,
  )
  c.disposeAll()
})

await check('需求 4：插件不可用（未装/未连/跨会话被关）→ 不发，且同一原因只提示一次', async () => {
  const fake = withNotifier({ available: false, reason: '微信插件未连接账号' })
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { ...wechatBaseConfig, wechatWaitingEnabled: true, wechatWaitingDelayMs: 30 })
  await sleep(20)
  for (let round = 0; round < 3; round += 1) {
    await c.emit('api-session/status', 's-1', true)
    const { release, pending } = await enterWaiting(c)
    await sleep(140)
    release()
    await pending
    await sleep(20)
  }
  assert.deepEqual(fake.last().calls.send, [], '不可用时一条都不许发')
  const reasons = infoLogs(c).filter((m) => m.includes('微信插件未连接账号'))
  assert.equal(reasons.length, 1, `同一原因只许提示一次，实际 ${reasons.length} 次`)
  c.disposeAll()
})

await check('需求 4：延迟设成 0 等于关闭（与①②的约定一致）', async () => {
  const fake = withNotifier()
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, {
    ...wechatBaseConfig,
    wechatDoneEnabled: true,
    wechatDoneDelayMs: 0,
    wechatWaitingEnabled: true,
    wechatWaitingDelayMs: 0,
  })
  await sleep(20)
  await completeSession(c, 's-1')
  const { release, pending } = await enterWaiting(c)
  await sleep(200)
  release()
  await pending
  assert.deepEqual(fake.last().calls.send, [], '0 = 关闭')
  c.disposeAll()
})

await check('需求 4：插件停用 → 取消微信计时并释放提醒器', async () => {
  const fake = withNotifier()
  setActivityProbe(async () => ({ foregroundIsDsh: false, idleMs: 30_000 }))
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { ...wechatBaseConfig, wechatDoneEnabled: true, wechatDoneDelayMs: 300 })
  await sleep(20)
  await completeSession(c, 's-1')
  c.disposeAll() // 保持期还没到就停用
  await sleep(420)
  assert.deepEqual(fake.last().calls.send, [], '停用后不该再补发')
  assert.equal(fake.last().calls.disposed, 1, '提醒器要释放（清探测缓存）')
})

// ── 需求 4 的浏览器半边通道：只读状态路由 ───────────────────────────────────
/** 假 webServer：只实现 register，并把 route 记下来。 */
function makeWebServer() {
  const routes = []
  return {
    routes,
    register(route) {
      routes.push(route)
      return () => {
        const index = routes.indexOf(route)
        if (index >= 0) routes.splice(index, 1)
      }
    },
  }
}

/**
 * 假 req/res，够跑一次路由处理器。
 *
 * v2.2.0：动作路由要读 POST body，而 `readJsonBody` 用的是 `for await (const chunk of req)`
 * —— 所以假 req 必须是**异步可迭代**的（真 node:http 的 IncomingMessage 就是）。
 * 传了 `body` 就按 JSON 序列化后作为一块数据吐出来。
 */
function makeHttpPair(url = WECHAT_STATE_ROUTE, method = 'GET', body = undefined) {
  const chunks = body === undefined ? [] : [Buffer.from(JSON.stringify(body), 'utf8')]
  const res = {
    status: 0,
    headers: null,
    writeHead(status, headers) {
      this.status = status
      this.headers = headers
      return this
    },
    end(value) {
      this.body = value
    },
  }
  const req = {
    url,
    method,
    headers: {},
    async *[Symbol.asyncIterator]() {
      for (const chunk of chunks) yield chunk
    },
  }
  return { req, res, body: () => JSON.parse(res.body) }
}

/** 从注册表里按 path 找路由。 */
const routeAt = (webServer, path) => {
  const route = webServer.routes.find((item) => item.path === path)
  assert.ok(route, `应注册路由 ${path}（实际：${webServer.routes.map((item) => item.path).join(', ')}）`)
  return route
}

await check('需求 4：宿主注册状态路由 + 四条独立连接动作路由（注册进 webServer，能被注销）', async () => {
  const fake = withNotifier()
  const webServer = makeWebServer()
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] }, webServer })
  apply(c, { ...wechatBaseConfig })
  await sleep(20)
  // v2.2.0：从"恰好一条只读路由"扩成"一条状态 + 四条动作"（见 lib/index.js 的路由选型注释）
  assert.deepEqual(
    webServer.routes.map((route) => route.path),
    [WECHAT_STATE_ROUTE, ...WECHAT_ACTION_ROUTES],
    '状态路由在前，四条动作路由在后；路径清单与导出的常量一致',
  )
  assert.equal(WECHAT_ACTION_ROUTES.length, 4, 'login / verify / cancel / disconnect')
  for (const route of webServer.routes) {
    assert.equal(route.kind, 'exact', '精确匹配，不做前缀覆盖')
    assert.equal(typeof route.handler, 'function')
  }
  c.disposeAll()
  assert.equal(webServer.routes.length, 0, '插件停用要把五条路由全部撤销')
  assert.ok(fake.last(), '提醒器由 apply 构造，路由与提醒共用同一个（所以探测缓存也共用）')
})

await check('需求 4：状态路由回答 probe() 的结论（可用 / 不可用 + 通道选择 + reason）', async () => {
  const fake = withNotifier({ available: false, reason: '微信插件的跨会话通知被关闭' })
  const webServer = makeWebServer()
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] }, webServer })
  apply(c, { ...wechatBaseConfig })
  await sleep(20)
  const route = routeAt(webServer, WECHAT_STATE_ROUTE)

  // v2.2.0：线上形状多了 mode / linked / standalone / standaloneReady / standaloneError
  const unavailable = makeHttpPair()
  await route.handler(unavailable.req, unavailable.res)
  assert.equal(unavailable.res.status, 200)
  assert.deepEqual(unavailable.body(), {
    available: false,
    reason: '微信插件的跨会话通知被关闭',
    mode: 'standalone',
    linked: { available: false, reason: '微信插件的跨会话通知被关闭' },
    standalone: null,
    standaloneReady: true,
    standaloneError: '',
    lastError: '',
  })

  fake.last().state.available = true
  fake.last().state.reason = ''
  fake.last().state.mode = 'linked'
  const available = makeHttpPair()
  await route.handler(available.req, available.res)
  assert.deepEqual(available.body(), {
    available: true,
    reason: '',
    mode: 'linked',
    linked: { available: true, reason: '' },
    standalone: null,
    standaloneReady: true,
    standaloneError: '',
    lastError: '',
  })
  c.disposeAll()
})

await check('需求 4：状态路由不写任何东西 —— 非 GET 一律 405', async () => {
  withNotifier()
  const webServer = makeWebServer()
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] }, webServer })
  apply(c, { ...wechatBaseConfig })
  await sleep(20)
  const post = makeHttpPair(WECHAT_STATE_ROUTE, 'POST')
  await routeAt(webServer, WECHAT_STATE_ROUTE).handler(post.req, post.res)
  assert.equal(post.res.status, 405)
  c.disposeAll()
})

// ── v2.1.3：强刷（`?refresh=1`）绕过 30 秒探测缓存 ─────────────────────────
//
// 真机证据见 README 第 11 节 v2.1.3：20:43:17 探到"微信里还没有对话"、21:01:35 绑定才建立，
// 而设置页一直显示 20:43 那次的结论 —— 所以「重新检测」必须能立刻拿到此刻的真实现场。
await check('v2.1.3：带 ?refresh=1 时先 invalidate() 再 probe()（顺序断言），不带时不动缓存', async () => {
  const fake = withNotifier({ available: false, reason: '微信里还没有对话，请先用手机给机器人发一条消息' })
  const webServer = makeWebServer()
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] }, webServer })
  apply(c, { ...wechatBaseConfig })
  await sleep(20)
  const route = routeAt(webServer, WECHAT_STATE_ROUTE)
  const notifier = fake.last()

  // ① 不带参数：照旧走缓存，**不许** invalidate（保持现状）
  const plain = makeHttpPair()
  await route.handler(plain.req, plain.res)
  assert.equal(plain.body().available, false)
  assert.equal(plain.body().reason, '微信里还没有对话，请先用手机给机器人发一条消息')
  assert.equal(notifier.calls.invalidate, 0, '普通请求不许动缓存')
  assert.deepEqual(notifier.calls.order, ['probe'], '普通请求只 probe 一次')

  // ② 带强刷参数：先 invalidate() 再 probe()
  notifier.calls.order.length = 0
  const strong = makeHttpPair(`${WECHAT_STATE_ROUTE}?${WECHAT_REFRESH_PARAM}=1`)
  await route.handler(strong.req, strong.res)
  assert.deepEqual(notifier.calls.order, ['invalidate', 'probe'], '强刷必须是"先作废缓存、再探测"这个顺序')
  assert.equal(strong.body().reason, '微信里还没有对话，请先用手机给机器人发一条消息')

  // ③ 现场变了（用户在手机上发了消息）→ 再强刷一次立刻拿到新结论
  notifier.calls.order.length = 0
  notifier.state.available = true
  notifier.state.reason = ''
  notifier.state.mode = 'linked'
  const again = makeHttpPair(`${WECHAT_STATE_ROUTE}?${WECHAT_REFRESH_PARAM}=true`)
  await route.handler(again.req, again.res)
  assert.deepEqual(notifier.calls.order, ['invalidate', 'probe'])
  assert.equal(again.body().available, true, '强刷后必须看到新现场，而不是上一轮的缓存')
  assert.equal(again.body().reason, '')
  assert.equal(again.body().mode, 'linked')

  // ④ `?refresh=0` 是明确要求"走缓存"，不许被当成强刷
  notifier.calls.order.length = 0
  const off = makeHttpPair(`${WECHAT_STATE_ROUTE}?${WECHAT_REFRESH_PARAM}=0`)
  await route.handler(off.req, off.res)
  assert.deepEqual(notifier.calls.order, ['probe'], 'refresh=0 要按"不强刷"处理（别用 includes 猜）')

  // ⑤ 路由是 exact 匹配：带 query 的请求仍然落在同一条路由上（宿主先剥 query 再查表），
  //    所以这里必须能拿到 200 与正常应答，不能 404。
  assert.equal(off.res.status, 200, '带 query 也必须命中这条 exact 路由')
  c.disposeAll()
})

await check('v2.1.3：强刷探测抛错时仍然降级成"不可用 + 一句话"，不把请求打成 500', async () => {
  const fake = withNotifier()
  const webServer = makeWebServer()
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] }, webServer })
  apply(c, { ...wechatBaseConfig })
  await sleep(20)
  const notifier = fake.last()
  notifier.probe = async () => {
    notifier.calls.order.push('probe')
    throw new Error('probe exploded')
  }
  const strong = makeHttpPair(`${WECHAT_STATE_ROUTE}?${WECHAT_REFRESH_PARAM}=1`)
  await routeAt(webServer, WECHAT_STATE_ROUTE).handler(strong.req, strong.res)
  assert.equal(strong.res.status, 200)
  // 探测抛错 = **未知**：mode 给 null，客户端据此不做任何模式专属展示（"问不到" ≠ "没有"）
  assert.deepEqual(strong.body(), {
    available: false,
    reason: '探测微信插件时出错',
    mode: null,
    linked: { available: false, reason: '探测微信插件时出错' },
    standalone: null,
    standaloneReady: false,
    standaloneError: '',
    lastError: '',
  })
  c.disposeAll()
})

await check('需求 4：有 connection 服务时套上 GUI 自己的请求守卫（401/403 直接挡掉）', async () => {
  withNotifier()
  const webServer = makeWebServer()
  const c = createFakeCtx({
    agents: { list: () => [], roots: () => [] },
    webServer,
    connection: { requestRejection: () => 401 },
  })
  apply(c, { ...wechatBaseConfig })
  await sleep(20)
  const denied = makeHttpPair()
  await routeAt(webServer, WECHAT_STATE_ROUTE).handler(denied.req, denied.res)
  assert.equal(denied.res.status, 401)
  // v2.2.0：动作路由同样套这道守卫（否则"开始登录"就成了绕过 GUI 鉴权的入口）
  const deniedLogin = makeHttpPair(WECHAT_LOGIN_ROUTE, 'POST', {})
  await routeAt(webServer, WECHAT_LOGIN_ROUTE).handler(deniedLogin.req, deniedLogin.res)
  assert.equal(deniedLogin.res.status, 401)
  c.disposeAll()
})

await check('需求 4：没有 webServer 时只记一条 info，进度条与通知照旧', async () => {
  withNotifier()
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { ...wechatBaseConfig })
  await sleep(20)
  assert.ok(
    infoLogs(c).some((m) => m.includes('没有 webServer 服务')),
    `应说明设置界面无法感知插件缺失：${infoLogs(c)}`,
  )
  assert.equal(phases(c).at(-1), 'idle', '进度条不受影响')
  c.disposeAll()
})

// ── v2.2.0：独立连接的动作路由（POST /login /verify /cancel /disconnect）────
//
// 这一节同样**不连微信、不连网**：提醒器是假的，所以断言的是"路由把动作交给了谁、
// 带了什么参数、返回了什么形状"，而不是"独立通道真的登录成功了吗"——
// 后者由 test/wechat.test.mjs 用假 standalone 覆盖。

/** 造一个带假 webServer 的宿主，拿到五条路由。 */
async function withRoutes(options = {}) {
  const fake = withNotifier(options)
  const webServer = makeWebServer()
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] }, webServer, ...(options.services ?? {}) })
  apply(c, { ...wechatBaseConfig })
  await sleep(20)
  return { fake, webServer, c }
}

await check('v2.2.0：POST /login → 驱动 startLogin()，回 { ok, error, state }', async () => {
  const { fake, webServer, c } = await withRoutes({ available: false, reason: '未检测到 dsh-wechat-plugin' })
  const pair = makeHttpPair(WECHAT_LOGIN_ROUTE, 'POST', {})
  await routeAt(webServer, WECHAT_LOGIN_ROUTE).handler(pair.req, pair.res)
  assert.equal(pair.res.status, 200)
  assert.equal(fake.last().calls.startLogin, 1, '点「连接微信」就该开始登录')
  assert.equal(fake.last().calls.cancel, 0, '不带 refresh 时不该先取消')
  assert.equal(pair.body().ok, true)
  assert.equal(pair.body().error, '')
  assert.equal(pair.body().state.mode, 'standalone', '动作响应里带上最新状态，界面不必再问一次')
  c.disposeAll()
})

await check('v2.2.0：POST /login { refresh: true } → 先 cancelLogin() 再 startLogin()（刷新二维码/重新连接）', async () => {
  const { fake, webServer, c } = await withRoutes({ available: false })
  const pair = makeHttpPair(WECHAT_LOGIN_ROUTE, 'POST', { refresh: true })
  await routeAt(webServer, WECHAT_LOGIN_ROUTE).handler(pair.req, pair.res)
  assert.deepEqual(
    fake.last().calls.order.filter((item) => item !== 'probe' && item !== 'invalidate'),
    ['cancel', 'startLogin'],
    '刷新二维码 = 先取消旧的、再重新开始（独立通道没有单独的 refresh 方法）',
  )
  c.disposeAll()
})

await check('v2.2.0：登录失败（模块没就绪）照样回 200 + ok:false + 人话，界面据此显示最近错误', async () => {
  const { fake, webServer, c } = await withRoutes({
    available: false,
    loginResult: { ok: false, error: 'lib/wechat-standalone.js 还没就绪' },
  })
  const pair = makeHttpPair(WECHAT_LOGIN_ROUTE, 'POST', {})
  await routeAt(webServer, WECHAT_LOGIN_ROUTE).handler(pair.req, pair.res)
  assert.equal(pair.res.status, 200, '业务失败不是协议错误：界面要拿到 error 去显示，而不是看到一个 500')
  assert.equal(pair.body().ok, false)
  assert.equal(pair.body().error, 'lib/wechat-standalone.js 还没就绪')
  assert.equal(fake.last().calls.startLogin, 1)
  c.disposeAll()
})

await check('v2.2.0：POST /verify → 提交验证码；缺 code 是 400；验证码绝不进任何日志', async () => {
  // 这条用例真的去读**诊断日志文件**（debugLogFile），而不是只看内存里的假日志 ——
  // "绝不打印验证码"这条要求必须在真实出口上验证。
  const debugFile = path.join(tmpdir(), `dsh-taskbar-verify-${process.pid}.jsonl`)
  rmSync(debugFile, { force: true })
  const fake = withNotifier({ available: false })
  const webServer = makeWebServer()
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] }, webServer })
  apply(c, { ...wechatBaseConfig, debugLogFile: debugFile })
  await sleep(20)
  const route = routeAt(webServer, WECHAT_VERIFY_ROUTE)

  const missing = makeHttpPair(WECHAT_VERIFY_ROUTE, 'POST', {})
  await route.handler(missing.req, missing.res)
  assert.equal(missing.res.status, 400, '没有 code 的请求是协议错误')
  assert.deepEqual(fake.last().calls.verify, [], '不该把空验证码交给通道')

  const pair = makeHttpPair(WECHAT_VERIFY_ROUTE, 'POST', { code: ' 1234 ' })
  await route.handler(pair.req, pair.res)
  assert.equal(pair.res.status, 200)
  assert.deepEqual(fake.last().calls.verify, ['1234'], '验证码要去掉首尾空白后再提交')
  assert.equal(pair.body().ok, true)

  // ⚠️ 隐私：验证码是凭据性内容，一个字都不许进 log / 诊断日志
  assert.ok(existsSync(debugFile), '诊断日志应被写出')
  const dump = JSON.stringify({ logs: c.logs, file: readFileSync(debugFile, 'utf8') })
  assert.ok(dump.includes('wechat-action'), `诊断日志里应能看见动作（只记成没成）：${dump.slice(0, 300)}`)
  assert.ok(!dump.includes('1234'), '日志里不许出现验证码')
  c.disposeAll()
  rmSync(debugFile, { force: true })
})

await check('v2.2.0：验证码被拒绝 → ok:false + 提示重新扫码（不静默失败）', async () => {
  const { fake, webServer, c } = await withRoutes({ available: false, verifyResult: false })
  const pair = makeHttpPair(WECHAT_VERIFY_ROUTE, 'POST', { code: '0000' })
  await routeAt(webServer, WECHAT_VERIFY_ROUTE).handler(pair.req, pair.res)
  assert.equal(pair.body().ok, false)
  assert.ok(pair.body().error.includes('验证码'), `要给一句人话：${pair.body().error}`)
  assert.deepEqual(fake.last().calls.verify, ['0000'])
  c.disposeAll()
})

await check('v2.2.0：POST /cancel 与 /disconnect 各自驱动对应方法', async () => {
  const { fake, webServer, c } = await withRoutes({ available: false })
  const cancel = makeHttpPair(WECHAT_CANCEL_ROUTE, 'POST', {})
  await routeAt(webServer, WECHAT_CANCEL_ROUTE).handler(cancel.req, cancel.res)
  assert.equal(cancel.body().ok, true)
  assert.equal(fake.last().calls.cancel, 1, '取消登录不该触发别的动作')
  assert.equal(fake.last().calls.disconnect, 0)

  const disconnect = makeHttpPair(WECHAT_DISCONNECT_ROUTE, 'POST', {})
  await routeAt(webServer, WECHAT_DISCONNECT_ROUTE).handler(disconnect.req, disconnect.res)
  assert.equal(disconnect.body().ok, true)
  assert.equal(fake.last().calls.disconnect, 1)
  c.disposeAll()
})

await check('v2.2.0：动作路由只认 POST；坏 JSON body 是 400（不会把 500 甩给界面）', async () => {
  const { webServer, c } = await withRoutes({ available: false })
  for (const path of WECHAT_ACTION_ROUTES) {
    const get = makeHttpPair(path, 'GET')
    await routeAt(webServer, path).handler(get.req, get.res)
    assert.equal(get.res.status, 405, `${path} 的 GET 应 405`)
  }
  // 坏 JSON：手搓一个能吐出非法 JSON 的 req
  const bad = {
    url: WECHAT_LOGIN_ROUTE,
    method: 'POST',
    headers: {},
    async *[Symbol.asyncIterator]() {
      yield Buffer.from('{不是 JSON', 'utf8')
    },
  }
  let status = 0
  const spied = { writeHead(value) { status = value }, end() {} }
  await routeAt(webServer, WECHAT_LOGIN_ROUTE).handler(bad, spied)
  assert.equal(status, 400)
  c.disposeAll()
})

await check('v2.2.0：状态路由把独立通道的相位/二维码/tokenFallback 原样带给界面（并附上 qrImage 渲染结果）', async () => {
  const standalone = {
    phase: 'awaiting-scan',
    qrContent: 'https://liteapp.weixin.qq.com/q/abc?qrcode=deadbeef',
    qrRefreshed: false,
    verifyAttempts: 0,
    accountId: 'acct-1',
    peerId: 'peer-1',
    error: '',
    connected: false,
    // v2.2.1：这张码是"旧 token 被拒 → 空列表兜底"取的，界面要能知道"旧绑定没能复用"
    tokenFallback: true,
  }
  const { webServer, c } = await withRoutes({ available: false, mode: 'standalone', standalone })
  const pair = makeHttpPair()
  await routeAt(webServer, WECHAT_STATE_ROUTE).handler(pair.req, pair.res)
  const body = pair.body()
  assert.equal(body.mode, 'standalone')
  assert.equal(body.available, false, '还没连上 → available 仍是 false，但 mode 告诉界面该显示「连接微信」')
  assert.equal(body.standalone.phase, 'awaiting-scan')
  assert.equal(body.standalone.qrContent, standalone.qrContent)
  assert.equal(body.standalone.tokenFallback, true, 'v2.2.1：降级取码这件事要透传到界面')
  // qrcode 渲染：workspace 里解析不到 qrcode 包（link 安装的现场），所以这里只断言
  // "要么给了 data URL，要么干脆没有这个字段"，绝不编造
  if ('qrImage' in body.standalone) {
    assert.ok(String(body.standalone.qrImage).startsWith('data:image/'), 'qrImage 必须是 data URL')
  }
  c.disposeAll()
})

await check('v2.2.0：状态路由把"最近一次发送失败"透传给界面（错误不许静默）', async () => {
  const { webServer, c } = await withRoutes({ available: false, lastError: '微信回信窗口已关闭，请先用手机给机器人发一条消息' })
  const pair = makeHttpPair()
  await routeAt(webServer, WECHAT_STATE_ROUTE).handler(pair.req, pair.res)
  assert.equal(
    pair.body().lastError,
    '微信回信窗口已关闭，请先用手机给机器人发一条消息',
    '宿主侧异步发生的发送失败只能靠这个字段让界面看见',
  )
  c.disposeAll()
})

// ── v2.2.0：切换通道**不得**重置去重状态 ────────────────────────────────────
//
// 去重键的语义（用户明确要求）：`sessionId + eventType + status`
//   · eventType ∈ { done, waiting, drift, failure }；
//   · status = 那一段 episode（①②③⑤ 是"每段相位一次"，④ 是"每会话一次故障"）；
//   · 记账挂在**会话/提醒器**上，与"用哪条通道发"无关 —— 所以联动↔独立切换**不该**
//     把已经提醒过的 episode 重新放出来（否则用户会立刻收到一批旧提醒）。
// 下面这条用例把这件事钉死：同一段等待里先探测不可用（不记账）、再变可用，
// 只允许发一条；而且第二次 arm 的同一段等待不会再发。
await check('v2.2.0：联动↔独立切换不重置去重（同一 episode 只发一条，不补发旧提醒）', async () => {
  const fake = withNotifier({ available: false, reason: '未检测到 dsh-wechat-plugin', mode: 'standalone' })
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] } })
  apply(c, { ...wechatBaseConfig, wechatWaitingEnabled: true, wechatWaitingDelayMs: 60 })
  await sleep(20)

  // 进入等待：此刻不"可用"（独立还没连上）→ 不该发
  await c.emit('api-session/status', 's-1', true)
  const first = await enterWaiting(c)
  await sleep(160)
  assert.deepEqual(fake.last().calls.send, [], '不可用时一条都不发')

  // 用户这时在设置界面点了「连接微信」（独立通道连上了）→ 通道切到 standalone 且可用
  fake.last().state.available = true
  fake.last().state.mode = 'standalone'
  await sleep(200)
  assert.deepEqual(fake.last().calls.send, [], '同一段等待已经过去了，切换通道不许把它补发出来')

  // 这一轮等待结束后，下一段等待才是新 episode → 允许发一条
  first.release()
  await first.pending
  await sleep(30)
  await c.emit('api-session/status', 's-1', true)
  const second = await enterWaiting(c)
  await sleep(180)
  assert.equal(fake.last().calls.send.length, 1, '新的 episode 才允许再提醒一次')
  second.release()
  await second.pending
  c.disposeAll()
})

// ── v2.2.0 端到端：路由 → 真提醒器 → 真独立通道（临时目录 + 假服务端）──────────
//
// 上面那些用例要么用假提醒器（测路由），要么直接调提醒器（测通道）。
// 这一条把两层串起来：真的 `createWechatNotifier`（默认动态 import 那三个模块）
// 挂在真的 `apply()` 上，动作路由打进去 → 提醒器 → 独立通道 → 假服务端。
// 仍然不联网、不碰用户真实凭据目录（store 指向临时目录）。
await check('v2.2.0 端到端：POST /login 打出二维码、POST /disconnect 清掉自己的凭据', async () => {
  const { createWechatNotifier } = await import('../lib/wechat.js')
  const { createWechatStore } = await import('../lib/wechat-store.js')
  const { mkdtempSync, existsSync } = await import('node:fs')
  const dir = mkdtempSync(path.join(tmpdir(), 'dsh-taskbar-e2e-'))
  const store = createWechatStore({ dir })
  const calls = []
  const fetchImpl = async (url, init = {}) => {
    calls.push(String(url))
    const payload = String(url).includes('get_bot_qrcode')
      ? { ret: 0, qrcode: 'qr-e2e', qrcode_img_content: 'https://liteapp.weixin.qq.com/q/e2e?qrcode=qr-e2e&bot_type=3' }
      : undefined
    if (payload !== undefined) {
      return { ok: true, status: 200, text: async () => JSON.stringify(payload), json: async () => payload }
    }
    // 状态轮询：挂住（真机上服务端会 hold 请求），只在被取消时中断 ——
    // 这样"停在等待扫码"的现场可复现，也不会把 10000 次迭代的保险丝烧掉。
    return await new Promise((resolve, reject) => {
      const signal = init.signal
      const abort = () => {
        const error = new Error('aborted')
        error.name = 'AbortError'
        reject(error)
      }
      if (signal?.aborted === true) abort()
      else signal?.addEventListener?.('abort', abort, { once: true })
      void resolve
    })
  }

  setWechatNotifierFactory((deps) => createWechatNotifier({
    ...deps,
    standaloneStore: store,
    standaloneFetch: fetchImpl,
    standaloneSleep: async () => {},
  }))
  const webServer = makeWebServer()
  const c = createFakeCtx({ agents: { list: () => [], roots: () => [] }, webServer })
  apply(c, { ...wechatBaseConfig })
  await sleep(20)

  // ① 状态：没有联动插件 → 独立模式、还没连上
  const state = makeHttpPair()
  await routeAt(webServer, WECHAT_STATE_ROUTE).handler(state.req, state.res)
  assert.equal(state.body().mode, 'standalone')
  assert.equal(state.body().available, false)
  assert.equal(state.body().standalone.phase, 'disconnected', `真通道的初始相位：${JSON.stringify(state.body().standalone)}`)

  // ② 点「连接微信」：宿主把登录挂起来，只等二维码就绪就返回
  const login = makeHttpPair(WECHAT_LOGIN_ROUTE, 'POST', {})
  await routeAt(webServer, WECHAT_LOGIN_ROUTE).handler(login.req, login.res)
  assert.equal(login.res.status, 200)
  assert.equal(login.body().ok, true, `登录应立刻开始：${JSON.stringify(login.body())}`)
  assert.equal(login.body().state.standalone.phase, 'awaiting-scan', '响应里就该带着二维码现场（界面不必再问一次）')
  assert.equal(login.body().state.standalone.qrContent, 'https://liteapp.weixin.qq.com/q/e2e?qrcode=qr-e2e&bot_type=3')
  assert.ok(calls.some((url) => url.includes('get_bot_qrcode')), '真的去取了二维码')
  // 二维码渲染：装了 profile 里的 qrcode 就是 data URL，没有这个字段就说明解析不到（界面会降级）
  if ('qrImage' in login.body().state.standalone) {
    assert.ok(String(login.body().state.standalone.qrImage).startsWith('data:image/'), 'qrImage 必须是 data URL')
  }

  // ③ 断开：只清本插件自己的凭据文件（这里全程没写共享文件，所以只断言自己的那份没了）
  const disconnect = makeHttpPair(WECHAT_DISCONNECT_ROUTE, 'POST', {})
  await routeAt(webServer, WECHAT_DISCONNECT_ROUTE).handler(disconnect.req, disconnect.res)
  assert.equal(disconnect.body().ok, true)
  assert.equal(existsSync(path.join(dir, 'standalone.json')), false, '断开后本插件的凭据文件应被清掉')
  assert.equal(disconnect.body().state.standalone.connected, false)

  c.disposeAll()
  setWechatNotifierFactory(null)
  rmSync(dir, { recursive: true, force: true })
})

setWechatNotifierFactory(null)
setActivityProbe(null)
setToastTransport(null)

console.log(`\nplugin wiring: ${passed} 项全部通过\n`)
