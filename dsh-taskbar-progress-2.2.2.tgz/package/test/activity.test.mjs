/**
 * 桌面活动探测的纯函数单测：判定规则 + 脚本生成 + 输出解析。
 * 不 spawn 进程、不碰真实桌面。
 *   node test/activity.test.mjs
 */

import assert from 'node:assert/strict'
import { isUserEngaged, parseActivityOutput, buildActivityScript } from '../lib/activity.js'

let passed = 0
const check = (label, fn) => {
  fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

console.log('desktop activity')

check('DSH 在前台 + 刚有输入 → 判定为"正在操作"', () => {
  assert.equal(isUserEngaged({ foregroundIsDsh: true, idleMs: 1200, thresholdMs: 15_000 }), true)
})

check('DSH 不在前台 → 不算"正在操作"（切去别的程序会提醒）', () => {
  assert.equal(isUserEngaged({ foregroundIsDsh: false, idleMs: 200, thresholdMs: 15_000 }), false)
})

check('DSH 在前台但长时间无输入 → 不算"正在操作"（人走开了会提醒）', () => {
  assert.equal(isUserEngaged({ foregroundIsDsh: true, idleMs: 16_000, thresholdMs: 15_000 }), false)
  assert.equal(isUserEngaged({ foregroundIsDsh: true, idleMs: 15_000, thresholdMs: 15_000 }), false, '边界：正好等于阈值算已超时')
  assert.equal(isUserEngaged({ foregroundIsDsh: true, idleMs: 14_999, thresholdMs: 15_000 }), true)
})

check('阈值 <= 0 时只看前台（不做空闲判断）', () => {
  assert.equal(isUserEngaged({ foregroundIsDsh: true, idleMs: 999_999, thresholdMs: 0 }), true)
  assert.equal(isUserEngaged({ foregroundIsDsh: false, idleMs: 0, thresholdMs: 0 }), false)
})

check('foregroundIsDsh 缺失/非 true → 一律不算"正在操作"（fail-open 提醒）', () => {
  assert.equal(isUserEngaged({ idleMs: 0, thresholdMs: 15_000 }), false)
  assert.equal(isUserEngaged({ foregroundIsDsh: 'yes', idleMs: 0, thresholdMs: 15_000 }), false)
})

check('idleMs 非法时按"未操作"处理', () => {
  assert.equal(isUserEngaged({ foregroundIsDsh: true, idleMs: Number.NaN, thresholdMs: 15_000 }), false)
})

check('parseActivityOutput 能解析探测脚本的输出', () => {
  assert.deepEqual(parseActivityOutput('foreground=1 idle=1234\n'), { foregroundIsDsh: true, idleMs: 1234 })
  assert.deepEqual(parseActivityOutput('  foreground=0 idle=0  '), { foregroundIsDsh: false, idleMs: 0 })
})

check('parseActivityOutput 对垃圾输出返回 undefined（不抛）', () => {
  assert.equal(parseActivityOutput(''), undefined)
  assert.equal(parseActivityOutput(undefined), undefined)
  assert.equal(parseActivityOutput('some error text'), undefined)
  assert.equal(parseActivityOutput('foreground=x idle=y'), undefined)
})

check('探测脚本包含所需 API，并带上目标 PID', () => {
  const script = buildActivityScript(12345)
  assert.ok(script.includes('GetForegroundWindow'), '应调用 GetForegroundWindow')
  assert.ok(script.includes('GetLastInputInfo'), '应调用 GetLastInputInfo')
  assert.ok(script.includes('GetWindowThreadProcessId'), '应取前台窗口的进程号')
  assert.ok(script.includes('Probe(12345)'), '应把目标 PID 传进去')
})

check('目标 PID 非法时不会拼出可执行的危险内容', () => {
  assert.ok(buildActivityScript(undefined).includes('Probe(0)'))
  assert.ok(buildActivityScript('abc; rm -rf /').includes('Probe(0)'))
})

console.log(`\ndesktop activity: ${passed} 项全部通过\n`)
