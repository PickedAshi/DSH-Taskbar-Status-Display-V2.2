/**
 * 微信任务提醒单测：全部用**假 ctx** 注入。
 * 不连真实微信、不 spawn 进程、不碰真实 DSH 宿主、不发任何网络请求。
 *
 *   node test/wechat.test.mjs
 */

import assert from 'node:assert/strict'
import {
  createWechatNotifier,
  buildTaskNoticeText,
  renderQrDataUrl,
  setQrRenderer,
  WECHAT_NOTIFY_TOOL,
  UNKNOWN_SESSION_TITLE,
  DEFAULT_PROBE_TTL_MS,
  NOTIFY_MODE_LINKED,
  NOTIFY_MODE_STANDALONE,
} from '../lib/wechat.js'

let passed = 0
const check = (label, fn) => {
  fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}
const checkAsync = async (label, fn) => {
  await fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

/* ------------------------------------------------------------------ 假宿主 */

/**
 * 夹具里默认的"已绑定微信对话"。
 *
 * 为什么默认给一条非空的：v2.1.1 起 `probe()` 多了第五道闸（必须存在已绑定的对话），
 * 夹具的默认形态就该代表"五道闸全过的现场"；要测"没有对话"的现场请显式传 `bindings: []`。
 * 注意 sessionId 故意既不叫 's-1' 也不叫 's-wechat*'，免得影响后面 isWechatSession 的断言。
 */
const DEFAULT_BINDING = Object.freeze({
  conversationId: 'conv-default',
  sessionId: 's-bound',
  title: '手机上已绑定的对话',
})

/** 假 wechatChannel runtime：只实现本模块用到的 bindings / settingsForPage / status。 */
function makeRt({
  bindings = [DEFAULT_BINDING],
  settings = { allowCrossSessionNotify: true },
  accounts = [{ accountId: 'acct-secret-123', userId: 'u-1', polling: true }],
  includeSettingsForPage = true,
  includeStatus = true,
  bindingsThrows,
  settingsThrows,
  statusThrows,
} = {}) {
  const calls = { bindings: 0, settingsForPage: 0, status: 0 }
  const rt = {
    calls,
    async bindings() {
      calls.bindings += 1
      if (bindingsThrows) throw bindingsThrows
      return bindings
    },
  }
  if (includeSettingsForPage) {
    rt.settingsForPage = async () => {
      calls.settingsForPage += 1
      if (settingsThrows) throw settingsThrows
      return { settings, defaults: settings }
    }
  }
  if (includeStatus) {
    rt.status = async () => {
      calls.status += 1
      if (statusThrows) throw statusThrows
      return { enabled: true, accounts, needsLogin: false }
    }
  }
  return rt
}

/** 假 tools 注册表：只实现 get(name) 与 execute(exec)。 */
const SUCCESS_RESULT = { isError: false, value: { detail: '已通过微信发送：消息' }, content: [] }

function makeTools({ hasNotify = true, result = SUCCESS_RESULT, executeThrows, noResult = false } = {}) {
  const calls = []
  return {
    calls,
    get(name) {
      return hasNotify && name === WECHAT_NOTIFY_TOOL ? { name: WECHAT_NOTIFY_TOOL } : undefined
    },
    async execute(exec) {
      calls.push(exec)
      if (executeThrows) throw executeThrows
      return noResult ? undefined : result
    },
  }
}

/** 假 ctx：`get()` 按 Cordis 语义返回 undefined，可选对某些服务名抛异常。 */
function makeCtx(parts = {}, { throwOn = [] } = {}) {
  const counts = new Map()
  const throwing = new Set(throwOn)
  return {
    counts,
    get(name) {
      counts.set(name, (counts.get(name) ?? 0) + 1)
      if (throwing.has(name)) throw new Error(`service ${name} 爆炸了`)
      return parts[name]
    },
  }
}

/**
 * 假独立通道（v2.2.0）：形状严格照 `lib/wechat-standalone.js` 的契约，一个方法都不多不少。
 *
 * 为什么现有的每条用例都要注入它：`createWechatNotifier` 的**默认**独立通道是
 * "动态 import lib/wechat-standalone.js + lib/wechat-store.js"。那两个文件由另一个
 * 交付方提供，一旦落地，这些纯离线用例就会真的去读凭据文件、甚至真的连网 ——
 * 单测必须**不联网、不碰文件系统**，所以夹具里一律换成这个替身（并且顺便能断言
 * "联动可用时压根没去构造独立通道"）。
 */
function makeStandalone(options = {}) {
  const calls = { status: 0, startLogin: 0, verify: [], cancel: 0, disconnect: 0, send: [], disposed: 0 }
  const state = {
    phase: options.phase ?? 'disconnected',
    qrContent: options.qrContent ?? '',
    qrRefreshed: options.qrRefreshed === true,
    verifyAttempts: options.verifyAttempts ?? 0,
    accountId: options.accountId ?? '',
    peerId: options.peerId ?? '',
    error: options.error ?? '',
    connected: options.connected === true,
  }
  return {
    state,
    calls,
    status() {
      calls.status += 1
      // 契约里 status() 是同步快照；故意返回**副本**，和真实实现一样
      return { ...state }
    },
    async startLogin() {
      calls.startLogin += 1
      if (options.startLoginThrows) throw options.startLoginThrows
      return options.loginResult ?? { ok: true, phase: 'awaiting-scan' }
    },
    provideVerifyCode(code) {
      calls.verify.push(code)
      if (options.verifyThrows) throw options.verifyThrows
      return options.verifyResult !== false
    },
    cancelLogin() {
      calls.cancel += 1
    },
    async disconnect() {
      calls.disconnect += 1
      if (options.disconnectThrows) throw options.disconnectThrows
      state.connected = false
      state.phase = 'disconnected'
    },
    isConnected() {
      return state.connected === true
    },
    async sendTaskNotice({ title, kind }) {
      calls.send.push({ title, kind })
      if (options.sendThrows) throw options.sendThrows
      return options.sendResult ?? { ok: true }
    },
    dispose() {
      calls.disposed += 1
    },
  }
}

/**
 * 组装一个可用的提醒器，并抓取 log / debug 便于断言。
 *
 * 独立通道三选一（默认第一个）：
 *  · `standalone`：现成的假替身（**默认**，离线、不碰文件系统）；
 *  · `createStandalone`：工厂替身 —— 想断言"到底建没建独立通道"时必须用它
 *    （注入现成实例的话，通道从第一秒就存在，看不出"有没有去构造"）；
 *  · `useDefaultStandalone: true`：故意走真实默认加载器（`lib/wechat-standalone.js`）。
 */
function makeHarness({
  rt, tools, sessionQuery, sessions, sessionTitle, throwOn, now, probeTtlMs,
  standalone, createStandalone,
} = {}) {
  const logs = []
  const traces = []
  const ctx = makeCtx({ wechatChannel: rt, tools, sessionQuery, sessions, sessionTitle }, { throwOn })
  const channel = standalone === undefined ? makeStandalone() : standalone
  const deps = {
    ctx,
    log: (level, message) => logs.push({ level, message }),
    debug: (event, data) => traces.push({ event, data }),
    ...(now === undefined ? {} : { now }),
    ...(probeTtlMs === undefined ? {} : { probeTtlMs }),
    newCallId: () => 'taskbar-wechat-test-call',
  }
  if (channel !== null) deps.standalone = channel
  if (createStandalone !== undefined) deps.createStandalone = createStandalone
  const notifier = createWechatNotifier(deps)
  return { notifier, ctx, logs, traces, standalone: channel }
}

/** 五道闸全过的环境。 */
function readyHarness(overrides = {}) {
  const rt = overrides.rt ?? makeRt()
  const tools = overrides.tools ?? makeTools()
  return makeHarness({
    rt,
    tools,
    sessionQuery: 'sessionQuery' in overrides ? overrides.sessionQuery : { readTitle: async () => ({ title: '任务栏进度条' }) },
    sessions: overrides.sessions,
    sessionTitle: overrides.sessionTitle,
    throwOn: overrides.throwOn,
    now: overrides.now,
    probeTtlMs: overrides.probeTtlMs,
  })
}

/* ------------------------------------------------------------------ 探测五道闸 */

console.log('微信提醒 · probe 五道闸')

await checkAsync('闸1：没有 wechatChannel 服务 → 未检测到插件', async () => {
  const { notifier } = makeHarness({ tools: makeTools() })
  const result = await notifier.probe()
  assert.equal(result.available, false)
  assert.equal(result.reason, '未检测到 dsh-wechat-plugin')
})

await checkAsync('闸2a：工具注册表里没有 notify_wechat → 不可用', async () => {
  const { notifier } = makeHarness({ rt: makeRt(), tools: makeTools({ hasNotify: false }) })
  const result = await notifier.probe()
  assert.equal(result.available, false)
  assert.equal(result.reason, '微信插件未提供 notify_wechat 工具')
})

await checkAsync('闸2b：tools 服务根本不存在 → 不可用（不抛）', async () => {
  const { notifier } = makeHarness({ rt: makeRt() })
  const result = await notifier.probe()
  assert.equal(result.available, false)
  assert.equal(result.reason, '微信插件未提供 notify_wechat 工具')
})

await checkAsync('闸3：跨会话通知被关闭 → 不可用（否则会被插件拒发）', async () => {
  const rt = makeRt({ settings: { allowCrossSessionNotify: false } })
  const { notifier } = makeHarness({ rt, tools: makeTools() })
  const result = await notifier.probe()
  assert.equal(result.available, false)
  assert.equal(result.reason, '微信插件的跨会话通知被关闭')
})

await checkAsync('闸3b：allowCrossSessionNotify 只认严格 true', async () => {
  for (const value of [undefined, 'true', 1, {}]) {
    const rt = makeRt({ settings: { allowCrossSessionNotify: value } })
    const { notifier } = makeHarness({ rt, tools: makeTools() })
    const result = await notifier.probe()
    assert.equal(result.available, false, `allowCrossSessionNotify=${JSON.stringify(value)} 应判不可用`)
  }
})

await checkAsync('闸4：没有已连接账号 → 不可用', async () => {
  const rt = makeRt({ accounts: [] })
  const { notifier } = makeHarness({ rt, tools: makeTools() })
  const result = await notifier.probe()
  assert.equal(result.available, false)
  assert.equal(result.reason, '微信插件未连接账号')
})

await checkAsync('五道闸全过 → available: true 且 reason 为空串', async () => {
  const { notifier } = readyHarness()
  const result = await notifier.probe()
  assert.equal(result.available, true)
  assert.equal(result.reason, '')
})

await checkAsync('探测失败不抛：settingsForPage / status / ctx.get 抛异常都被兜住', async () => {
  const boom = new Error('boom')
  const settingsFail = makeHarness({ rt: makeRt({ settingsThrows: boom }), tools: makeTools() })
  assert.equal((await settingsFail.notifier.probe()).reason, '读取微信插件设置失败')

  const statusFail = makeHarness({ rt: makeRt({ statusThrows: boom }), tools: makeTools() })
  assert.equal((await statusFail.notifier.probe()).reason, '读取微信插件连接状态失败')

  const oldVersion = makeHarness({ rt: makeRt({ includeSettingsForPage: false }), tools: makeTools() })
  assert.equal((await oldVersion.notifier.probe()).reason, '微信插件不支持读取设置（版本过旧）')

  const getThrows = makeHarness({ rt: makeRt(), tools: makeTools(), throwOn: ['wechatChannel', 'tools'] })
  const result = await getThrows.notifier.probe()
  assert.equal(result.available, false)
  assert.equal(result.reason, '未检测到 dsh-wechat-plugin')
})

/* ------------------------------------------------------------------ 缓存 */

console.log('\n微信提醒 · 探测缓存')

await checkAsync(`默认缓存时长为 30 秒（${DEFAULT_PROBE_TTL_MS}ms）`, async () => {
  assert.equal(DEFAULT_PROBE_TTL_MS, 30_000)
})

await checkAsync('probe() 缓存生效：连续两次探测只跑一遍底层', async () => {
  const rt = makeRt()
  const { notifier, ctx } = readyHarness({ rt })
  await notifier.probe()
  await notifier.probe()
  assert.equal(rt.calls.settingsForPage, 1, 'settingsForPage 只该被调用一次')
  assert.equal(rt.calls.status, 1, 'status 只该被调用一次')
  assert.equal(ctx.counts.get('wechatChannel'), 1, 'ctx.get 只该被调用一次')
})

await checkAsync('缓存对调用方是副本：改返回值不会污染缓存', async () => {
  const { notifier } = readyHarness()
  const first = await notifier.probe()
  first.available = false
  first.reason = '被外部改坏了'
  const second = await notifier.probe()
  assert.equal(second.available, true)
  assert.equal(second.reason, '')
})

await checkAsync('invalidate() 之后重新探测（缓存清空）', async () => {
  const rt = makeRt()
  const { notifier } = readyHarness({ rt })
  await notifier.probe()
  notifier.invalidate()
  await notifier.probe()
  assert.equal(rt.calls.settingsForPage, 2)
  assert.equal(rt.calls.status, 2)
})

await checkAsync('缓存会过期：超过 TTL 后重新探测', async () => {
  const rt = makeRt()
  let clock = 1_000
  const { notifier } = readyHarness({ rt, now: () => clock })
  await notifier.probe()
  clock += DEFAULT_PROBE_TTL_MS - 1
  await notifier.probe()
  assert.equal(rt.calls.status, 1, 'TTL 内不该重探')
  clock += 2
  await notifier.probe()
  assert.equal(rt.calls.status, 2, '超过 TTL 应重探')
})

await checkAsync('不可用的探测结果同样被缓存（避免每条提醒都跑五道闸）', async () => {
  const rt = makeRt({ accounts: [] })
  const { notifier, ctx } = readyHarness({ rt })
  await notifier.probe()
  await notifier.probe()
  assert.equal(ctx.counts.get('wechatChannel'), 1)
  assert.equal(rt.calls.settingsForPage, 1)
})

/* ------------------------------------------------------------------ 文案逐字 */

console.log('\n微信提醒 · 文案格式')

await checkAsync('done 文案逐字正确（含真实标题）', async () => {
  const tools = makeTools()
  const { notifier } = readyHarness({ tools })
  const ok = await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' })
  assert.equal(ok, true)
  assert.equal(tools.calls.length, 1)
  assert.equal(tools.calls[0].arguments.text, '您在任务栏进度条对话中的任务 已完成，请及时处理。')
})

await checkAsync('waiting 文案逐字正确（含真实标题）', async () => {
  const tools = makeTools()
  const { notifier } = readyHarness({ tools })
  const ok = await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'waiting' })
  assert.equal(ok, true)
  assert.equal(tools.calls[0].arguments.text, '您在任务栏进度条对话中的任务 等待选择，请及时处理。')
})

await checkAsync('调用形状符合宿主 ToolExecutionInput 约定（不带 agent，只带 text）', async () => {
  const tools = makeTools()
  const { notifier } = readyHarness({ tools })
  await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' })
  const exec = tools.calls[0]
  assert.equal(exec.name, WECHAT_NOTIFY_TOOL)
  assert.equal(exec.name, 'notify_wechat')
  assert.equal(typeof exec.callId, 'string')
  assert.ok(exec.callId.length > 0, 'callId 不能为空')
  assert.ok(exec.signal instanceof AbortSignal, 'signal 必须是 AbortSignal')
  assert.equal('agent' in exec, false, '按设计允许不带 agent 调用')
  assert.deepEqual(Object.keys(exec.arguments), ['text'], '工具 schema 是 additionalProperties:false')
})

await checkAsync('标题里的方括号原样保留（不被当成占位符吃掉）', async () => {
  const tools = makeTools()
  const { notifier } = readyHarness({
    tools,
    sessionQuery: { readTitle: async () => ({ title: '[重点] 修复登录' }) },
  })
  await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' })
  assert.equal(tools.calls[0].arguments.text, '您在[重点] 修复登录对话中的任务 已完成，请及时处理。')
})

await checkAsync('buildTaskNoticeText 是纯函数：空白标题 → 未知对话，未知 kind → undefined', async () => {
  assert.equal(buildTaskNoticeText({ title: '   ', kind: 'done' }), '您在未知对话对话中的任务 已完成，请及时处理。')
  assert.equal(buildTaskNoticeText({ title: undefined, kind: 'waiting' }), '您在未知对话对话中的任务 等待选择，请及时处理。')
  assert.equal(buildTaskNoticeText({ title: 'x', kind: 'whatever' }), undefined)
  assert.equal(UNKNOWN_SESSION_TITLE, '未知对话')
})

/* ------------------------------------------------------------------ 标题降级 */

console.log('\n微信提醒 · 标题降级')

await checkAsync('标题取不到 → 用"未知对话"兜底，并且仍然发送', async () => {
  const tools = makeTools()
  const { notifier } = readyHarness({ tools, sessionQuery: undefined, sessions: undefined, sessionTitle: undefined })
  const ok = await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' })
  assert.equal(ok, true, '取不到标题也必须发出去')
  assert.equal(tools.calls.length, 1)
  assert.equal(tools.calls[0].arguments.text, '您在未知对话对话中的任务 已完成，请及时处理。')
})

await checkAsync('sessionQuery.readTitle 抛异常 → 退到 sessions + sessionTitle', async () => {
  const tools = makeTools()
  const session = { id: 's-1' }
  const { notifier } = readyHarness({
    tools,
    sessionQuery: { readTitle: async () => { throw new Error('读标题失败') } },
    sessions: { get: () => session },
    sessionTitle: { get: () => ({ title: '备选标题' }) },
  })
  const ok = await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' })
  assert.equal(ok, true)
  assert.equal(tools.calls[0].arguments.text, '您在备选标题对话中的任务 已完成，请及时处理。')
})

await checkAsync('两级都取不到 → 未知对话（且不抛）', async () => {
  const tools = makeTools()
  const { notifier } = readyHarness({
    tools,
    sessionQuery: { readTitle: async () => undefined },
    sessions: { get: () => undefined },
    sessionTitle: { get: () => { throw new Error('也没有') } },
  })
  const ok = await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'waiting' })
  assert.equal(ok, true)
  assert.equal(tools.calls[0].arguments.text, '您在未知对话对话中的任务 等待选择，请及时处理。')
})

/* ------------------------------------------------------------------ 微信会话判据 */

console.log('\n微信提醒 · 微信会话排除')

const WECHAT_BINDINGS = [
  { conversationId: 'conv-1', sessionId: 's-wechat', title: '手机上的对话', peerId: 'peer-secret' },
  { conversationId: 'conv-2', sessionId: 's-wechat-2', title: '另一个对话' },
]

await checkAsync('isWechatSession：命中 bindings 里的 sessionId', async () => {
  const { notifier } = readyHarness({ rt: makeRt({ bindings: WECHAT_BINDINGS }) })
  assert.equal(await notifier.isWechatSession('s-wechat'), true)
  assert.equal(await notifier.isWechatSession('s-wechat-2'), true)
})

await checkAsync('isWechatSession：不命中普通会话 / 非法输入', async () => {
  const { notifier } = readyHarness({ rt: makeRt({ bindings: WECHAT_BINDINGS }) })
  assert.equal(await notifier.isWechatSession('s-desktop'), false)
  assert.equal(await notifier.isWechatSession(''), false)
  assert.equal(await notifier.isWechatSession(undefined), false)
  assert.equal(await notifier.isWechatSession(123), false)
})

await checkAsync('isWechatSession：bindings 抛异常 → 保守返回 false（不抛）', async () => {
  const { notifier, logs } = readyHarness({ rt: makeRt({ bindingsThrows: new Error('store 坏了') }) })
  assert.equal(await notifier.isWechatSession('s-wechat'), false)
  assert.ok(logs.some((entry) => entry.level === 'warn'), '应留下一条 warn 日志')
})

await checkAsync('微信会话自身不推送（任务栏提醒不应回声到同一个微信对话）', async () => {
  const tools = makeTools()
  const { notifier, traces } = readyHarness({ tools, rt: makeRt({ bindings: WECHAT_BINDINGS }) })
  const ok = await notifier.sendTaskNotice({ sessionId: 's-wechat', kind: 'done' })
  assert.equal(ok, false)
  assert.equal(tools.calls.length, 0, '微信会话不该触发 tools.execute')
  assert.ok(traces.some((entry) => entry.data?.reason === 'wechat-session'), '应留下 skip 诊断')
})

/* ------------------------------------------------------------------ 失败不抛 */

console.log('\n微信提醒 · 失败一律降级为 false')

await checkAsync('tools.execute 返回 isError:true → false 且有 warn 日志（不抛）', async () => {
  const tools = makeTools({
    result: {
      isError: true,
      error: { message: '当前绑定了 2 个微信对话，无法确定发给哪一个。' },
      content: [{ type: 'text', text: 'Error: 当前绑定了 2 个微信对话，无法确定发给哪一个。' }],
    },
  })
  const { notifier, logs } = readyHarness({ tools })
  const ok = await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' })
  assert.equal(ok, false)
  assert.ok(logs.some((entry) => entry.level === 'warn' && entry.message.includes('微信提醒发送被拒绝')), '失败要写 warn')
})

await checkAsync('isError 结果里没有 error.message 时退化读 content 文本', async () => {
  const tools = makeTools({ result: { isError: true, content: [{ type: 'text', text: 'Error: 还没有微信对话。' }] } })
  const { notifier, traces } = readyHarness({ tools })
  assert.equal(await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' }), false)
  const errorTrace = traces.find((entry) => entry.data?.stage === 'tool-error')
  assert.ok(errorTrace, '应留下 tool-error 诊断')
  assert.ok(errorTrace.data.detail.includes('还没有微信对话'), errorTrace.data.detail)
})

await checkAsync('tools.execute 抛异常 → false（不抛给调用方）', async () => {
  const tools = makeTools({ executeThrows: new Error('管子断了') })
  const { notifier, logs } = readyHarness({ tools })
  const ok = await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' })
  assert.equal(ok, false)
  assert.ok(logs.some((entry) => entry.level === 'warn' && entry.message.includes('管子断了')))
})

await checkAsync('tools.execute 返回 undefined → 视为失败（不谎报成功）', async () => {
  const { notifier } = readyHarness({ tools: makeTools({ noResult: true }) })
  assert.equal(await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' }), false)
})

await checkAsync('ctx.get("tools") 抛异常 → false（不抛）', async () => {
  // 闸 2 会先因 tools 取不到而判不可用，所以这里只验证"不抛且返回 false"
  const { notifier } = readyHarness({ throwOn: ['tools'] })
  assert.equal(await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' }), false)
})

await checkAsync('插件不可用时 sendTaskNotice 直接 false，且不调用 tools.execute', async () => {
  const tools = makeTools()
  const { notifier, logs } = readyHarness({ tools, rt: makeRt({ accounts: [] }) })
  assert.equal(await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' }), false)
  assert.equal(tools.calls.length, 0)
  assert.ok(logs.some((entry) => entry.message.includes('微信插件未连接账号')), 'warn 里要带原因')
})

await checkAsync('未知 kind → false，不发送也不抛', async () => {
  const tools = makeTools()
  const { notifier, logs } = readyHarness({ tools })
  assert.equal(await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'whatever' }), false)
  assert.equal(await notifier.sendTaskNotice({}), false)
  assert.equal(tools.calls.length, 0)
  assert.ok(logs.some((entry) => entry.message.includes('未知的提醒类型')))
})

/* ------------------------------------------------------------------ dispose 与隐私 */

console.log('\n微信提醒 · dispose 与日志隐私')

await checkAsync('dispose() 之后不再探测、不再发送', async () => {
  const rt = makeRt()
  const tools = makeTools()
  const { notifier } = readyHarness({ rt, tools })
  notifier.dispose()
  const result = await notifier.probe()
  assert.equal(result.available, false)
  assert.equal(result.reason, '提醒器已释放')
  assert.equal(await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' }), false)
  assert.equal(tools.calls.length, 0)
  assert.equal(rt.calls.status, 0, 'dispose 后不该再探测底层')
})

await checkAsync('日志不含账号 / peerId / contextToken 之类凭据', async () => {
  // bindings 里塞满凭据性字段，但目标会话是普通会话（不是微信会话），保证真的走到发送分支
  const rt = makeRt({
    bindings: [{ conversationId: 'conv-1', sessionId: 's-wechat', peerId: 'peer-secret', contextToken: 'token-secret' }],
  })
  const tools = makeTools({ result: { isError: true, error: { message: '发送被拒' }, content: [] } })
  const { notifier, logs, traces } = readyHarness({ tools, rt })
  await notifier.probe()
  await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' })
  const dump = JSON.stringify({ logs, traces })
  for (const secret of ['acct-secret-123', 'peer-secret', 'token-secret', 'u-1', 'conv-1']) {
    assert.ok(!dump.includes(secret), `日志不该出现 ${secret}`)
  }
  // 正文与标题可以打（排障需要），标题在诊断里应能看见
  assert.ok(dump.includes('任务栏进度条'), '标题应可出现在诊断日志里')
  assert.ok(logs.some((entry) => entry.message.includes('微信提醒发送被拒绝')), '失败原因要写进日志')
})

await checkAsync('log / debug 回调本身抛异常也不影响发送结果', async () => {
  const tools = makeTools()
  const ctx = makeCtx({ wechatChannel: makeRt(), tools, sessionQuery: { readTitle: async () => ({ title: 't' }) } })
  const notifier = createWechatNotifier({
    ctx,
    log: () => { throw new Error('日志炸了') },
    debug: () => { throw new Error('诊断日志炸了') },
  })
  assert.equal(await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' }), true)
})

/* ------------------------------------------------------------------ 第五道闸（v2.1.1 新增） */

console.log('\n微信提醒 · 闸5：是否存在已绑定的微信对话（v2.1.1 新增）')

await checkAsync('闸5：账号在线 + 有已绑定对话 → available: true，reason 为空串', async () => {
  const rt = makeRt({ bindings: [{ conversationId: 'conv-1', sessionId: 's-wechat', title: '手机上的对话' }] })
  const { notifier } = makeHarness({ rt, tools: makeTools() })
  const result = await notifier.probe()
  assert.equal(result.available, true)
  assert.equal(result.reason, '')
})

await checkAsync('闸5：bindings 为空 → 不可用，且提示"先用手机给机器人发一条消息"', async () => {
  // 真机现场就是这个形状：账号已登录、bindings 是空的 —— 老版本 probe() 答"可用"，
  // 用户一发送就静默失败（notify_wechat 返回"还没有微信对话…"），只能翻日志才知道。
  const rt = makeRt({ bindings: [] })
  const { notifier, traces } = makeHarness({ rt, tools: makeTools() })
  const result = await notifier.probe()
  assert.equal(result.available, false)
  assert.equal(result.reason, '微信里还没有对话，请先用手机给机器人发一条消息')
  assert.ok(
    traces.some((entry) => entry.event === 'wechat:probe' && entry.data.available === false),
    '应留下 available:false 的 wechat:probe 诊断',
  )
})

await checkAsync('闸5：bindings() 抛异常 → 不可用且是"读取失败"那条文案（不抛、不崩）', async () => {
  const rt = makeRt({ bindingsThrows: new Error('store 坏了') })
  const { notifier, traces } = makeHarness({ rt, tools: makeTools() })
  const result = await notifier.probe()
  assert.equal(result.available, false)
  assert.equal(result.reason, '读取微信会话绑定失败')
  assert.ok(traces.some((entry) => entry.event === 'wechat:probe-bindings-error'), '应留下读绑定失败的诊断')
})

await checkAsync('闸5：bindings() 返回怪东西 / 方法缺失 → 同样判"读取失败"（安全降级）', async () => {
  // 非数组 = 形状不对，归入"读取失败"而不是"确实没有对话"：两者要用户做的动作不同
  for (const weird of [null, {}, 'x', 42]) {
    const rt = makeRt({ bindings: weird })
    const { notifier } = makeHarness({ rt, tools: makeTools() })
    const result = await notifier.probe()
    assert.equal(result.available, false, `bindings=${JSON.stringify(weird)} 应判不可用`)
    assert.equal(result.reason, '读取微信会话绑定失败', `bindings=${JSON.stringify(weird)} 应是读取失败文案`)
  }
  // 插件版本过旧、根本没有 bindings 方法：同一句文案，且不抛
  const legacy = makeRt()
  delete legacy.bindings
  const { notifier } = makeHarness({ rt: legacy, tools: makeTools() })
  const result = await notifier.probe()
  assert.equal(result.available, false)
  assert.equal(result.reason, '读取微信会话绑定失败')
})

await checkAsync('闸5 排在账号闸之后：账号没连 + 也没有对话 → 先报"未连接账号"', async () => {
  const rt = makeRt({ accounts: [], bindings: [] })
  const { notifier } = makeHarness({ rt, tools: makeTools() })
  const result = await notifier.probe()
  assert.equal(result.available, false)
  assert.equal(result.reason, '微信插件未连接账号', '顺序反了就会先报"还没有对话"，把人引到错误的动作上')
  assert.equal(rt.calls.bindings, 0, '账号闸没过就不该再去读绑定（这也是顺序的证据）')
})

await checkAsync('闸5 的结论也进 30 秒缓存：连探两次只读一次 bindings', async () => {
  const rt = makeRt({ bindings: [] })
  const { notifier } = makeHarness({ rt, tools: makeTools() })
  const first = await notifier.probe()
  const second = await notifier.probe()
  assert.deepEqual(second, first)
  assert.equal(second.reason, '微信里还没有对话，请先用手机给机器人发一条消息')
  assert.equal(rt.calls.bindings, 1, '不可用也要缓存，别每条提醒都去读一次绑定')
})

/* ─────────────────── v2.2.0：独立连接（两条可插拔通道） ─────────────────── */

console.log('\n微信提醒 · v2.2.0 通道选择（联动 ↔ 独立）')

/** 造一个"联动不可用"的五道闸现场：没装插件是最常见的一种。 */
const noLinked = () => makeHarness({ tools: makeTools() })

await checkAsync('通道选择：联动可用 → mode=linked，且**完全不去构造**独立通道', async () => {
  const built = []
  const { notifier } = makeHarness({
    rt: makeRt(),
    tools: makeTools(),
    sessionQuery: { readTitle: async () => ({ title: '任务栏进度条' }) },
    // 故意**不注入**现成实例，只给工厂：这样"建没建"才看得出来
    standalone: null,
    createStandalone: () => {
      built.push(1)
      return makeStandalone()
    },
  })
  const result = await notifier.probe()
  assert.equal(result.available, true)
  assert.equal(result.mode, NOTIFY_MODE_LINKED)
  assert.deepEqual(result.linked, { available: true, reason: '' })
  assert.equal(result.standalone, null, '联动可用时不该报独立通道状态（它压根没被建起来）')
  assert.deepEqual(built, [], '"有联动插件就委托它"：不许偷偷建第二条连接')
})

await checkAsync('通道选择：联动不可用 + 独立未连接 → mode=standalone、available=false，但相位可见', async () => {
  const channel = makeStandalone({ phase: 'disconnected', connected: false })
  const { notifier } = makeHarness({ ...noLinked(), standalone: channel })
  const result = await notifier.probe()
  assert.equal(result.available, false, '还没连上就是发不出去')
  assert.equal(result.mode, NOTIFY_MODE_STANDALONE, 'UI 靠 mode 决定显示「连接微信」而不是"本节无法开启"')
  assert.equal(result.reason, '未检测到 dsh-wechat-plugin', 'reason 语义不变：仍是"为什么不能用联动"')
  assert.equal(result.linked.available, false, 'linked 里保留联动那五道闸的原始结论')
  assert.equal(result.standalone.phase, 'disconnected', 'UI 据此显示"未连接"')
  assert.equal(result.standaloneReady, true)
  assert.equal(result.standaloneError, '')
})

await checkAsync('通道选择：联动不可用 + 独立已连接 → available=true、mode=standalone、reason 归空', async () => {
  const channel = makeStandalone({ phase: 'connected', connected: true, accountId: 'acct-1' })
  const { notifier } = makeHarness({ ...noLinked(), standalone: channel })
  const result = await notifier.probe()
  assert.equal(result.available, true, '独立连上了就是能发')
  assert.equal(result.mode, NOTIFY_MODE_STANDALONE)
  assert.equal(result.reason, '', '能发就没有"不可用原因"')
  assert.equal(result.linked.reason, '未检测到 dsh-wechat-plugin', '"为什么没用联动"仍然查得到')
  assert.equal(result.standalone.connected, true)
})

await checkAsync('通道选择：独立通道建不起来（模块缺失/构造抛错）→ 安全降级，只试一次', async () => {
  let attempts = 0
  const { notifier, traces } = makeHarness({
    ...noLinked(),
    standalone: null,
    createStandalone: () => {
      attempts += 1
      throw new Error("Cannot find module './wechat-standalone.js'")
    },
  })
  const first = await notifier.probe()
  assert.equal(first.available, false)
  assert.equal(first.mode, NOTIFY_MODE_STANDALONE)
  assert.equal(first.standalone, null)
  assert.equal(first.standaloneReady, false)
  assert.ok(first.standaloneError.includes('wechat-standalone.js'), `要带上是哪一步失败：${first.standaloneError}`)
  notifier.invalidate()
  await notifier.probe()
  assert.equal(attempts, 1, '失败也只尝试一次：不该每条提醒都去 import 一次不存在的模块')
  assert.ok(traces.some((entry) => entry.event === 'wechat:standalone-error'), '应留下 standalone-error 诊断')
})

await checkAsync('通道选择：probe() 的嵌套对象是副本（改它不会污染下一次探测）', async () => {
  const channel = makeStandalone({ phase: 'connected', connected: true })
  const { notifier } = makeHarness({ ...noLinked(), standalone: channel })
  const first = await notifier.probe()
  first.linked.available = true
  first.linked.reason = '被改坏了'
  first.standalone.phase = '被改坏了'
  const second = await notifier.probe()
  assert.equal(second.linked.available, false)
  assert.equal(second.linked.reason, '未检测到 dsh-wechat-plugin')
  assert.equal(second.standalone.phase, 'connected')
})

await checkAsync('通道选择：独立通道的状态每次现取（不跟着联动的 30 秒缓存一起陈旧）', async () => {
  const channel = makeStandalone({ phase: 'disconnected', connected: false })
  const { notifier } = makeHarness({ ...noLinked(), standalone: channel })
  await notifier.probe()
  // 界面刚点了「连接微信」：通道自己的相位已经变成"等待扫码"
  channel.state.phase = 'awaiting-scan'
  channel.state.qrContent = 'https://liteapp.weixin.qq.com/q/abc?qrcode=deadbeef'
  const again = await notifier.probe()
  assert.equal(again.standalone.phase, 'awaiting-scan', '独立状态必须现取，否则点完连接看不到二维码')
  assert.equal(again.standalone.qrContent, 'https://liteapp.weixin.qq.com/q/abc?qrcode=deadbeef')
})

console.log('\n微信提醒 · v2.2.0 独立通道发送')

await checkAsync('独立发送：走 channel.sendTaskNotice({title, kind})，不碰 notify_wechat 工具', async () => {
  const tools = makeTools()
  const channel = makeStandalone({ phase: 'connected', connected: true })
  const { notifier } = makeHarness({
    rt: undefined,
    tools,
    sessionQuery: { readTitle: async () => ({ title: '任务栏进度条' }) },
    standalone: channel,
  })
  const ok = await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' })
  assert.equal(ok, true)
  assert.equal(tools.calls.length, 0, '独立模式下不该再去调联动插件的工具')
  assert.deepEqual(channel.calls.send, [{ title: '任务栏进度条', kind: 'done' }])
  // 文案契约（对接检查）：独立通道用它收到的 title/kind 拼出来的话必须与需求原文逐字一致
  assert.equal(
    buildTaskNoticeText(channel.calls.send[0]),
    '您在任务栏进度条对话中的任务 已完成，请及时处理。',
    '独立通道按契约自己拼文案 —— 它必须与联动通道逐字相同（联调时对着 wechat-standalone.js 再验一次）',
  )
})

await checkAsync('独立发送：取不到标题时把「未知对话」交给独立通道（与联动一致）', async () => {
  const channel = makeStandalone({ phase: 'connected', connected: true })
  const { notifier } = makeHarness({ rt: undefined, tools: makeTools(), standalone: channel })
  assert.equal(await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'waiting' }), true)
  assert.deepEqual(channel.calls.send, [{ title: UNKNOWN_SESSION_TITLE, kind: 'waiting' }])
  assert.equal(
    buildTaskNoticeText(channel.calls.send[0]),
    '您在未知对话对话中的任务 等待选择，请及时处理。',
  )
})

await checkAsync('独立发送：通道回 ok:false → false + warn 带原因 + 诊断（不静默失败）', async () => {
  const channel = makeStandalone({
    phase: 'connected',
    connected: true,
    sendResult: { ok: false, error: '会话已超时，请先在微信里给机器人发一条消息' },
  })
  const { notifier, logs, traces } = makeHarness({ rt: undefined, tools: makeTools(), standalone: channel })
  assert.equal(await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' }), false)
  assert.ok(logs.some((entry) => entry.level === 'warn' && entry.message.includes('会话已超时')), `失败原因要进 warn：${JSON.stringify(logs)}`)
  const trace = traces.find((entry) => entry.data?.stage === 'standalone')
  assert.ok(trace, '应留下 standalone 发送失败的诊断')
  assert.ok(trace.data.detail.includes('会话已超时'))
})

await checkAsync('独立发送：通道抛异常 → false（不抛给调用方）', async () => {
  const channel = makeStandalone({ phase: 'connected', connected: true, sendThrows: new Error('管子断了') })
  const { notifier, logs } = makeHarness({ rt: undefined, tools: makeTools(), standalone: channel })
  assert.equal(await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' }), false)
  assert.ok(logs.some((entry) => entry.level === 'warn' && entry.message.includes('管子断了')))
})

await checkAsync('独立发送：还没连上时直接 false，一个字节都不发', async () => {
  const channel = makeStandalone({ phase: 'awaiting-scan', connected: false })
  const { notifier, logs } = makeHarness({ rt: undefined, tools: makeTools(), standalone: channel })
  assert.equal(await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' }), false)
  assert.deepEqual(channel.calls.send, [])
  assert.ok(logs.some((entry) => entry.message.includes('微信提醒不可用')))
})

await checkAsync('最近一次错误：发送失败会进 probe().lastError，成功发送会清空', async () => {
  const channel = makeStandalone({
    phase: 'connected',
    connected: true,
    sendResult: { ok: false, error: '微信会话已超时' },
  })
  const { notifier } = makeHarness({ rt: undefined, tools: makeTools(), standalone: channel })
  assert.equal(await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' }), false)
  const failed = await notifier.probe()
  assert.equal(failed.lastError, '微信会话已超时', '设置界面要能看见"最近一次错误"，否则就是静默失败')

  channel.state.connected = true
  const ok = makeStandalone({ phase: 'connected', connected: true })
  const second = makeHarness({ rt: undefined, tools: makeTools(), standalone: ok, createStandalone: undefined })
  await second.notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' })
  assert.equal((await second.notifier.probe()).lastError, '', '成功发送后旧错误必须清掉')
})

console.log('\n微信提醒 · v2.2.0 独立通道控制面（登录/验证码/取消/断开）')

await checkAsync('控制面：startLogin 转发并按相位回报；成功后探测缓存立即作废', async () => {
  const channel = makeStandalone({ loginResult: { ok: true, phase: 'awaiting-scan' } })
  const rt = makeRt({ accounts: [] }) // 联动不可用，逼出独立通道
  const { notifier, ctx } = makeHarness({ rt, tools: makeTools(), standalone: channel })
  await notifier.probe()
  const before = ctx.counts.get('wechatChannel')
  const result = await notifier.startLogin()
  assert.deepEqual(result, { ok: true, phase: 'awaiting-scan' })
  assert.equal(channel.calls.startLogin, 1)
  // 点完「连接微信」必须立刻能看到新相位：探测缓存被作废 → 下一次 probe 重新跑五道闸
  await notifier.probe()
  assert.equal(ctx.counts.get('wechatChannel'), before + 1, 'startLogin 之后缓存要失效')
})

await checkAsync('控制面：startLogin **不等待整条登录流程**（否则界面永远看不到二维码）', async () => {
  // 真交付代码的 startLogin() 会 await 到"扫码完成/失败/5 分钟超时"才 settle。
  // 如果本插件 await 它，设置界面点完「连接微信」那个 fetch 会一直挂着 —— 二维码永远不出现。
  let release
  const hanging = makeStandalone()
  hanging.startLogin = () => new Promise((resolve) => {
    release = resolve
  })
  // 通道的 status() 很快变成"等待扫码"（真机就是这样：先拿到二维码，再等用户扫）
  hanging.status = () => {
    hanging.calls.status += 1
    return { ...hanging.state, phase: release === undefined ? 'connecting' : 'awaiting-scan', qrContent: 'https://x/qr' }
  }
  const { notifier } = makeHarness({ rt: makeRt({ accounts: [] }), tools: makeTools(), standalone: hanging })
  const started = await notifier.startLogin({ waitMs: 500 })
  assert.equal(started.ok, true)
  assert.equal(started.phase, 'awaiting-scan', '拿到二维码就该返回，而不是等用户扫完')
  assert.equal(notifier.standaloneStatus().qrContent, 'https://x/qr')
  assert.equal(typeof release, 'function', '后台那条登录 Promise 还在跑（这是对的）')
  release({ ok: true, phase: 'connected' }) // 收尾，别把 Promise 晾着
})

await checkAsync('控制面：刷新二维码时"先取消再登录"不会撞上还在收尾的旧登录（pending 重试）', async () => {
  // 真交付代码在"上一条登录还在收尾"时会回 {pending:true}（拒绝起第二条轮询），
  // 而 cancelLogin() 到那条 Promise 的 finally 之间隔着一个事件循环。
  const calls = []
  const channel = makeStandalone()
  channel.startLogin = async () => {
    calls.push(calls.length)
    // 第一次：撞上旧登录的收尾 → pending；第二次：正常开始
    return calls.length === 1 ? { ok: false, phase: 'disconnected', pending: true } : { ok: true, phase: 'awaiting-scan' }
  }
  const { notifier } = makeHarness({ rt: makeRt({ accounts: [] }), tools: makeTools(), standalone: channel })
  const result = await notifier.startLogin({ waitMs: 800 })
  assert.equal(calls.length, 2, '第一次拿到 pending 之后要再踢一次')
  assert.equal(result.ok, true, `刷新应当真的重新开始登录：${JSON.stringify(result)}`)
  assert.equal(result.phase, 'awaiting-scan')
})

await checkAsync('控制面：startLogin 失败 / 抛错都回 {ok:false,error}（不抛）', async () => {
  const failing = makeStandalone({ loginResult: { ok: false, error: '网络不可用' } })
  const first = makeHarness({ rt: makeRt({ accounts: [] }), tools: makeTools(), standalone: failing })
  const failed = await first.notifier.startLogin()
  assert.equal(failed.ok, false)
  assert.equal(failed.error, '网络不可用')

  const throwing = makeStandalone({ startLoginThrows: new Error('DNS 挂了') })
  const second = makeHarness({ rt: makeRt({ accounts: [] }), tools: makeTools(), standalone: throwing })
  const result = await second.notifier.startLogin()
  assert.equal(result.ok, false)
  assert.equal(result.error, 'DNS 挂了')
})

await checkAsync('控制面：provideVerifyCode 原样转发、返回 boolean；通道不在时返回 false', async () => {
  const channel = makeStandalone()
  const { notifier } = makeHarness({ rt: makeRt({ accounts: [] }), tools: makeTools(), standalone: channel })
  assert.equal(notifier.provideVerifyCode('4321'), true)
  assert.deepEqual(channel.calls.verify, ['4321'], '验证码原样交给通道（路由那一层才做 trim）')

  const notAccepted = makeStandalone({ verifyResult: false })
  const rejecting = makeHarness({ rt: makeRt({ accounts: [] }), tools: makeTools(), standalone: notAccepted })
  assert.equal(rejecting.notifier.provideVerifyCode('0000'), false)

  // 通道还没建起来（模块缺失）：提交验证码没有意义，返回 false 且不抛
  const none = makeHarness({ ...noLinked(), standalone: null, createStandalone: () => { throw new Error('模块缺失') } })
  assert.equal(none.notifier.provideVerifyCode('1234'), false)
  assert.equal(none.notifier.provideVerifyCode(), false)
})

await checkAsync('控制面：cancelLogin / disconnect 转发；disconnect 失败也是 {ok:false,error}', async () => {
  const channel = makeStandalone({ phase: 'connected', connected: true })
  const { notifier } = makeHarness({ rt: makeRt({ accounts: [] }), tools: makeTools(), standalone: channel })
  notifier.cancelLogin()
  assert.equal(channel.calls.cancel, 1)
  assert.deepEqual(await notifier.disconnect(), { ok: true })
  assert.equal(channel.calls.disconnect, 1)

  const failing = makeStandalone({ disconnectThrows: new Error('凭据文件删不掉') })
  const second = makeHarness({ rt: makeRt({ accounts: [] }), tools: makeTools(), standalone: failing })
  const result = await second.notifier.disconnect()
  assert.equal(result.ok, false)
  assert.equal(result.error, '凭据文件删不掉')
})

await checkAsync('控制面：dispose() 会把独立通道一起释放，之后不再探测', async () => {
  const channel = makeStandalone({ phase: 'connected', connected: true })
  const rt = makeRt()
  const { notifier } = makeHarness({ rt, tools: makeTools(), standalone: channel })
  notifier.dispose()
  assert.equal(channel.calls.disposed, 1, '宿主停用时独立通道也要 dispose（别留下长轮询）')
  const result = await notifier.probe()
  assert.equal(result.available, false)
  assert.equal(result.reason, '提醒器已释放')
  assert.equal(rt.calls.status, 0)
})

await checkAsync('日志隐私（独立模式）：accountId / peerId 不进 log / debug', async () => {
  const channel = makeStandalone({
    phase: 'connected',
    connected: true,
    accountId: 'acct-secret-999',
    peerId: 'peer-secret-999',
  })
  const { notifier, logs, traces } = makeHarness({ rt: undefined, tools: makeTools(), standalone: channel })
  await notifier.probe()
  await notifier.startLogin()
  await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' })
  const dump = JSON.stringify({ logs, traces })
  assert.ok(!dump.includes('acct-secret-999'), '账号 id 不该进日志')
  assert.ok(!dump.includes('peer-secret-999'), 'peerId 不该进日志')
  // 但状态本身要能通过 probe() 拿到（设置界面要显示"已连接"）
  assert.equal((await notifier.probe()).standalone.accountId, 'acct-secret-999')
})

console.log('\n微信提醒 · v2.2.0 二维码渲染（qrcode_img_content 的真实格式）')

await checkAsync('二维码：payload 是要被编码的文本（真实值是 URL），渲染器拿到的就是它', async () => {
  const seen = []
  setQrRenderer(async (payload) => {
    seen.push(payload)
    return 'data:image/png;base64,AAAA'
  })
  // 本机只读探针实测的真实形状：一段 https URL，不是 data URL、也不是图片地址
  const payload = 'https://liteapp.weixin.qq.com/q/7GiQu1?qrcode=957c551a7c95957e8434ddc183e95f70&bot_type=3'
  const image = await renderQrDataUrl(payload)
  assert.equal(image, 'data:image/png;base64,AAAA')
  assert.deepEqual(seen, [payload], '渲染器收到的必须是原始 payload 字符串')
  setQrRenderer(null)
})

await checkAsync('二维码：同一张 payload 只编码一次（缓存），空 payload / 渲染失败都回 null', async () => {
  let calls = 0
  setQrRenderer(async () => {
    calls += 1
    return 'data:image/png;base64,BBBB'
  })
  assert.equal(await renderQrDataUrl('https://example.com/q/1'), 'data:image/png;base64,BBBB')
  assert.equal(await renderQrDataUrl('https://example.com/q/1'), 'data:image/png;base64,BBBB')
  assert.equal(calls, 1, '同一张二维码不重复编码')

  assert.equal(await renderQrDataUrl(''), null, '空 payload 直接 null')
  assert.equal(await renderQrDataUrl(undefined), null)
  setQrRenderer(async () => {
    throw new Error('qrcode 解析不到')
  })
  assert.equal(await renderQrDataUrl('https://example.com/q/2'), null, '渲染失败不能抛，返回 null 让界面降级')
  setQrRenderer(null)
})

/* ───────────── v2.2.0 联调：真的用交付方的三个模块（离线、临时目录） ───────────── */

console.log('\n微信提醒 · v2.2.0 联调（真 wechat-standalone / wechat-store / wechat-proto）')

// 这一节**故意不注入替身**：走的就是 `lib/wechat.js` 的默认加载路径
// （动态 import './wechat-standalone.js' + './wechat-store.js'）+ 真的交付代码。
// 三条安全线，一条都不能松：
//   1. **没有网络**：`fetchImpl` 是假的，只认识 get_bot_qrcode / get_qrcode_status / sendmessage；
//   2. **没有真实文件系统**：store 用临时目录（`createWechatStore({ dir })`），
//      绝不会碰到用户真实的 ~/.dsh/wechat/standalone.json；
//   3. **不真的等待**：`sleep` 注入成空实现。
// 这份联调验证的是"两边接口真的对得上"：工厂名、参数名、status() 字段、
// 以及**最重要的**——独立通道拼出来的文案与需求逐字一致。

/** 造一份"只认我们这三个端点"的假服务端。 */
function makeWechatServer() {
  const calls = []
  let qrCount = 0
  let confirmed = false
  /** 'wait' = 一直回 wait（配合 park 用）；'park' = 挂住不返回（只在取消时中断） */
  let pollMode = 'wait'
  const fetchImpl = async (url, init = {}) => {
    calls.push({ url: String(url), method: init.method ?? 'GET', body: init.body })
    const target = String(url)
    const json = (value) => ({
      ok: true,
      status: 200,
      text: async () => JSON.stringify(value),
      json: async () => value,
    })
    if (target.includes('get_bot_qrcode')) {
      qrCount += 1
      return json({
        ret: 0,
        qrcode: `qr-${qrCount}`,
        qrcode_img_content: `https://liteapp.weixin.qq.com/q/test${qrCount}?qrcode=qr-${qrCount}&bot_type=3`,
      })
    }
    if (target.includes('get_qrcode_status')) {
      if (confirmed) {
        return json({
          status: 'confirmed',
          ilink_bot_id: 'bot-abc',
          bot_token: 'token-abc',
          baseurl: 'https://ilinkai.weixin.qq.com',
          ilink_user_id: 'user-abc',
        })
      }
      if (pollMode === 'park') {
        // 挂住这一轮轮询（真机上服务端会 hold 请求）：只在被取消时中断。
        // 这样"停在 awaiting-scan 的现场"是可复现的，而且**不会空转**。
        return await new Promise((resolve, reject) => {
          const signal = init.signal
          const abort = () => {
            const error = new Error('aborted')
            error.name = 'AbortError'
            reject(error)
          }
          if (signal?.aborted === true) abort()
          else signal?.addEventListener?.('abort', abort, { once: true })
          void resolve
        })
      }
      return json({ status: 'wait' })
    }
    if (target.includes('sendmessage')) {
      return json({ errcode: 0, errmsg: 'ok', message_id: '1' })
    }
    throw new Error(`联调假服务端不认识这个 URL：${target}`)
  }
  return {
    fetchImpl,
    calls,
    confirmLogin: () => {
      confirmed = true
    },
    parkPoll: () => {
      pollMode = 'park'
    },
    qrUrl: (index = 1) => `https://liteapp.weixin.qq.com/q/test${index}?qrcode=qr-${index}&bot_type=3`,
  }
}

/** 临时目录里的真 store（用完删掉；绝不碰用户真实目录）。 */
async function makeTempStore() {
  const { mkdtempSync, rmSync } = await import('node:fs')
  const { tmpdir } = await import('node:os')
  const { join } = await import('node:path')
  const { createWechatStore } = await import('../lib/wechat-store.js')
  const dir = mkdtempSync(join(tmpdir(), 'dsh-taskbar-wechat-'))
  const store = createWechatStore({ dir })
  return { dir, store, cleanup: () => { try { rmSync(dir, { recursive: true, force: true }) } catch { /* 清理失败不影响断言 */ } } }
}

/** 用真模块组装一个提醒器（无联动插件 ⇒ probe() 会真的去构造独立通道）。 */
async function makeIntegrationHarness(options = {}) {
  const temp = await makeTempStore()
  const server = makeWechatServer()
  const logs = []
  const traces = []
  const nowMs = 1_000_000
  const notifier = createWechatNotifier({
    // 没有 wechatChannel：联动不可用；给个会话标题源，好断言语义里的标题
    ctx: makeCtx({
      tools: makeTools(),
      sessionQuery: { readTitle: async () => ({ title: '任务栏进度条' }) },
    }),
    log: (level, message) => logs.push({ level, message }),
    debug: (event, data) => traces.push({ event, data }),
    now: () => nowMs,
    standaloneStore: temp.store,
    standaloneFetch: server.fetchImpl,
    // 轮询之间的等待：给个空实现，但**必须让出一轮微任务**，否则登录循环会把事件循环卡死
    standaloneSleep: async () => {},
    ...(options.notifier ?? {}),
  })
  return { notifier, server, temp, logs, traces }
}

await checkAsync('联调：默认加载路径真的能建起独立通道（工厂名/参数名对得上）', async () => {
  const { notifier, temp } = await makeIntegrationHarness()
  try {
    const result = await notifier.probe()
    assert.equal(result.mode, NOTIFY_MODE_STANDALONE, '没有联动插件 → 走独立')
    assert.equal(result.standaloneReady, true, `独立通道要建得起来：${result.standaloneError}`)
    assert.equal(result.available, false, '还没登录 → 不能发')
    assert.equal(result.standalone.phase, 'disconnected')
    assert.equal(typeof result.standalone.connected, 'boolean')
    assert.equal(typeof result.standalone.qrContent, 'string')
    // 账号/peerId 还没连上时是空串（快照是规整过的，不是 undefined）
    assert.equal(result.standalone.accountId, '')
    assert.equal(result.standalone.peerId, '')
  } finally {
    notifier.dispose()
    temp.cleanup()
  }
})

await checkAsync('联调：startLogin 立刻返回并能看到 awaiting-scan（不等用户扫完），二维码就是服务端给的 URL', async () => {
  const { notifier, server, temp } = await makeIntegrationHarness()
  try {
    // 让轮询"挂住"：这样能稳定地观察 awaiting-scan 这个现场，而且不会空转
    server.parkPoll()
    // ⚠️ 这一行本身就是断言：真交付代码的 startLogin() 会 await 到扫码完成才 settle，
    // 本插件若 await 它，这里就会一直挂着（界面也就永远看不到二维码）。
    const started = await notifier.startLogin()
    assert.equal(started.ok, true, `登录应立刻开始并给出相位：${JSON.stringify(started)}`)
    assert.equal(started.phase, 'awaiting-scan', '拿到二维码就该返回')

    const snapshot = notifier.standaloneStatus()
    assert.equal(snapshot.phase, 'awaiting-scan', `真实现场应是等待扫码：${JSON.stringify(snapshot)}`)
    assert.equal(snapshot.qrContent, server.qrUrl(1), 'qrContent 就是服务端的 qrcode_img_content（真实格式：URL）')
    assert.equal(snapshot.connected, false)
    assert.ok(server.calls.some((call) => call.url.includes('get_bot_qrcode')), '必须真的去取二维码')

    // 二维码能被渲染成 <img src> 能吃的 data URL（profile 里 hoisted 的 qrcode；
    // workspace 里解析不到时回 null —— 两种都算通过，界面会降级显示原文）
    const image = await renderQrDataUrl(snapshot.qrContent)
    assert.ok(image === null || image.startsWith('data:image/'), `渲染结果要么是 data URL 要么是 null：${String(image).slice(0, 30)}`)

    // 取消：真的能把登录收口（不是把 Promise 晾着）
    notifier.cancelLogin()
    await new Promise((resolve) => setTimeout(resolve, 20))
    assert.notEqual(notifier.standaloneStatus().phase, 'awaiting-scan', '取消后不该还停在等待扫码')
  } finally {
    notifier.dispose()
    temp.cleanup()
  }
})

await checkAsync('联调：扫码确认 → 通道进 connected 并把凭据落进本插件自己的文件', async () => {
  const { notifier, server, temp } = await makeIntegrationHarness()
  try {
    server.confirmLogin()
    const started = await notifier.startLogin()
    assert.equal(started.ok, true, `扫码确认后应登录成功：${JSON.stringify(started)}`)
    assert.equal(started.phase, 'connected')
    assert.equal(temp.store.credentialsExist(), true, '连上之后凭据要落到本插件的 standalone.json（不是共享 state.json）')

    const result = await notifier.probe()
    assert.equal(result.available, true)
    assert.equal(result.mode, NOTIFY_MODE_STANDALONE)
    assert.equal(result.standalone.connected, true)
    assert.equal(result.standalone.phase, 'connected')
    assert.equal(result.standalone.accountId, 'bot-abc', 'accountId 要能从真 store 读回来')
  } finally {
    notifier.dispose()
    temp.cleanup()
  }
})

await checkAsync('联调：已连接 + 已绑定对话 → 独立通道发出的话与需求**逐字**一致', async () => {
  const { notifier, server, temp } = await makeIntegrationHarness()
  try {
    // 直接种一份凭据（等价于"上次扫码连上过"）：真 store 会读到它 → connected + peerId
    const saved = temp.store.saveCredentials({
      account: { accountId: 'bot-abc', token: 'token-abc', baseUrl: 'https://ilinkai.weixin.qq.com' },
      peerId: 'peer-abc',
      conversationId: 'conv-abc',
      contextToken: 'ctx-abc',
    })
    assert.equal(saved, true, '凭据要写得进去（临时目录）')

    const probe = await notifier.probe()
    assert.equal(probe.available, true, `种了凭据就该是已连接：${JSON.stringify(probe.standalone)}`)
    assert.equal(probe.mode, NOTIFY_MODE_STANDALONE)
    assert.equal(probe.standalone.phase, 'connected')
    assert.equal(probe.standalone.accountId, 'bot-abc')

    assert.equal(await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'done' }), true)
    assert.equal(await notifier.sendTaskNotice({ sessionId: 's-1', kind: 'waiting' }), true)

    const sends = server.calls.filter((call) => call.url.includes('sendmessage'))
    assert.equal(sends.length, 2, '两条提醒应各发一条')
    // 线上形状：{ msg: { to_user_id, item_list: [{ type: 1, text_item: { text } }], context_token } }
    const texts = sends.map((call) => JSON.parse(call.body)?.msg?.item_list?.[0]?.text_item?.text)
    assert.deepEqual(
      texts,
      [
        '您在任务栏进度条对话中的任务 已完成，请及时处理。',
        '您在任务栏进度条对话中的任务 等待选择，请及时处理。',
      ],
      `独立通道拼出来的文案必须与需求逐字一致，实际：${JSON.stringify(texts)}`,
    )
    // 半角空格 / 全角逗号 / 句末句号：逐字符再钉一遍（防"看起来一样"）
    assert.equal(texts[0].includes('任务 已完成，请及时处理。'), true)
    assert.equal(texts[0].charCodeAt(texts[0].indexOf('任务 ') + 2), 0x20, '状态词前必须是半角空格 U+0020')
    assert.equal(texts[0].endsWith('。'), true, '句末必须是 U+3002')
    assert.equal(texts[0].includes('，'), true, '逗号必须是全角 U+FF0C')
  } finally {
    notifier.dispose()
    temp.cleanup()
  }
})

await checkAsync('联调：断开只清本插件自己的凭据文件（共享 state.json 一个字节都不碰）', async () => {
  const { mkdtempSync, rmSync, existsSync, writeFileSync, readFileSync } = await import('node:fs')
  const { tmpdir } = await import('node:os')
  const { join } = await import('node:path')
  const { createWechatStore } = await import('../lib/wechat-store.js')
  const dir = mkdtempSync(join(tmpdir(), 'dsh-taskbar-wechat-shared-'))
  try {
    // 造一份"联动插件的 state.json"（只读共享文件），里面塞一个哨兵值
    const shared = join(dir, 'state.json')
    const sharedText = JSON.stringify({ version: 1, sentinel: '联动插件的凭据，谁都不许动' })
    writeFileSync(shared, sharedText, 'utf8')

    const store = createWechatStore({ dir })
    store.saveCredentials({
      account: { accountId: 'bot-abc', token: 'token-abc' },
      peerId: 'peer-abc',
      contextToken: 'ctx-abc',
    })
    assert.ok(existsSync(join(dir, 'standalone.json')), '独立凭据写在 standalone.json')

    const notifier = createWechatNotifier({
      ctx: makeCtx({ tools: makeTools() }),
      log: () => {},
      debug: () => {},
      standaloneStore: store,
      standaloneFetch: makeWechatServer().fetchImpl,
      standaloneSleep: async () => {},
    })
    await notifier.probe()
    const result = await notifier.disconnect()
    assert.equal(result.ok, true)
    assert.equal(notifier.standaloneStatus().connected, false)
    assert.equal(existsSync(join(dir, 'standalone.json')), false, '断开要清掉本插件自己的凭据')
    assert.equal(readFileSync(shared, 'utf8'), sharedText, '共享 state.json 必须原封不动')
    notifier.dispose()
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
})

console.log(`\nwechat: ${passed} 项全部通过\n`)
