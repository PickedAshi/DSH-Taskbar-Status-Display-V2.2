/**
 * 微信 openclaw 独立连接 · **协议层**单测。
 *
 * 全部离线：`fetchImpl` 注入，不联网、不 spawn、不发真消息。
 *   node test/wechat-proto.test.mjs
 */

import assert from 'node:assert/strict'
import {
  APP_CLIENT_VERSION,
  APP_ID,
  AUTH_TYPE,
  BOT_TYPE,
  FIXED_BASE_URL,
  MAX_LOCAL_TOKENS,
  QR_FETCH_TIMEOUT_MS,
  QR_POLL_TIMEOUT_MS,
  WINDOW_CLOSED_ERRCODE,
  buildCommonHeaders,
  buildPostHeaders,
  fetchQRCode,
  pollQRStatus,
  sendText,
} from '../lib/wechat-proto.js'

let passed = 0
const check = (label, fn) => {
  fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}
const checkAsync = async (label, fn) => {
  await fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

/* ------------------------------------------------------------------ 假 fetch */

/**
 * 假 fetch：记录每次调用的 url / method / headers / body。
 * handler 返回 `{status, body}` / `{status, text}` / `{jsonThrows:true}` / 一个 Error（抛出），
 * 也可以返回一个"直到 signal abort 才 reject"的 Promise（用于测超时）。
 */
function makeFetch(handler) {
  const calls = []
  const fetchImpl = async (url, init = {}) => {
    // 真 fetch 对已 abort 的 signal 会立刻拒；假 fetch 也要照做，否则测不出取消路径
    if (init.signal?.aborted === true) {
      const error = new Error('The operation was aborted')
      error.name = 'AbortError'
      throw error
    }
    const call = {
      url,
      method: init.method,
      headers: init.headers ?? {},
      body: typeof init.body === 'string' ? JSON.parse(init.body) : init.body,
      signal: init.signal,
    }
    calls.push(call)
    const reply = (await handler(call, calls.length - 1)) ?? {}
    if (reply instanceof Error) throw reply
    const status = reply.status ?? 200
    return {
      ok: reply.ok ?? (status >= 200 && status < 300),
      status,
      async json() {
        if (reply.jsonThrows === true) throw new Error('响应体不是 JSON')
        return reply.body ?? {}
      },
      async text() {
        return reply.text ?? JSON.stringify(reply.body ?? {})
      },
    }
  }
  return { fetchImpl, calls }
}

/** 成功响应。 */
const ok = (body) => ({ status: 200, body })

/** 一个"挂着不动、到 signal.abort() 才 reject"的请求（模拟服务端 hold）。 */
function hanging(signal) {
  return new Promise((_, reject) => {
    signal.addEventListener('abort', () => {
      const error = new Error('The operation was aborted')
      error.name = 'AbortError'
      reject(error)
    })
  })
}

/** base64 → 十进制 uint32 文本。 */
const decodeUin = (uin) => Buffer.from(uin, 'base64').toString('utf8')

/* ------------------------------------------------------------------ 常量与请求头 */

console.log('微信独立连接 · 协议常量与请求头')

check('协议常量与已查证的事实逐字一致', () => {
  assert.equal(FIXED_BASE_URL, 'https://ilinkai.weixin.qq.com')
  assert.equal(APP_ID, 'bot')
  assert.equal(APP_CLIENT_VERSION, '204009')
  assert.equal(BOT_TYPE, '3')
  assert.equal(AUTH_TYPE, 'ilink_bot_token')
  assert.equal(QR_FETCH_TIMEOUT_MS, 20_000)
  assert.equal(QR_POLL_TIMEOUT_MS, 35_000)
  assert.equal(MAX_LOCAL_TOKENS, 10)
  assert.equal(WINDOW_CLOSED_ERRCODE, -14)
})

check('buildCommonHeaders 只有两个 app 头（GET 轮询的形状）', () => {
  const headers = buildCommonHeaders()
  assert.deepEqual(headers, {
    'iLink-App-Id': 'bot',
    'iLink-App-ClientVersion': '204009',
  })
  assert.equal('Authorization' in headers, false, 'GET 不带 Authorization')
  assert.equal('AuthorizationType' in headers, false)
  assert.equal('X-WECHAT-UIN' in headers, false, 'GET 不带 UIN')
  assert.equal('Content-Type' in headers, false)
})

check('buildPostHeaders() 不带 token：有 UIN + Content-Type，无 Authorization', () => {
  const headers = buildPostHeaders()
  assert.equal(headers['iLink-App-Id'], 'bot')
  assert.equal(headers['iLink-App-ClientVersion'], '204009')
  assert.equal(headers['Content-Type'], 'application/json')
  assert.equal(typeof headers['X-WECHAT-UIN'], 'string')
  assert.equal('Authorization' in headers, false)
  assert.equal('AuthorizationType' in headers, false, '没有 token 就不该带 AuthorizationType')
})

check('buildPostHeaders(token)：AuthorizationType + Bearer', () => {
  const headers = buildPostHeaders('c3259b90b378@im.bot:0600abc')
  assert.equal(headers.AuthorizationType, 'ilink_bot_token')
  assert.equal(headers.Authorization, 'Bearer c3259b90b378@im.bot:0600abc')
  assert.equal(headers['iLink-App-Id'], 'bot')
})

check('UIN = base64(十进制 uint32)，且每次现生成', () => {
  const seen = new Set()
  for (let i = 0; i < 20; i += 1) {
    const uin = buildPostHeaders()['X-WECHAT-UIN']
    const text = decodeUin(uin)
    assert.match(text, /^\d+$/, `UIN 解出来必须是十进制数字：${text}`)
    const value = Number(text)
    assert.ok(Number.isInteger(value) && value >= 0 && value <= 4_294_967_295, `UIN 必须是 uint32：${text}`)
    assert.equal(Buffer.from(text, 'utf8').toString('base64'), uin, 'base64 应能原样还原')
    seen.add(uin)
  }
  assert.ok(seen.size > 1, 'UIN 应该是随机的，不该 20 次全一样')
})

/* ------------------------------------------------------------------ ① 取二维码 */

console.log('\n微信独立连接 · ① 取二维码')

await checkAsync('fetchQRCode：POST + bot_type=3 + local_token_list 原样带上', async () => {
  const { fetchImpl, calls } = makeFetch(() => ok({ qrcode: 'QR-ENC', qrcode_img_content: 'data:image/png;base64,AAA' }))
  const result = await fetchQRCode({
    baseUrl: 'https://ilinkai.weixin.qq.com',
    localTokenList: ['token-a', 'token-b'],
    fetchImpl,
  })
  assert.equal(calls.length, 1)
  const call = calls[0]
  assert.equal(call.url, 'https://ilinkai.weixin.qq.com/ilink/bot/get_bot_qrcode?bot_type=3')
  assert.equal(call.method, 'POST')
  assert.equal(call.headers['iLink-App-Id'], 'bot')
  assert.equal(call.headers['iLink-App-ClientVersion'], '204009')
  assert.equal(call.headers['Content-Type'], 'application/json')
  assert.equal(typeof call.headers['X-WECHAT-UIN'], 'string')
  assert.equal('Authorization' in call.headers, false, '取码时还没有 token')
  assert.deepEqual(call.body, { local_token_list: ['token-a', 'token-b'] })
  assert.deepEqual(result, { qrcode: 'QR-ENC', qrcode_img_content: 'data:image/png;base64,AAA' })
})

await checkAsync('fetchQRCode：local_token_list 去空、去重、截断到 10 个', async () => {
  const { fetchImpl, calls } = makeFetch(() => ok({ qrcode: 'Q' }))
  await fetchQRCode({
    localTokenList: ['a', '', '  ', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l'],
    fetchImpl,
  })
  const list = calls[0].body.local_token_list
  assert.equal(list.length, MAX_LOCAL_TOKENS, '最多 10 个')
  assert.equal(list[0], 'a')
  assert.deepEqual(list, ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j'])
  assert.equal(new Set(list).size, list.length, '不能有重复')
  assert.ok(list.every((item) => typeof item === 'string' && item !== ''))
})

await checkAsync('fetchQRCode：list 缺省时发空数组（不是不发字段）', async () => {
  const { fetchImpl, calls } = makeFetch(() => ok({ qrcode: 'Q' }))
  await fetchQRCode({ fetchImpl })
  assert.deepEqual(calls[0].body, { local_token_list: [] })
  assert.equal(calls[0].url, `${FIXED_BASE_URL}/ilink/bot/get_bot_qrcode?bot_type=3`, 'baseUrl 缺省回落固定基址')
})

await checkAsync('fetchQRCode：baseUrl 结尾斜杠与自定义 botType 都被规整', async () => {
  const { fetchImpl, calls } = makeFetch(() => ok({ qrcode: 'Q' }))
  await fetchQRCode({ baseUrl: 'https://example.com/', botType: '9', fetchImpl })
  assert.equal(calls[0].url, 'https://example.com/ilink/bot/get_bot_qrcode?bot_type=9')
})

await checkAsync('fetchQRCode：非 2xx 抛清晰错误（带动作名与状态码）', async () => {
  const { fetchImpl } = makeFetch(() => ({ status: 500, text: 'boom' }))
  await assert.rejects(() => fetchQRCode({ fetchImpl }), (error) => {
    assert.match(error.message, /获取二维码失败/)
    assert.match(error.message, /HTTP 500/)
    assert.match(error.message, /boom/)
    return true
  })
})

await checkAsync('fetchQRCode：响应不是 JSON 时抛清晰错误', async () => {
  const { fetchImpl } = makeFetch(() => ({ status: 200, jsonThrows: true }))
  await assert.rejects(() => fetchQRCode({ fetchImpl }), /获取二维码失败：响应不是合法 JSON/)
})

await checkAsync('fetchQRCode：服务端没给 qrcode → 抛错（不能拿空壳继续轮询），且带上原始响应体', async () => {
  const { fetchImpl } = makeFetch(() => ok({ qrcode_img_content: 'x' }))
  await assert.rejects(() => fetchQRCode({ fetchImpl }), (error) => {
    assert.match(error.message, /服务端未返回 qrcode/)
    // 没有错误码时**才**允许这句文案，并且必须带上原始响应体（否则用户看不到任何线索）
    assert.match(error.message, /响应：/)
    assert.match(error.message, /qrcode_img_content/)
    return true
  })
})

await checkAsync('fetchQRCode：ret 非 0 → 原样报服务端 ret/err_msg（真机：-3 = token 校验失败）', async () => {
  const { fetchImpl } = makeFetch(() => ok({ err_msg: 'batch verify bot token fail', ret: -3 }))
  await assert.rejects(() => fetchQRCode({ fetchImpl }), (error) => {
    assert.equal(error.message, '获取二维码失败：服务端返回 ret=-3 err_msg=batch verify bot token fail')
    assert.equal(error.errcode, -3)
    assert.equal(error.errmsg, 'batch verify bot token fail')
    assert.equal(error.tokenRejected, true, '上层靠这个标记决定"空列表重试一次"')
    // v2.2.0 的真机 bug：这里曾经抛"服务端未返回 qrcode"，把服务端原话吞掉了
    assert.equal(error.message.includes('未返回 qrcode'), false)
    return true
  })
})

await checkAsync('fetchQRCode：ret 非 0 但**给了** qrcode 也算失败（错误码优先）', async () => {
  const { fetchImpl } = makeFetch(() => ok({ ret: -3, err_msg: 'bad', qrcode: 'Q' }))
  await assert.rejects(() => fetchQRCode({ fetchImpl }), /ret=-3 err_msg=bad/)
})

await checkAsync('fetchQRCode：errcode 也认（老形状），且没给 err_msg 时只报 ret', async () => {
  const { fetchImpl } = makeFetch(() => ok({ errcode: -3 }))
  await assert.rejects(() => fetchQRCode({ fetchImpl }), (error) => {
    assert.equal(error.message, '获取二维码失败：服务端返回 ret=-3')
    assert.equal(error.tokenRejected, true)
    return true
  })
})

await checkAsync('fetchQRCode：fetch 抛异常 → 包成"获取二维码失败"', async () => {
  const { fetchImpl } = makeFetch(() => new Error('socket hang up'))
  await assert.rejects(() => fetchQRCode({ fetchImpl }), (error) => {
    assert.match(error.message, /获取二维码失败：socket hang up/)
    // 前缀只出现一次（上层不许再加一遍，见 wechat-standalone 的 withActionPrefix）
    assert.equal(error.message.split('获取二维码失败').length - 1, 1)
    return true
  })
})

/* ------------------------------------------------------------------ ② 轮询 */

console.log('\n微信独立连接 · ② 轮询扫码状态')

await checkAsync('pollQRStatus：GET 只带两个 app 头（无 Authorization / 无 UIN / 无 Content-Type）', async () => {
  const { fetchImpl, calls } = makeFetch(() => ok({ status: 'wait' }))
  const result = await pollQRStatus({ qrcode: 'QR-ENC', fetchImpl })
  assert.equal(result.status, 'wait')
  const call = calls[0]
  assert.equal(call.method, 'GET')
  assert.deepEqual(call.headers, {
    'iLink-App-Id': 'bot',
    'iLink-App-ClientVersion': '204009',
  })
  assert.equal(call.body, undefined, 'GET 不带 body')
  assert.equal(call.url, `${FIXED_BASE_URL}/ilink/bot/get_qrcode_status?qrcode=QR-ENC`)
})

await checkAsync('pollQRStatus：qrcode / verify_code 都做 URL 编码，且按顺序拼接', async () => {
  const { fetchImpl, calls } = makeFetch(() => ok({ status: 'wait' }))
  await pollQRStatus({ qrcode: 'a b&c=d', verifyCode: '12 34', fetchImpl })
  assert.equal(
    calls[0].url,
    `${FIXED_BASE_URL}/ilink/bot/get_qrcode_status?qrcode=a%20b%26c%3Dd&verify_code=12%2034`,
  )
})

await checkAsync('pollQRStatus：没传 verifyCode 时不拼 verify_code', async () => {
  const { fetchImpl, calls } = makeFetch(() => ok({ status: 'wait' }))
  await pollQRStatus({ qrcode: 'Q', verifyCode: '', fetchImpl })
  assert.equal(calls[0].url.includes('verify_code'), false)
})

await checkAsync('pollQRStatus：客户端超时按 wait 处理（不是错误）', async () => {
  const { fetchImpl, calls } = makeFetch((call) => hanging(call.signal))
  const result = await pollQRStatus({ qrcode: 'Q', fetchImpl, timeoutMs: 15 })
  assert.equal(result.status, 'wait')
  assert.equal(result.timedOut, true)
  assert.equal(calls[0].signal.aborted, true, '超时应把请求 abort 掉')
})

await checkAsync('pollQRStatus：外部 signal 取消 → 抛 AbortError（与超时区分开）', async () => {
  const { fetchImpl } = makeFetch((call) => hanging(call.signal))
  const controller = new AbortController()
  setTimeout(() => controller.abort(), 10)
  await assert.rejects(
    () => pollQRStatus({ qrcode: 'Q', fetchImpl, signal: controller.signal, timeoutMs: 5_000 }),
    (error) => {
      assert.equal(error.name, 'AbortError')
      assert.equal(error.cancelled, true)
      return true
    },
  )
})

await checkAsync('pollQRStatus：进来时 signal 已经 aborted → 立刻抛 AbortError', async () => {
  const { fetchImpl, calls } = makeFetch(() => ok({ status: 'wait' }))
  const controller = new AbortController()
  controller.abort()
  await assert.rejects(
    () => pollQRStatus({ qrcode: 'Q', fetchImpl, signal: controller.signal }),
    (error) => error.name === 'AbortError',
  )
  assert.equal(calls.length, 0, '已经取消了就不该再发请求')
})

await checkAsync('pollQRStatus：响应字段原样透传（bot_token / redirect_host / ilink_bot_id）', async () => {
  const { fetchImpl } = makeFetch(() =>
    ok({
      status: 'confirmed',
      bot_token: 'tk-1',
      ilink_bot_id: 'acct-1',
      baseurl: 'https://redirect.example.com',
      ilink_user_id: 'user-1',
      redirect_host: 'redirect.example.com',
    }),
  )
  const result = await pollQRStatus({ qrcode: 'Q', fetchImpl })
  assert.equal(result.status, 'confirmed')
  assert.equal(result.bot_token, 'tk-1')
  assert.equal(result.ilink_bot_id, 'acct-1')
  assert.equal(result.baseurl, 'https://redirect.example.com')
  assert.equal(result.ilink_user_id, 'user-1')
  assert.equal(result.redirect_host, 'redirect.example.com')
})

await checkAsync('pollQRStatus：缺 qrcode / 缺 status / 非 2xx 都抛清晰错误', async () => {
  const { fetchImpl } = makeFetch(() => ok({}))
  await assert.rejects(() => pollQRStatus({ qrcode: '', fetchImpl }), /缺少 qrcode/)
  await assert.rejects(() => pollQRStatus({ qrcode: 'Q', fetchImpl }), (error) => {
    assert.match(error.message, /未返回 status/)
    assert.match(error.message, /响应：/, '没有错误码时必须带上原始响应体')
    return true
  })
  const bad = makeFetch(() => ({ status: 404, text: 'nope' }))
  await assert.rejects(() => pollQRStatus({ qrcode: 'Q', fetchImpl: bad.fetchImpl }), /轮询二维码状态失败：HTTP 404/)
})

await checkAsync('pollQRStatus：缺 status 但服务端给了 ret/err_msg → 不许吞掉原话', async () => {
  const { fetchImpl } = makeFetch(() => ok({ ret: -3, err_msg: 'batch verify bot token fail' }))
  await assert.rejects(() => pollQRStatus({ qrcode: 'Q', fetchImpl }), (error) => {
    assert.match(error.message, /轮询二维码状态失败：服务端返回 ret=-3 err_msg=batch verify bot token fail/)
    assert.equal(error.message.includes('未返回 status'), false)
    return true
  })
})

await checkAsync('pollQRStatus：带 status 的响应照旧放行（长轮询路径的 errcode 另有含义，不在这里改判）', async () => {
  // `-14` 在长轮询路径表示"token 失效"（见模块头），但它和 status 一起出现时
  // 仍应交给状态机处理 —— 这里加一条错误码判据会把登录流程改坏。
  const { fetchImpl } = makeFetch(() => ok({ status: 'wait', errcode: -14 }))
  const result = await pollQRStatus({ qrcode: 'Q', fetchImpl })
  assert.equal(result.status, 'wait')
})

await checkAsync('pollQRStatus：网络异常（非超时非取消）抛错，交给上层决定要不要重试', async () => {
  const { fetchImpl } = makeFetch(() => new Error('ECONNRESET'))
  await assert.rejects(() => pollQRStatus({ qrcode: 'Q', fetchImpl }), /轮询二维码状态失败：ECONNRESET/)
})

/* ------------------------------------------------------------------ ③ 发消息 */

console.log('\n微信独立连接 · ③ 发消息')

await checkAsync('sendText：POST 形状与协议逐字段一致', async () => {
  const { fetchImpl, calls } = makeFetch(() => ok({ errcode: 0 }))
  const result = await sendText({
    account: { token: 'tk-1', baseUrl: 'https://ilinkai.weixin.qq.com/' },
    to: 'peer-1',
    text: '您在[重点] 修复登录对话中的任务 已完成，请及时处理。',
    contextToken: 'ctx-1',
    fetchImpl,
  })
  assert.deepEqual(result, { ok: true, errcode: 0 })
  const call = calls[0]
  assert.equal(call.url, 'https://ilinkai.weixin.qq.com/ilink/bot/sendmessage')
  assert.equal(call.method, 'POST')
  assert.equal(call.headers.Authorization, 'Bearer tk-1')
  assert.equal(call.headers.AuthorizationType, 'ilink_bot_token')
  assert.equal(call.headers['Content-Type'], 'application/json')
  assert.equal(typeof call.headers['X-WECHAT-UIN'], 'string')

  const msg = call.body.msg
  assert.deepEqual(Object.keys(msg).sort(), [
    'client_id',
    'context_token',
    'from_user_id',
    'item_list',
    'message_state',
    'message_type',
    'to_user_id',
  ])
  assert.equal(msg.from_user_id, '')
  assert.equal(msg.to_user_id, 'peer-1')
  assert.match(msg.client_id, /^dsh-taskbar-[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/)
  assert.equal(msg.message_type, 2)
  assert.equal(msg.message_state, 2)
  assert.deepEqual(msg.item_list, [
    { type: 1, text_item: { text: '您在[重点] 修复登录对话中的任务 已完成，请及时处理。' } },
  ])
  assert.equal(msg.context_token, 'ctx-1')
})

await checkAsync('sendText：没有 contextToken 就不带 context_token 字段（这正是 -14 的现场）', async () => {
  const { fetchImpl, calls } = makeFetch(() => ok({ errcode: 0 }))
  await sendText({ account: { token: 'tk' }, to: 'peer', text: 'hi', fetchImpl })
  assert.equal('context_token' in calls[0].body.msg, false)
  assert.equal(calls[0].url, `${FIXED_BASE_URL}/ilink/bot/sendmessage`, 'baseUrl 缺省回落固定基址')
})

await checkAsync('sendText：HTTP 200 + errcode 0 / 完全没带错误码 → 成功', async () => {
  const a = makeFetch(() => ok({ errcode: 0 }))
  assert.deepEqual(await sendText({ account: { token: 't' }, to: 'p', text: 'x', fetchImpl: a.fetchImpl }), {
    ok: true,
    errcode: 0,
  })
  const b = makeFetch(() => ok({ ret: 0 }))
  assert.equal((await sendText({ account: { token: 't' }, to: 'p', text: 'x', fetchImpl: b.fetchImpl })).ok, true)
  const c = makeFetch(() => ok({}))
  assert.equal((await sendText({ account: { token: 't' }, to: 'p', text: 'x', fetchImpl: c.fetchImpl })).ok, true)
})

await checkAsync('sendText：-14 抛错，并带 errcode / windowClosed 供上层提示"先发一条消息"', async () => {
  const { fetchImpl } = makeFetch(() => ok({ errcode: -14, errmsg: 'window closed' }))
  await assert.rejects(
    () => sendText({ account: { token: 't' }, to: 'p', text: 'x', fetchImpl }),
    (error) => {
      assert.equal(error.errcode, -14)
      assert.equal(error.windowClosed, true)
      assert.equal(error.errmsg, 'window closed')
      assert.match(error.message, /发送被拒绝 errcode=-14/)
      assert.match(error.message, /errmsg=window closed/)
      return true
    },
  )
})

await checkAsync('sendText：其他 errcode 非 0 → "发送被拒绝 errcode=… errmsg=…"', async () => {
  const { fetchImpl } = makeFetch(() => ok({ errcode: 10001, errmsg: 'bad request' }))
  await assert.rejects(
    () => sendText({ account: { token: 't' }, to: 'p', text: 'x', fetchImpl }),
    (error) => {
      assert.equal(error.message, '发送被拒绝 errcode=10001 errmsg=bad request')
      assert.equal(error.windowClosed, false)
      return true
    },
  )
})

await checkAsync('sendText：没有 errcode 时按 ret 判错（errcode ?? ret）', async () => {
  const { fetchImpl } = makeFetch(() => ok({ ret: 5, errmsg: 'legacy' }))
  await assert.rejects(
    () => sendText({ account: { token: 't' }, to: 'p', text: 'x', fetchImpl }),
    /发送被拒绝 errcode=5 errmsg=legacy/,
  )
})

await checkAsync('sendText：服务端用 err_msg（下划线）时也照样带出来（不许吞掉原话）', async () => {
  const { fetchImpl } = makeFetch(() => ok({ ret: -3, err_msg: 'batch verify bot token fail' }))
  await assert.rejects(() => sendText({ account: { token: 't' }, to: 'p', text: 'x', fetchImpl }), (error) => {
    assert.equal(error.message, '发送被拒绝 errcode=-3 errmsg=batch verify bot token fail')
    assert.equal(error.errmsg, 'batch verify bot token fail')
    assert.equal(error.windowClosed, false)
    return true
  })
})

await checkAsync('sendText：错误码非 0 且服务端一句话都没给 → 退化成截断的响应体（不报无原因的错误码）', async () => {
  const { fetchImpl } = makeFetch(() => ok({ ret: 7 }))
  await assert.rejects(() => sendText({ account: { token: 't' }, to: 'p', text: 'x', fetchImpl }), (error) => {
    assert.match(error.message, /发送被拒绝 errcode=7（响应：\{"ret":7\}）/)
    return true
  })
})

await checkAsync('sendText：errcode 存在时优先于 ret（errcode=0 + ret=5 算成功）', async () => {
  const { fetchImpl } = makeFetch(() => ok({ errcode: 0, ret: 5 }))
  assert.equal((await sendText({ account: { token: 't' }, to: 'p', text: 'x', fetchImpl })).ok, true)
})

await checkAsync('sendText：忽略 message_id（uint64 裸数字，JSON.parse 已丢精度，不回查）', async () => {
  const { fetchImpl } = makeFetch(() => ok({ errcode: 0, message_id: 7514671478896275848 }))
  const result = await sendText({ account: { token: 't' }, to: 'p', text: 'x', fetchImpl })
  assert.deepEqual(result, { ok: true, errcode: 0 })
  assert.equal('message_id' in result, false)
})

await checkAsync('sendText：非 2xx 也抛错（防御性，虽然协议上永远 200）', async () => {
  const { fetchImpl } = makeFetch(() => ({ status: 502, text: 'bad gateway' }))
  await assert.rejects(() => sendText({ account: { token: 't' }, to: 'p', text: 'x', fetchImpl }), /发送消息失败：HTTP 502/)
})

await checkAsync('sendText：缺 token / 缺 to 直接抛（不发半截请求）', async () => {
  const { fetchImpl, calls } = makeFetch(() => ok({ errcode: 0 }))
  await assert.rejects(() => sendText({ account: { token: '' }, to: 'p', text: 'x', fetchImpl }), /缺少微信 token/)
  await assert.rejects(() => sendText({ account: { token: 't' }, to: '', text: 'x', fetchImpl }), /缺少目标 to_user_id/)
  assert.equal(calls.length, 0)
})

await checkAsync('sendText：fetch 网络异常 / 超时都包成"发送失败"', async () => {
  const boom = makeFetch(() => new Error('socket hang up'))
  await assert.rejects(
    () => sendText({ account: { token: 't' }, to: 'p', text: 'x', fetchImpl: boom.fetchImpl }),
    /发送失败：socket hang up/,
  )
  const hang = makeFetch((call) => hanging(call.signal))
  await assert.rejects(
    () => sendText({ account: { token: 't' }, to: 'p', text: 'x', fetchImpl: hang.fetchImpl, timeoutMs: 15 }),
    /发送失败：The operation was aborted/,
  )
})

await checkAsync('sendText：text 为空/非字符串也发得出去（不炸）', async () => {
  const { fetchImpl, calls } = makeFetch(() => ok({ errcode: 0 }))
  await sendText({ account: { token: 't' }, to: 'p', text: undefined, fetchImpl })
  assert.equal(calls[0].body.msg.item_list[0].text_item.text, '')
})

console.log(`\nwechat-proto: ${passed} 项全部通过\n`)
