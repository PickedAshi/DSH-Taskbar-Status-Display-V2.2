/**
 * 相位状态机单测：用假时钟驱动，不依赖 DSH / Cordis / 任务栏。
 *   node test/plugin-state.test.mjs
 *
 * v2.1 新增的部分集中在文件末尾：**子智能体到底影不影响 done**。
 */

import assert from 'node:assert/strict'
import { createPhaseMachine, countWorkingSubagents, isRootAgent } from '../lib/machine.js'
import { PHASE } from '../lib/status-map.js'

let passed = 0
const check = (label, fn) => {
  fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

/** 造一台机器 + 假时钟，并记录每一次相位回调。 */
function harness(overrides = {}) {
  let clock = 1_000_000
  const phases = []
  const cfg = {
    scope: 'roots',
    completion: 'hold',
    completionHoldMs: 30_000,
    errorHoldMs: 60_000,
    logStateChanges: false,
    ...overrides,
  }
  const machine = createPhaseMachine({
    config: cfg,
    onPhase: (phase, meta) => phases.push({ phase, ...meta }),
    now: () => clock,
  })
  return {
    machine,
    cfg,
    phases,
    /** 当前相位 */
    get current() {
      return machine.phase
    },
    /** 推进假时钟 */
    advance(ms) {
      clock += ms
    },
    /** 最后一次回调的相位 */
    get last() {
      return phases.at(-1)?.phase
    },
    reset() {
      phases.length = 0
    },
  }
}

console.log('phase machine')

check('初始 → idle', () => {
  const h = harness()
  h.machine.recompute()
  assert.equal(h.current, PHASE.IDLE)
  h.machine.dispose()
})

check('有会话在跑 → working', () => {
  const h = harness()
  h.machine.setRunning('s1', true)
  assert.equal(h.current, PHASE.WORKING)
  h.machine.dispose()
})

check('跑完 → done（保持期），到期 → idle', () => {
  const h = harness({ completionHoldMs: 30_000 })
  h.machine.setRunning('s1', true)
  assert.equal(h.current, PHASE.WORKING)
  h.machine.setRunning('s1', false)
  assert.equal(h.current, PHASE.DONE, '停止后应进入完成态')
  h.advance(29_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.DONE, '保持期内应仍是完成态')
  h.advance(2_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.IDLE, '保持期结束后应清除')
  h.machine.dispose()
})

check("completion='clear' 时跑完直接 idle", () => {
  const h = harness({ completion: 'clear' })
  h.machine.setRunning('s1', true)
  h.machine.setRunning('s1', false)
  assert.equal(h.current, PHASE.IDLE)
  h.machine.dispose()
})

check('等待用户 → waiting，且优先级高于 working', () => {
  const h = harness()
  h.machine.setRunning('s1', true)
  assert.equal(h.current, PHASE.WORKING)
  h.machine.setWaiting('s1', true)
  assert.equal(h.current, PHASE.WAITING, '等待应压过运行中')
  h.machine.setWaiting('s1', false)
  assert.equal(h.current, PHASE.WORKING, '回答完应回到运行中')
  h.machine.dispose()
})

check('故障 → error，且优先级高于 waiting / working', () => {
  const h = harness()
  h.machine.setRunning('s1', true)
  h.machine.setWaiting('s1', true)
  assert.equal(h.current, PHASE.WAITING)
  h.machine.markError('s1', 'boom')
  assert.equal(h.current, PHASE.ERROR, '故障应压过等待')
  h.machine.dispose()
})

check('粘性故障：同一条错误重复上报只触发一次', () => {
  const h = harness()
  assert.equal(h.machine.markError('s1', 'boom'), true, '首次应视为新故障')
  assert.equal(h.phases.length, 1, '第一次应触发')
  h.reset()
  // 连续重复同一条错误（模拟 lastAgentError 是粘性的）
  for (let i = 0; i < 5; i += 1) {
    assert.equal(h.machine.markError('s1', 'boom'), false, '同内容应被去重')
  }
  assert.equal(h.phases.length, 0, '内容没变不应重复触发')
  h.machine.dispose()
})

check('故障内容变化 → 视为新故障并刷新保持期', () => {
  const h = harness({ errorHoldMs: 60_000 })
  h.machine.markError('s1', 'boom')
  h.advance(50_000)
  // 新故障：相位本来就是 error，视觉不变所以不必重发相位回调，但保持期必须被刷新
  assert.equal(h.machine.markError('s1', 'different failure'), true, '内容变化应视为新故障')
  h.advance(50_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.ERROR, '保持期应被新故障刷新（否则这里会消退成 idle）')
  h.machine.dispose()
})

check('故障按 errorHoldMs 自动消退', () => {
  const h = harness({ errorHoldMs: 60_000 })
  h.machine.markError('s1', 'boom')
  assert.equal(h.current, PHASE.ERROR)
  h.advance(59_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.ERROR, '消退期内应保持红色')
  h.advance(2_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.IDLE, '消退后应清除')
  h.machine.dispose()
})

check('errorHoldMs=0 表示不自动消退', () => {
  const h = harness({ errorHoldMs: 0 })
  h.machine.markError('s1', 'boom')
  h.advance(10 * 60_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.ERROR, '0 应视为永久保持')
  h.machine.dispose()
})

check('重新开始跑 → 清掉该会话上一次的故障', () => {
  const h = harness()
  h.machine.markError('s1', 'boom')
  assert.equal(h.current, PHASE.ERROR)
  h.machine.setRunning('s1', true)
  assert.equal(h.current, PHASE.WORKING, '重新运行应压过旧故障')
  h.machine.dispose()
})

check('子代理状态不覆盖顶层会话（scope=roots 过滤）', () => {
  const h = harness()
  h.machine.setTopLevelFilter((id) => id === 'top')
  h.machine.recompute()
  assert.equal(h.current, PHASE.IDLE)
  h.reset()
  h.machine.setRunning('sub-agent', true)
  assert.equal(h.current, PHASE.IDLE, '非顶层会话的运行状态应被忽略')
  h.reset()
  h.machine.markError('sub-agent', 'child failed')
  assert.equal(h.current, PHASE.IDLE, '非顶层会话的故障应被忽略')
  h.machine.setRunning('top', true)
  assert.equal(h.current, PHASE.WORKING, '顶层会话正常运行')
  h.machine.dispose()
})

check('forgetSession 会清掉运行/等待/故障', () => {
  const h = harness()
  h.machine.setRunning('s1', true)
  h.machine.markError('s1', 'boom')
  h.machine.forgetSession('s1')
  assert.equal(h.current, PHASE.IDLE)
  h.machine.dispose()
})

check('reconcileRunning 用权威列表整体校准（含剔除已消失会话）', () => {
  const h = harness()
  h.machine.reconcileRunning([{ id: 'a', status: 'running' }, { id: 'b', status: 'idle' }])
  assert.equal(h.current, PHASE.WORKING)
  // 轮询发现 a 已经空闲 → 应转完成态
  h.machine.reconcileRunning([{ id: 'a', status: 'idle' }])
  assert.equal(h.current, PHASE.DONE)
  // b 从列表里消失也不该有残留
  h.machine.reconcileRunning([])
  assert.equal(h.current, PHASE.DONE, '无运行会话时保持完成态（保持期内）')
  h.machine.dispose()
})

check('未知 status 值不改动运行集合', () => {
  const h = harness({ completion: 'clear' })
  h.machine.setRunning('a', true)
  h.machine.reconcileRunning([{ id: 'a', status: 'some-future-status' }])
  assert.equal(h.current, PHASE.WORKING, '不认识的 status 不应把运行中误判为空闲')
  h.machine.dispose()
})

check('多会话聚合：任何一个在跑就是 working', () => {
  const h = harness({ completion: 'clear' })
  h.machine.setRunning('a', true)
  h.machine.setRunning('b', true)
  h.machine.setRunning('a', false)
  assert.equal(h.current, PHASE.WORKING, 'b 还在跑')
  h.machine.setRunning('b', false)
  assert.equal(h.current, PHASE.IDLE)
  h.machine.dispose()
})

check('会话被关闭/消失不算"任务完成"（不点亮绿色完成条）', () => {
  const h = harness({ completionHoldMs: 30_000 })
  h.machine.setRunning('s1', true)
  assert.equal(h.current, PHASE.WORKING)
  h.machine.forgetSession('s1')
  assert.equal(h.current, PHASE.IDLE, '拆卸不该显示完成')
  h.machine.dispose()
})

check('会话从权威列表里消失也不算完成，但显式 idle 算', () => {
  const h = harness({ completionHoldMs: 30_000 })
  h.machine.setRunning('a', true)
  // a 直接从列表里消失（被回收）→ 不该点亮完成条
  h.machine.reconcileRunning([])
  assert.equal(h.current, PHASE.IDLE, '消失 ≠ 完成')
  // 显式 idle → 算完成
  h.machine.setRunning('b', true)
  h.machine.reconcileRunning([{ id: 'b', status: 'idle' }])
  assert.equal(h.current, PHASE.DONE, '显式 idle 应算完成')
  h.machine.dispose()
})

check('完成保持期内重复 recompute 不会重复下发（原本会白发 20 次）', () => {
  const h = harness({ completionHoldMs: 30_000 })
  h.machine.setRunning('s1', true)
  h.machine.setRunning('s1', false)
  assert.equal(h.last, PHASE.DONE)
  h.reset()
  for (let i = 0; i < 20; i += 1) {
    h.advance(1_000)
    h.machine.recompute()
  }
  assert.equal(h.phases.length, 0, `保持期内应保持静默，实际收到 ${JSON.stringify(h.phases)}`)
  h.advance(11_000)
  h.machine.recompute()
  assert.equal(h.last, PHASE.IDLE, '30 秒后应转 idle')
  h.machine.dispose()
})

check('保持期内又完成一次 → 重新点亮完成态（带 force）', () => {
  const h = harness({ completionHoldMs: 30_000 })
  h.machine.reconcileRunning([{ id: 'a', status: 'running' }])
  h.machine.reconcileRunning([{ id: 'a', status: 'idle' }])
  assert.equal(h.last, PHASE.DONE)
  h.reset()
  h.machine.reconcileRunning([{ id: 'a', status: 'running' }])
  h.machine.reconcileRunning([{ id: 'a', status: 'idle' }])
  assert.equal(h.last, PHASE.DONE, '第二次完成应重新点亮')
  assert.equal(h.phases.at(-1).force, true, '相位没变时必须带 force 才会重发')
  h.machine.dispose()
})

// ── v2.1：子智能体的判据与计数 ─────────────────────────────────────────────
//
// 「子智能体」的判据固定在**注册表的运行时父子关系**上（`@deepseek-ai/dsh-agent` 的
// AgentRegistry）：`roots()` = `filter((entry) => entry.owner === void 0)`，
// `list()` = 全部在册 agent。所以"在 list 里但不在 roots 里"就是子智能体。
// 下面全部用**假数据**复现，不依赖真实 DSH。

/** 一个够用的假 AgentRegistry：roots 由 owner 关系推出来，和真实现同构。 */
function fakeAgents(entries) {
  const rows = entries.map((entry, index) => ({ index, ...entry }))
  return {
    list: () => rows.map((row) => ({ id: row.id, status: row.status })),
    roots: () => rows.filter((row) => row.owner === undefined).map((row) => ({ id: row.id, status: row.status })),
  }
}

check('isRootAgent：不在 roots 集合里 ⇒ 不是顶层（拿不准时放行）', () => {
  const roots = new Set(['top'])
  assert.equal(isRootAgent('top', roots), true)
  assert.equal(isRootAgent('sub-1', roots), false)
  assert.equal(isRootAgent('', roots), true, '空 id 不该被判成子智能体')
  assert.equal(isRootAgent('anything', new Set()), true, 'roots 拿不到时一律放行（宁可多响应）')
})

check('countWorkingSubagents：只数"非顶层 且 running"的 agent', () => {
  // 顶层在跑 + 两个子智能体在跑 + 一个子智能体已空闲（可继续的子智能体跑完就是这个样子）
  const agents = fakeAgents([
    { id: 'top', status: 'running', owner: undefined },
    { id: 'sub-a', status: 'running', owner: 'top' },
    { id: 'sub-b', status: 'running', owner: 'sub-a' }, // 孙代也算"还在工作的子智能体"
    { id: 'sub-c', status: 'idle', owner: 'top' },
  ])
  assert.equal(countWorkingSubagents(agents), 2, '只有 running 的子智能体算"还在工作"')

  // 主任务完成、子智能体都停了 → 0
  const settled = fakeAgents([
    { id: 'top', status: 'idle', owner: undefined },
    { id: 'sub-a', status: 'idle', owner: 'top' },
    { id: 'sub-b', status: 'idle', owner: 'top' },
  ])
  assert.equal(countWorkingSubagents(settled), 0, '数量为 0 时调用方不该加任何后缀')
})

check('countWorkingSubagents：拿不到注册表 / 服务抛错时一律返回 0（不误报）', () => {
  assert.equal(countWorkingSubagents(undefined), 0)
  assert.equal(countWorkingSubagents(null), 0)
  assert.equal(countWorkingSubagents({}), 0, '没有 list() 就不是一个注册表')
  assert.equal(
    countWorkingSubagents({
      list: () => {
        throw new Error('registry exploded')
      },
      roots: () => [],
    }),
    0,
    '服务抛错时返回 0，而不是把插件打挂',
  )
})

check('countWorkingSubagents：只有顶层在跑时是 0（v2.0 的默认观感）', () => {
  const agents = fakeAgents([{ id: 'top', status: 'running', owner: undefined }])
  assert.equal(countWorkingSubagents(agents), 0, '主任务自己在跑，不该被算成子智能体')
})

// ── v2.1：子智能体影不影响 done，由配置说了算 ───────────────────────────────
//
// ⚠️ **调用顺序很关键**：`awaitingSubagents` 只在"主任务 running → idle 的那一刻"
// 置位（需求原文是「**主要工作完成**后如果还有子智能体在跑」）。所以正确顺序是
//   setRunning('top', true)  →  setSubagentBusy(true)  →  setRunning('top', false)
// 先 setSubagentBusy(true) 再跑主任务是不对的：主任务在跑时相位本来就是 working。

/** 走一遍"主任务完成、子智能体还在跑"的标准序列。 */
function mainDoneWithSubagents(h) {
  h.machine.setRunning('top', true)
  h.machine.setSubagentBusy(true)
  h.machine.setRunning('top', false)
}

check('子智能体在工作 + 开关关（默认）→ 主任务一停就 done（v2.0 行为不变）', () => {
  const h = harness({ subagentDisplayEnabled: false })
  mainDoneWithSubagents(h)
  assert.equal(h.current, PHASE.DONE, '开关关着时子智能体不该拖住 done')
  h.machine.dispose()
})

check('子智能体在工作 + 开关开 → 主任务停后继续 working，不填满', () => {
  const h = harness({ subagentDisplayEnabled: true, completionHoldMs: 30_000 })
  mainDoneWithSubagents(h)
  assert.equal(h.current, PHASE.WORKING, '还有子智能体在跑 → 继续滚动而不是填满')
  // 保持期（30s）过去了也必须还是 working，不能等到期时闪成 idle
  h.advance(40_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.WORKING, '被压住的完成态不该在保持期到点时闪成 idle')
  h.machine.dispose()
})

check('子智能体全部跑完 → 这一刻才点 done，并重新开始保持期', () => {
  const h = harness({ subagentDisplayEnabled: true, completionHoldMs: 30_000 })
  mainDoneWithSubagents(h)
  assert.equal(h.current, PHASE.WORKING)
  h.advance(5_000)
  const changed = h.machine.setSubagentBusy(false)
  assert.equal(changed, true, '从"压住"变成"不压"是有意义的变化')
  assert.equal(h.current, PHASE.DONE, '所有子智能体都跑完才点亮完成条')
  assert.equal(h.last, PHASE.DONE, '这一次完成必须真的回调出去（②才能开始计时）')
  // 保持期是**从这一刻**重新开始算的
  h.advance(29_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.DONE, '保持期内仍是完成态')
  h.advance(2_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.IDLE, '保持期结束后清除')
  h.machine.dispose()
})

check('主任务从没开工、只有子智能体在跑 → 不该点亮 working（需求 2 说的是"主要工作完成后"）', () => {
  const h = harness({ subagentDisplayEnabled: true })
  h.machine.setSubagentBusy(true)
  assert.equal(h.current, PHASE.IDLE, '没有"主要工作完成"这回事，子智能体不该把进度条点亮')
  h.machine.dispose()
})

check('开关关着时 setSubagentBusy 完全静默（连一次回调都没有）', () => {
  const h = harness({ subagentDisplayEnabled: false })
  h.machine.setRunning('top', true)
  h.reset()
  h.machine.setSubagentBusy(true)
  h.machine.setSubagentBusy(false)
  h.machine.setSubagentBusy(true)
  assert.equal(h.phases.length, 0, '开关关着时子智能体的来去不该引发任何相位回调')
  assert.equal(h.current, PHASE.WORKING)
  h.machine.dispose()
})

check('主任务还在跑 → 子智能体跑完不该提前点 done', () => {
  const h = harness({ subagentDisplayEnabled: true })
  h.machine.setRunning('top', true)
  h.machine.setSubagentBusy(true)
  h.machine.setSubagentBusy(false) // 子智能体先跑完，主任务还在跑
  assert.equal(h.current, PHASE.WORKING, '主任务没停就绝不能进 done')
  h.machine.dispose()
})

check('done 保持期内又来一批子智能体 → 重新压回 working，跑完后再点 done', () => {
  const h = harness({ subagentDisplayEnabled: true, completionHoldMs: 30_000 })
  // 第一批：主任务完成 + 子智能体在跑 → 压住
  mainDoneWithSubagents(h)
  assert.equal(h.current, PHASE.WORKING)
  h.machine.setSubagentBusy(false)
  assert.equal(h.current, PHASE.DONE)
  assert.equal(h.phases.at(-1).changed, true, 'working → done 是真实变化，②一定会被 arm')
  h.reset()
  // 第二批：done 还亮着（保持期内），又来了子智能体……
  h.machine.setRunning('top', true)
  h.machine.setSubagentBusy(true)
  h.machine.setRunning('top', false)
  assert.equal(h.current, PHASE.WORKING, 'done 保持期内新一批子智能体应重新压住')
  h.machine.setSubagentBusy(false)
  assert.equal(h.current, PHASE.DONE, '第二批跑完应重新点亮')
  assert.equal(h.last, PHASE.DONE)
  assert.equal(h.phases.at(-1).changed, true, 'working → done 又是真实变化（②因此会重新计时）')
  h.machine.dispose()
})

check('setSubagentBusy 的返回值语义：只在"压不压完成态"真的翻转时才为 true', () => {
  // 开关关着：busy 的来去都不算数 → 一次相位回调都不该有
  const off = harness({ subagentDisplayEnabled: false })
  off.machine.setRunning('top', true)
  off.reset()
  assert.equal(off.machine.setSubagentBusy(true), false)
  assert.equal(off.machine.setSubagentBusy(false), false)
  assert.equal(off.machine.setSubagentBusy(true), false)
  assert.equal(off.phases.length, 0, '开关关着时子智能体的来去不该引发任何相位回调')
  assert.equal(off.current, PHASE.WORKING)
  off.machine.dispose()

  // 开关开着：主任务还在跑时，压住与否结果都是 working → 不算"翻转"
  const on = harness({ subagentDisplayEnabled: true })
  on.machine.setRunning('top', true)
  assert.equal(on.machine.setSubagentBusy(true), true, '第一次 false→true 是真实翻转')
  assert.equal(on.machine.setSubagentBusy(true), false, '事实没变 → 不重算')
  assert.equal(on.current, PHASE.WORKING, '主任务还在跑，压不压都不影响相位')
  on.machine.dispose()
})

check('等待用户/故障仍然压过"子智能体在工作"', () => {
  const h = harness({ subagentDisplayEnabled: true })
  mainDoneWithSubagents(h)
  assert.equal(h.current, PHASE.WORKING)
  h.machine.setWaiting('top', true)
  assert.equal(h.current, PHASE.WAITING, '等待用户优先级更高')
  h.machine.setWaiting('top', false)
  assert.equal(h.current, PHASE.WORKING)
  h.machine.markError('top', 'boom')
  assert.equal(h.current, PHASE.ERROR, '故障优先级最高')
  h.machine.dispose()
})

check('completion=clear + 开关开 → 子智能体跑完后不点亮完成态', () => {
  const h = harness({ subagentDisplayEnabled: true, completion: 'clear' })
  h.machine.setSubagentBusy(true)
  h.machine.setRunning('top', true)
  h.machine.setRunning('top', false)
  h.machine.setSubagentBusy(false)
  assert.equal(h.current, PHASE.IDLE, "completion='clear' 时本来就不点亮完成态")
  h.machine.dispose()
})

check('dispose 之后 setSubagentBusy 不会复活相位', () => {
  const h = harness({ subagentDisplayEnabled: true })
  h.machine.setSubagentBusy(true)
  h.machine.setRunning('top', true)
  h.machine.dispose()
  h.reset()
  h.machine.setSubagentBusy(false)
  assert.equal(h.phases.length, 0, '停用后不该再有回调')
})

// ── v2.1.2：故障**提醒**改成事件型（灯的行为一个字没改）────────────────────────
//
// 真机证据（Windows 通知中心历史）：DSH 的 toast 一共 70 条，其中约 60 条是「故障，请检查」，
// 而且成簇出现。原因是老逻辑在 `errorHoldMs` 到期时把内容签名一起清掉，于是会话只要停在
// 故障态，每 60 秒就重新亮红一次并再发一条。改成事件型后的语义：
//   **同一个会话的一次故障只提醒一次；该会话重新开跑（恢复正常）之后再出错，才允许再提醒一次。**
//
// 下面用假时钟复现这条链。`announce()` 逐字复刻 `lib/index.js` 的两道闸：
//   1. markError 返回 true（内容去重后确实是一条新故障、且是顶层会话）；
//   2. consumeFailureAnnouncement 返回 true（这个会话自上次恢复以来还没提醒过）。

/** 复刻 lib/index.js 的 announceFailure()：返回 true ⟺ 这一次该发「故障，请检查」。 */
const announce = (h, id, message) =>
  h.machine.markError(id, message) === true && h.machine.consumeFailureAnnouncement(id) === true

check('v2.1.2：同一会话连续报错多次 → 只提醒一条', () => {
  const h = harness({ errorHoldMs: 0 })
  assert.equal(announce(h, 's1', 'boom'), true, '第一次故障应该提醒')
  // 粘性错误反复上报：内容没变 → markError 去重；即使内容变了，也还在同一次故障期内
  assert.equal(announce(h, 's1', 'boom'), false, '同一条错误重复上报不该再提醒')
  assert.equal(announce(h, 's1', 'boom'), false)
  assert.equal(h.machine.markError('s1', '另一条错误'), true, '内容变化仍算新故障（灯的语义不变）')
  assert.equal(h.machine.consumeFailureAnnouncement('s1'), false, '同一次故障期内内容变了也不再提醒')
  h.machine.dispose()
})

check('v2.1.2：会话重新开跑（恢复正常）后再次出错 → 再提醒一条', () => {
  const h = harness({ errorHoldMs: 0 })
  h.machine.setRunning('s1', true)
  assert.equal(announce(h, 's1', 'boom'), true, '第一次提醒')
  h.machine.setRunning('s1', true) // 重新开跑 = 恢复正常
  assert.equal(announce(h, 's1', 'boom'), true, '恢复之后再出错，允许再提醒一次')
  assert.equal(announce(h, 's1', 'boom'), false, '再之后又回到"一次故障只提醒一条"')
  h.machine.dispose()
})

check('v2.1.2：两个不同会话各自报错 → 各提醒一条（相位不变也要发）', () => {
  const h = harness({ errorHoldMs: 0 })
  h.machine.setRunning('a', true)
  h.machine.setRunning('b', true)
  assert.equal(announce(h, 'a', 'a-boom'), true, 'a 的故障要提醒')
  h.reset()
  // b 报错时相位本来就是 error（a 还压着）→ 老逻辑按 changed 判断会漏掉这一条
  assert.equal(announce(h, 'b', 'b-boom'), true, 'b 是另一个会话，该有自己的那次提醒')
  assert.equal(h.phases.length, 0, '相位没变 ⇒ 通知不可能再靠相位回调发出来（这就是要挪出 onPhase 的原因）')
  assert.equal(h.machine.consumeFailureAnnouncement('a'), false, 'a 仍然只提醒过一次')
  assert.equal(h.machine.consumeFailureAnnouncement('b'), false, 'b 也只提醒一次')
  h.machine.dispose()
})

check('v2.1.2 回归保护：errorHoldMs 消退 → 相位离开 error 又重新进入 → 不再重复提醒', () => {
  const h = harness({ errorHoldMs: 60_000 })
  h.machine.setRunning('s1', true)
  assert.equal(announce(h, 's1', 'boom'), true, '第一次故障提醒一条')
  h.reset()
  // 会话停下，但故障态还在 —— 真机上"卡住"就是这个样子
  h.machine.setRunning('s1', false)
  h.advance(61_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.IDLE, '红条按 errorHoldMs 消退（视觉行为不变）')
  // 粘性错误又上报了一次：消退把签名一起清了，所以**灯**的角度这确实是一条"新故障"
  assert.equal(announce(h, 's1', 'boom'), false, '消退 ≠ 恢复正常 ⇒ 绝不能再提醒（这条就是本次 bug 的回归保护）')
  assert.equal(h.phases.at(-1).phase, PHASE.ERROR, '灯照旧重新亮红')
  assert.equal(h.phases.at(-1).changed, true, '相位确实"离开 error 又重新进入"——老逻辑正是在这里又发了一条')
  h.machine.dispose()
})

check('v2.1.2 回归保护：连续 5 轮「消退 → 复亮」也只提醒一条（真机 60 条刷屏的模型）', () => {
  const h = harness({ errorHoldMs: 60_000 })
  h.machine.setRunning('s1', true) // 卡住的会话仍然算"在跑"，红条消退后会落回 working
  let sent = 0
  for (let round = 0; round < 5; round += 1) {
    if (announce(h, 's1', 'boom')) sent += 1
    h.advance(61_000)
    h.machine.recompute() // errorHoldMs 到期 → 红条消退（相位离开 error）
    assert.notEqual(h.current, PHASE.ERROR, `第 ${round + 1} 轮红条应已消退（灯的行为没变）`)
  }
  assert.equal(sent, 1, `5 轮消退/复亮只该提醒 1 条，实际 ${sent} 条（老逻辑这里是 5 条）`)
  h.machine.dispose()
})

check('v2.1.2：idle 不算"恢复正常"，配额不还（红条仍然压着相位）', () => {
  const h = harness({ errorHoldMs: 60_000 })
  h.machine.setRunning('s1', true)
  assert.equal(announce(h, 's1', 'boom'), true)
  h.machine.setRunning('s1', false) // 故障之后会话回到 idle
  assert.equal(h.current, PHASE.ERROR, '粘性故障仍然压着相位（红灯还亮着）')
  assert.equal(h.machine.markError('s1', 'boom'), false, '同内容仍被去重（灯的语义不变）')
  assert.equal(h.machine.consumeFailureAnnouncement('s1'), false, 'idle 不是恢复 ⇒ 不还配额')
  h.advance(59_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.ERROR, '消退期内保持红色（与旧版一致）')
  h.advance(2_000)
  h.machine.recompute()
  assert.equal(h.current, PHASE.IDLE, '消退后清除（与旧版一致）')
  h.machine.dispose()
})

check('v2.1.2：轮询观察到 idle → running 翻转也算"恢复正常"（补事件漏报）', () => {
  const h = harness({ errorHoldMs: 0 })
  h.machine.reconcileRunning([{ id: 's1', status: 'running' }])
  assert.equal(announce(h, 's1', 'boom'), true, '第一次提醒')
  h.machine.reconcileRunning([{ id: 's1', status: 'idle' }])
  assert.equal(h.machine.consumeFailureAnnouncement('s1'), false, '只是空闲 → 不算恢复')
  h.machine.reconcileRunning([{ id: 's1', status: 'running' }])
  assert.equal(announce(h, 's1', 'boom'), true, '轮询看到它重新开跑 ⇒ 允许再提醒一次')
  h.machine.dispose()
})

check('v2.1.2：forgetSession（会话消失）也清掉记账 → 同一个 id 再出错算新的一次', () => {
  const h = harness({ errorHoldMs: 0 })
  assert.equal(announce(h, 's1', 'boom'), true)
  h.machine.forgetSession('s1')
  assert.equal(announce(h, 's1', 'boom'), true, '会话消失后同一个 id 是全新的一次故障')
  h.machine.dispose()
})

check('v2.1.2：子代理（非顶层会话）既不点灯也不提醒', () => {
  const h = harness({ errorHoldMs: 0 })
  h.machine.setTopLevelFilter((id) => id === 'top')
  h.machine.recompute()
  assert.equal(announce(h, 'sub-agent', 'child failed'), false, '子代理的故障不该弹通知')
  assert.equal(h.machine.consumeFailureAnnouncement('sub-agent'), false, '子代理连配额都不该取用')
  assert.equal(announce(h, 'top', 'boom'), true, '顶层会话照常提醒')
  h.machine.dispose()
})

console.log(`\nphase machine: ${passed} 项全部通过\n`)
