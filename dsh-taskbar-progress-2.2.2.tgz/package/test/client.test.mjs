/**
 * `lib/client.js`（浏览器半边）的**结构级回归测试**。
 *
 * ## 为什么需要它
 * `lib/client.js` 是跑在 DSH Web 客户端里的模块，跟本仓库其它测试完全不在一个世界：
 * 它只能在 `window.__ModuleLoader__` + `require('react/jsx-runtime')` +
 * `require('@deepseek-ai/dsh-client-ui-primitives')` 这套加载器契约下运行，
 * 主仓库里的单测（status-map / plugin-state / reminder / …）**一个字都不会碰它**。
 * 也就是说：改坏这个文件，`npm test` 照样全绿，直到用户打开「插件 → 配置」才发现
 * 页面白屏或控件不动。所以这里用**假加载器 + 假 require + 假原语 + 假 ctx**，
 * 把它当成一个普通模块加载进来，验证下面这些**契约**：
 *
 *   1. 模块形态与注入：`id`、`NS`、`inject` 三项；
 *   2. **注册时机**：`apply()` 必须走 `ctx.configForms.whileServed([...])` 才注册
 *      `plugins.row.config` —— 宿主还没服务这个命名空间时不许注册，服务到达后才建
 *      卡片（这条是真实修过的 bug，必须有回归保护）；释放时 slot 与卡片都要被释放；
 *   3. 字段清单与 `lib/config-schema.js` 逐字段对齐；
 *   4. 渲染契约：`summary` 返回一句话、`page` 返回 SettingsForm、每个控件都拿到
 *      合法且已本地化的 prop；
 *   5. 依赖逻辑：某组开关关掉后，该组两个输入框 `disabled`，**其它组不受影响**；
 *   6. UI 硬性要求：页面上不出现「故障」相关任何东西，也不出现 v1 的旧配置键名；
 *   7. 中英两套字典键集一致。
 *
 * 全都是"结构级"断言：这里没有真 React（本机也拿不到可解析的 react 包），
 * 真正的浏览器渲染与保存流程仍需在 DSH 桌面端里点一遍。
 *
 *   node test/client.test.mjs
 */

import assert from 'node:assert/strict'
import fs from 'node:fs'

/** 被测文件与它的参照物，都用相对路径解析，跟 cwd 无关。 */
const CLIENT_URL = new URL('../lib/client.js', import.meta.url)
const SCHEMA_URL = new URL('../lib/config-schema.js', import.meta.url)

const CLIENT_ID = 'dsh-taskbar-progress'
const NS = 'taskbarProgress'
const NAMESPACE = 'taskbar-progress'
const ROW_KEY = 'dsh-taskbar-progress#taskbar-progress'

/**
 * 期望的字段清单（顺序也要一致）。
 *
 * ⚠️ **改 `lib/config-schema.js` 时，这里必须同步改。**
 * 测试不能 `import '../lib/config-schema.js'`：那个文件 `import '@deepseek-ai/schemastery'`，
 * 而本仓库刻意零依赖（`link:` 安装时解析不到 profile 运行时包），直接跑必然失败。
 * 所以清单硬编码在这里，另外单独有一项"读文本比对"，防止两边悄悄漂移。
 */
const EXPECTED_FIELDS = [
  'notifyPersona',
  'waitingNotifyEnabled',
  'waitingNotifyText',
  'waitingNotifyDelayMs',
  'reviewNotifyEnabled',
  'reviewNotifyText',
  'reviewNotifyDelayMs',
  'driftNotifyEnabled',
  'driftNotifyText',
  'driftNotifyMinutes',
  // v2.1 新增：子智能体工作显示（父开关 + 子开关）
  'subagentDisplayEnabled',
  'subagentDoneNotifyEnabled',
  // v2.1 需求 4 新增：微信提醒（两个开关 + 各自独立的时长）
  'wechatDoneEnabled',
  'wechatDoneDelayMs',
  'wechatWaitingEnabled',
  'wechatWaitingDelayMs',
]

/** 三组提醒：开关字段 + 它管着的文案与时长。 */
const GROUPS = [
  { enabled: 'waitingNotifyEnabled', text: 'waitingNotifyText', number: 'waitingNotifyDelayMs' },
  { enabled: 'reviewNotifyEnabled', text: 'reviewNotifyText', number: 'reviewNotifyDelayMs' },
  { enabled: 'driftNotifyEnabled', text: 'driftNotifyText', number: 'driftNotifyMinutes' },
]

/**
 * v2.1 需求 4 的微信提醒块：**两个各自独立的开关**，每个管着自己的时长。
 *
 * 与三组提醒的差别只有一处：这里没有单一"父开关"（需求要求两个功能能单独开关、
 * 单独设时长），所以"父开关关 → 延迟框禁用"这条规则**逐行**适用。
 * 另外整节还有一个宿主侧的可用性闸：探测不到联动插件时整节灰掉。
 */
const WECHAT = {
  title: 'wechatTitle',
  enabledFields: ['wechatDoneEnabled', 'wechatWaitingEnabled'],
  numberFields: ['wechatDoneDelayMs', 'wechatWaitingDelayMs'],
  rows: [
    { enabled: 'wechatDoneEnabled', number: 'wechatDoneDelayMs' },
    { enabled: 'wechatWaitingEnabled', number: 'wechatWaitingDelayMs' },
  ],
  /** 宿主侧只读状态路由（客户端就是问它"联动插件在不在"）。 */
  statePath: '/api/dsh-taskbar-progress/wechat',
  /** v2.1.3：强刷查询串（「重新检测」按钮必须带上它，宿主据此先 invalidate 再 probe）。 */
  refreshQuery: '?refresh=1',
}

/**
 * v2.1 的子智能体块：一个父开关 + 它管着的一个子开关。
 * 交互规则与三组提醒一致：**父开关关掉 → 子开关禁用**。
 */
const SUBAGENT = {
  parent: 'subagentDisplayEnabled',
  child: 'subagentDoneNotifyEnabled',
  /** 三个布尔组 + 子智能体父开关；子开关不在这个清单里（它由父开关管）。 */
  independentSwitches: [...GROUPS.map((group) => group.enabled), 'subagentDisplayEnabled'],
}

/** v1 的旧键名 + 故意不上界面的键：一个都不许出现在渲染结果里。 */
const BANNED_KEYS = [
  'waitingReminderMs',
  'waitingReminderText',
  'completionNudgeMs',
  'completionNudgeText',
  'notifyAumid',
  'failureNotifyEnabled',
  'failureNotifyText',
  // v2.1 需求 1 的那截后缀是硬性追加、不可配置的，界面上不能有任何开关
  'subagentSuffix',
  'subagentNoticeSuffix',
]

let passed = 0
const check = (label, fn) => {
  fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}
const checkAsync = async (label, fn) => {
  await fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

/**
 * 造一个"世界"：假 window 加载器 + 假 require + 假原语 + 假 ctx，并跑一次 `apply()`。
 *
 * @param options.serve - `immediate`（宿主已经报上命名空间）/ `manual`（还没报，测试自己触发）
 * @returns 这个世界里所有可断言的把手
 */
function createWorld(options = {}) {
  const serveMode = options.serve ?? 'immediate'
  /**
   * 宿主侧只读状态路由的替身。
   *
   * 客户端只用 `fetch` 一条通道，所以这里按**浏览器原样**打桩：测试可以换掉它来
   * 模拟"宿主说联动插件不可用"（`available:false` + 原因）与"通道根本不通"（抛）。
   * 默认答"可用"，这样其它用例的渲染结果不受需求 4 影响。
   */
  const fetchCalls = []
  let fetchImpl = options.fetch ?? (async () => ({
    ok: true,
    status: 200,
    json: async () => ({ available: true, reason: '' }),
  }))
  globalThis.fetch = async (url, init) => {
    fetchCalls.push({ url, init })
    return await fetchImpl(url, init)
  }

  // ── 记录下模块向原语要了什么 ────────────────────────────────────────────
  const calls = {
    specs: null,
    models: [],
    forms: [],
    valueFields: [],
    switches: [],
    buttons: [],
    /** v2.2.0：所有字符串标签的元素（`input` / `img` 这类要看类型才能断言的） */
    elements: [],
    edits: [],
    resets: [],
    saves: 0,
    discards: 0,
    modelDisposed: 0,
    slotDisposed: 0,
    registrationsInsideCallback: 0,
    duplicateKeys: [],
    effectLabels: [],
    effectDisposers: [],
    whileServedCalls: [],
  }

  // ── react/jsx-runtime 的替身 ───────────────────────────────────────────
  // 只做两件真运行时也做的事：第三个参数是 key；config 里的 key 不算 prop。
  // 真 React 里 key 只该走第三个参数，两个都给属于写法不规范 —— 这里记下来断言。
  const node = (type, config, maybeKey) => {
    const { key: configKey, ...props } = config ?? {}
    if (configKey !== undefined && maybeKey !== undefined) calls.duplicateKeys.push(String(maybeKey))
    const element = { type, key: maybeKey !== undefined ? maybeKey : configKey, props }
    // 字符串标签的元素记一份：`<input>` / `<img>` 没有 children，只能靠类型去找
    if (typeof type === 'string') calls.elements.push(element)
    return element
  }
  const jsxRuntime = { jsx: node, jsxs: node, Fragment: Symbol('Fragment') }

  // ── react 的替身（v2.1.3 新增：客户端开始用 useEffect） ─────────────────
  //
  // 真 React 的哪些语义必须照抄：
  //  · 同一个组件跨多次"渲染"共用同一份 hook 槽位（所以 deps 比较才有意义）；
  //  · deps 逐项 `Object.is` 比较，全都一样就不重跑 effect —— "同一挂载周期只发一次"
  //    这条要求全靠它，假实现要是每次都跑，新用例就变成"永远发请求"；
  //  · 每次渲染把游标归零（React 的 hooks 顺序契约）。
  // 故意不像真的地方：effect 在**本轮渲染结束时就同步排空**（真 React 是异步的），
  // 这样断言不必抢微任务；被测 effect 也不返回清理函数，所以这里没有实现清理。
  const hooks = new Map()
  let hookOwner = null
  let hookCursor = 0
  let effectQueue = []
  const beginHooks = (component) => {
    if (!hooks.has(component)) hooks.set(component, {})
    hookOwner = component
    hookCursor = 0
  }
  const endHooks = () => {
    hookOwner = null
  }
  const drainEffects = () => {
    const queue = effectQueue
    effectQueue = []
    for (const effect of queue) effect()
  }
  const react = {
    useEffect(effect, deps) {
      assert.ok(hookOwner, 'useEffect 必须在一个组件渲染过程中调用')
      const slots = hooks.get(hookOwner)
      const at = hookCursor
      hookCursor += 1
      const previous = slots[at]
      slots[at] = { deps: Array.isArray(deps) ? [...deps] : undefined }
      const same = Array.isArray(deps) && Array.isArray(previous?.deps)
        && deps.length === previous.deps.length
        && deps.every((value, index) => Object.is(value, previous.deps[index]))
      if (same) return
      effectQueue.push(effect)
    },
  }

  // ── 原语替身：形状照 @deepseek-ai/dsh-client-ui-primitives 的真实实现 ──
  const primitives = {
    SettingsForm(props) {
      calls.forms.push(props)
      return node('SettingsForm', props)
    },
    SettingsValueField(props) {
      calls.valueFields.push(props)
      return node('SettingsValueField', props)
    },
    Switch(props) {
      calls.switches.push(props)
      return node('Switch', props)
    },
    // 真实现：`forwardRef` 包的原生 button，默认 `type="button"`，rest 透传
    // （`onClick` / `disabled` / `children` 都在 rest 里）。v2.1.3 的「重新检测」用它。
    Button(props) {
      calls.buttons.push(props)
      return node('Button', props)
    },
    settingsTextField(field) {
      return {
        field,
        format: (value) => (typeof value === 'string' ? value : ''),
        parse: (text) => (text.trim() === '' ? { kind: 'clear' } : { kind: 'set', value: text.trim() }),
      }
    },
    settingsNumberField(field) {
      return {
        field,
        format: (value) => (typeof value === 'number' ? String(value) : ''),
        parse: (text) => {
          const trimmed = text.trim()
          if (trimmed === '') return { kind: 'clear' }
          const parsed = Number(trimmed)
          return Number.isFinite(parsed) ? { kind: 'set', value: parsed } : undefined
        },
      }
    },
    SettingsFormModel: class {
      constructor(scope, specs) {
        this.scope = scope
        this.specs = specs
        calls.specs = specs
        calls.models.push(this)
        /** 假的宿主有效值；测试可以改它来模拟"开关被关掉"等场景。 */
        this.values = {
          notifyPersona: '大肥鱼',
          waitingNotifyEnabled: true,
          waitingNotifyText: '老大请您做出决定',
          waitingNotifyDelayMs: 30000,
          reviewNotifyEnabled: true,
          reviewNotifyText: '老大请验收',
          reviewNotifyDelayMs: 15000,
          driftNotifyEnabled: true,
          driftNotifyText: '已经连续工作10分钟，建议检查白饭是否被偷',
          driftNotifyMinutes: 10,
          // v2.1：父开关默认关（v2.0 行为），子开关默认开
          subagentDisplayEnabled: false,
          subagentDoneNotifyEnabled: true,
          // v2.1 需求 4：两个微信开关**默认都是关**（需求硬性要求）
          wechatDoneEnabled: false,
          wechatDoneDelayMs: 15000,
          wechatWaitingEnabled: false,
          wechatWaitingDelayMs: 30000,
        }
      }
      bind(project) {
        this.project = project
        return { getSnapshot: () => project() }
      }
      shell() {
        return { available: true, writable: true, dirty: false, invalid: false, saving: false, failed: false }
      }
      field(name) {
        const spec = this.specs.find((item) => item.field === name)
        return { text: spec.format(this.values[name]), overridden: false, invalid: false }
      }
      actions() {
        return {
          edit: (field, text) => calls.edits.push({ field, text }),
          resetField: (field) => calls.resets.push(field),
          save: () => {
            calls.saves += 1
          },
          discard: () => {
            calls.discards += 1
          },
        }
      }
      dispose() {
        calls.modelDisposed += 1
      }
    },
  }

  // ── 用假加载器把真文件加载进来 ─────────────────────────────────────────
  let registration = null
  globalThis.window = {
    __ModuleLoader__: {
      load(reg) {
        registration = reg
      },
    },
  }
  new Function(fs.readFileSync(CLIENT_URL, 'utf8'))()
  assert.ok(registration, 'client.js 必须调用 window.__ModuleLoader__.load({ id, factory })')

  const moduleExports = registration.factory((specifier) => {
    if (specifier === 'react/jsx-runtime') return jsxRuntime
    if (specifier === 'react') return react
    if (specifier === '@deepseek-ai/dsh-client-ui-primitives') return primitives
    throw new Error(`client.js require 了计划外的模块：${specifier}`)
  })

  // ── 假 ctx ─────────────────────────────────────────────────────────────
  const dictionaries = []
  const missingKeys = new Set()
  let activeLocale = 'zh'
  const lookup = (key) => {
    const dict = dictionaries[0]?.dicts[activeLocale]
    if (dict?.[key] === undefined) missingKeys.add(`${activeLocale}:${key}`)
    return dict?.[key] ?? key
  }

  const scope = {
    subscribe: () => () => {},
    getSnapshot: () => ({ status: 'ready', writable: true, value: {}, base: {}, user: {} }),
    mutate: async () => true,
  }

  const registry = []
  const pendingServes = []
  let insideServeCallback = false
  const ctx = {
    effect(fn, label) {
      calls.effectLabels.push(label)
      const dispose = fn()
      calls.effectDisposers.push(typeof dispose === 'function' ? dispose : () => {})
      return () => {
        if (typeof dispose === 'function') dispose()
      }
    },
    locale: {
      bind(ns) {
        assert.equal(ns, NS, '字典命名空间')
        return lookup
      },
      register(ns, dicts) {
        assert.equal(ns, NS, '字典命名空间')
        dictionaries.push({ ns, dicts })
        return () => {}
      },
    },
    configForms: {
      get(ns) {
        assert.equal(ns, NAMESPACE, '设置命名空间必须是行 id')
        return scope
      },
      whileServed(namespaces, register) {
        calls.whileServedCalls.push(namespaces)
        let off
        const sync = () => {
          if (serveMode !== 'immediate' || off !== undefined) return
          insideServeCallback = true
          try {
            off = register(new Set(namespaces))
          } finally {
            insideServeCallback = false
          }
        }
        if (serveMode !== 'immediate') {
          // 手动模式：宿主还没报上命名空间，测试稍后自己调用这个回调
          pendingServes.push(() => {
            insideServeCallback = true
            try {
              off = register(new Set(namespaces))
            } finally {
              insideServeCallback = false
            }
          })
        }
        sync()
        return () => {
          off?.()
          off = undefined
        }
      },
    },
    slots: {
      inject(slotName, callback) {
        assert.equal(slotName, 'plugins.row.config', '座位名')
        const dispose = callback()
        return typeof dispose === 'function' ? dispose : () => {}
      },
      register(options, component) {
        if (insideServeCallback) calls.registrationsInsideCallback += 1
        registry.push({ options, component })
        return () => {
          calls.slotDisposed += 1
        }
      },
    },
  }

  return {
    registration,
    moduleExports,
    ctx,
    calls,
    scope,
    registry,
    dictionaries,
    missingKeys,
    pendingServes,
    fetchCalls,
    /** 换掉宿主状态路由的答案（在 apply 之前调用，模拟不同的探测结果）。 */
    setFetch(impl) {
      fetchImpl = impl
    },
    /** 让控制器那次 `fetch` 的 Promise 链跑完（测试是同步的，需要显式让出一轮）。 */
    async settle() {
      await new Promise((resolve) => setTimeout(resolve, 0))
      await new Promise((resolve) => setTimeout(resolve, 0))
    },
    get activeLocale() {
      return activeLocale
    },
    setLocale(locale) {
      activeLocale = locale
    },
    /** 当前注册项（slot 被释放后就没有了）。 */
    current() {
      return registry.at(-1)
    },
    /** 走一遍 renderer 的 bindInjectSources：hooks → use<Name>。 */
    face() {
      const { hooks, ...rest } = this.current().options.inject()
      const props = { ...rest }
      for (const [name, source] of Object.entries(hooks ?? {})) {
        props[`use${name[0].toUpperCase()}${name.slice(1)}`] = (selector) => selector(source.getSnapshot())
      }
      return props
    },
    /** 渲染一次（不经过真 React，只调用组件拿元素树）。 */
    render(view) {
      const { component } = this.current()
      beginHooks(component)
      let element
      try {
        element = component({
          view,
          t: lookup,
          form: scope,
          ...this.face(),
        })
      } finally {
        endHooks()
      }
      // 一次渲染结束：把这一轮注册的 effect 跑掉（打开配置页那次重新探测就在这里发生）
      drainEffects()
      return element
    },
    /** 收集一棵元素树里的全部可见文案。 */
    texts(element) {
      const out = []
      const walk = (value) => {
        if (value === null || value === undefined || typeof value === 'boolean') return
        if (typeof value === 'string' || typeof value === 'number') {
          out.push(String(value))
          return
        }
        if (Array.isArray(value)) {
          value.forEach(walk)
          return
        }
        if (typeof value === 'object' && 'props' in value) {
          if (typeof value.type === 'function') {
            // 真 React 里每个函数组件都是一次独立渲染（hooks 游标各归各的），
            // 这里照做，顺便把这一次注册的 effect 也排空。
            beginHooks(value.type)
            let rendered
            try {
              rendered = value.type(value.props)
            } finally {
              endHooks()
            }
            drainEffects()
            walk(rendered)
          } else walk(value.props.children)
        }
      }
      walk(element)
      return out
    },
    /** 清掉上一次渲染记下的控件，便于分组断言。 */
    resetRendered() {
      calls.forms.length = 0
      calls.valueFields.length = 0
      calls.switches.length = 0
      calls.buttons.length = 0
      calls.elements.length = 0
    },
    /** 一次"渲染 + 收集文案 + 记录控件"的组合动作。 */
    paint(overrides = {}, view = 'page') {
      const model = calls.models.at(-1)
      for (const [field, value] of Object.entries(overrides)) model.values[field] = value
      this.resetRendered()
      const element = this.render(view)
      return { element, texts: this.texts(element) }
    },
    /** 某个输入框当前是不是禁用。 */
    disabled(field) {
      const control = calls.valueFields.find((item) => item.id === `plugin-config-taskbar-progress-${field}`)
      assert.ok(control, `渲染结果里应有字段 ${field}`)
      return control.disabled
    },
  }
}

/** 页面文案 + 所有控件收到的文案，合起来就是用户实际看得见的东西。 */
const visibleCopy = (world, texts) =>
  [
    ...texts,
    ...world.calls.valueFields.flatMap((field) => [field.label, field.hint]),
    ...world.calls.switches.map((sw) => sw.label),
    ...world.calls.buttons.flatMap((button) => (typeof button.children === 'string' ? [button.children] : [])),
    ...Object.values(world.calls.forms.at(-1).labels),
  ].join('\n')

console.log('client (browser half)')

// ── 1. 模块形态 ────────────────────────────────────────────────────────────
check('模块形态：id / NS / inject 三项服务', () => {
  const world = createWorld()
  assert.equal(world.registration.id, CLIENT_ID)
  assert.equal(world.moduleExports.NS, NS)
  assert.deepEqual(world.moduleExports.inject, ['slots', 'locale', 'configForms'])
  assert.equal(typeof world.moduleExports.apply, 'function')
})

// ── 2. 注册时机：必须经 whileServed ────────────────────────────────────────
check('apply 经 ctx.configForms.whileServed 注册 slot（而不是抢先注册）', () => {
  const world = createWorld({ serve: 'immediate' })
  world.moduleExports.apply(world.ctx)
  assert.deepEqual(world.calls.whileServedCalls, [[NAMESPACE]], 'whileServed 必须盯住本插件的命名空间')
  assert.equal(world.calls.registrationsInsideCallback, 1, 'slot 必须在 whileServed 的回调里注册')
  assert.equal(world.registry.length, 1)
  const { options } = world.current()
  assert.equal(options.name, 'plugins.row.config')
  assert.equal(options.key, ROW_KEY, 'key 必须是 <包名>#<行id>')
  assert.equal(options.locale, NS)
  assert.equal(options.label(), '任务栏进度条')
  assert.ok(world.calls.effectLabels.includes('dsh-taskbar-progress: configuration page'))
})

check('宿主还没服务这个命名空间时：不注册 slot、也不建卡片', () => {
  const world = createWorld({ serve: 'manual' })
  world.moduleExports.apply(world.ctx)
  assert.deepEqual(world.calls.whileServedCalls, [[NAMESPACE]], '仍然要订阅 whileServed')
  assert.equal(world.registry.length, 0, '没服务就不该有注册项（否则插件行会多出一个点不开的「配置」）')
  assert.equal(world.calls.models.length, 0, '也不该提前建卡片')
})

check('命名空间到达后才建卡片并注册（延迟服务）', () => {
  const world = createWorld({ serve: 'manual' })
  world.moduleExports.apply(world.ctx)
  world.pendingServes[0]()
  assert.equal(world.registry.length, 1)
  assert.equal(world.calls.models.length, 1)
  assert.deepEqual(world.calls.models[0].specs.map((spec) => spec.field), EXPECTED_FIELDS)
})

check('释放 whileServed 的 effect：slot 注销 + 卡片 dispose', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  assert.equal(world.calls.slotDisposed, 0)
  assert.equal(world.calls.modelDisposed, 0)
  // effect 顺序：0=字典，1=配置页
  world.calls.effectDisposers[1]()
  assert.equal(world.calls.slotDisposed, 1, 'slot 注册要撤掉')
  assert.equal(world.calls.modelDisposed, 1, '卡片要 dispose，不能漏订阅')
})

// ── 3. 字段清单 ───────────────────────────────────────────────────────────
check('字段清单与 config-schema 的 16 个键逐字段一致（顺序也一致）', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  assert.deepEqual(world.calls.specs.map((spec) => spec.field), EXPECTED_FIELDS)
  assert.equal(world.calls.specs.length, 16)
})

check('lib/config-schema.js 文本里的键与上面清单一致（读文本，不 import）', () => {
  const source = fs.readFileSync(SCHEMA_URL, 'utf8')
  const declared = [...source.matchAll(/^\s{2}(\w+):\s*(?:bool|text|number)\(/gm)].map((match) => match[1])
  // 匹配不到说明那个文件的写法变了（不是失败，只是这条检查失效）——不误报
  if (declared.length > 0) assert.deepEqual(declared, EXPECTED_FIELDS, '两边字段漂移了：请同步本文件的 EXPECTED_FIELDS')
})

check('三个布尔字段 + 三个数字字段的解析/格式化符合表单模型契约', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const spec = (field) => world.calls.specs.find((item) => item.field === field)

  for (const group of GROUPS) {
    const bool = spec(group.enabled)
    assert.deepEqual(bool.format(true), 'true')
    assert.deepEqual(bool.format(false), 'false')
    assert.deepEqual(bool.format(undefined), '', '没值时是空串，等于"用默认"')
    assert.deepEqual(bool.parse(' true '), { kind: 'set', value: true })
    assert.deepEqual(bool.parse('false'), { kind: 'set', value: false })
    assert.deepEqual(bool.parse(''), { kind: 'clear' })
    assert.equal(bool.parse('随便'), undefined, '认不出的布尔草稿要拦住保存，而不是猜')

    const number = spec(group.number)
    assert.deepEqual(number.format(30000), '30000')
    assert.deepEqual(number.parse('30000'), { kind: 'set', value: 30000 })
    assert.deepEqual(number.parse(''), { kind: 'clear' })
    assert.equal(number.parse('三十秒'), undefined, '数字字段要拦住非数字')
  }

  const text = spec('waitingNotifyText')
  assert.deepEqual(text.parse('  老大请您做出决定  '), { kind: 'set', value: '老大请您做出决定' })
  assert.deepEqual(text.parse('   '), { kind: 'clear' })
})

// ── 4. 渲染契约 ───────────────────────────────────────────────────────────
check('注入面：form + useTaskbarCard + 四个表单动作 + 重新探测/独立连接把手', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const face = world.face()
  assert.equal(face.form, world.scope, '注入的 form 就是本行的设置 scope')
  assert.deepEqual(
    Object.keys(face).sort(),
    // v2.2.0 多了 connectWechat（独立连接的动作入口）与 wechatCode（验证码的 DOM 镜像盒子）
    ['connectWechat', 'discard', 'edit', 'form', 'recheckWechat', 'resetField', 'save', 'useTaskbarCard', 'wechatCode'],
  )
  assert.equal(typeof face.recheckWechat, 'function', 'v2.1.3：页面靠这个把手重新探测微信可用性')
  assert.equal(typeof face.connectWechat, 'function', 'v2.2.0：页面靠这个把手驱动独立连接的登录/验证码/断开')
  assert.ok(face.wechatCode && typeof face.wechatCode === 'object', '验证码盒子由控制器持有（DOM 镜像，不是 UI 状态）')
})

check('summary 视图返回一句话（不是元素）', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const summary = world.render('summary')
  assert.equal(typeof summary, 'string')
  assert.equal(summary, world.dictionaries[0].dicts.zh.summary)
  world.setLocale('en')
  assert.equal(world.render('summary'), world.dictionaries[0].dicts.en.summary)
  world.setLocale('zh')
})

check('page 视图渲染 SettingsForm：通用块 + 三组，控件 prop 齐备且 id 唯一', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const { element } = world.paint()

  assert.equal(element.type.name, 'SettingsForm')
  const form = world.calls.forms[0]
  assert.deepEqual(Object.keys(form.labels).sort(), ['readOnly', 'save', 'saveFailed', 'saving', 'unavailable'])
  assert.equal(form.state.available, true)
  assert.equal(typeof form.onSave, 'function')
  assert.equal(typeof form.onDiscard, 'function')
  assert.equal(form.children.length, 6, '通用 + 三组提醒 + 子智能体块 + 微信提醒块')

  // 九个输入框：署名 1 + 每组文案 1 + 每组时长 1 + 微信两行的时长
  assert.deepEqual(
    world.calls.valueFields.map((field) => field.id.replace('plugin-config-taskbar-progress-', '')),
    ['notifyPersona', ...GROUPS.flatMap((group) => [group.text, group.number]), ...WECHAT.numberFields],
  )
  assert.equal(new Set(world.calls.valueFields.map((field) => field.id)).size, 9, '控件 id 必须唯一')
  for (const field of world.calls.valueFields) {
    assert.equal(typeof field.label, 'string')
    assert.equal(typeof field.hint, 'string')
    assert.ok(field.label.length > 0 && field.hint.length > 0)
    assert.equal(typeof field.numeric, 'boolean')
    assert.equal(typeof field.disabled, 'boolean')
    assert.equal(typeof field.text, 'string')
    assert.equal(typeof field.overridden, 'boolean')
    assert.equal(typeof field.invalid, 'boolean')
    assert.equal(typeof field.onEdit, 'function')
    assert.equal(typeof field.onReset, 'function')
    assert.equal(typeof field.overriddenLabel, 'string')
    assert.equal(typeof field.resetLabel, 'string')
    assert.equal(typeof field.invalidLabel, 'string')
  }
  // 只有五个时长是数字键盘：三组提醒各自的时长 + 微信两行的时长
  assert.deepEqual(
    world.calls.valueFields.filter((field) => field.numeric).map((field) => field.id.replace('plugin-config-taskbar-progress-', '')),
    [...GROUPS.map((group) => group.number), ...WECHAT.numberFields],
  )
  // 七个开关：三组提醒各自的开关 + 子智能体父开关 + 它的子开关 + 微信的两个开关
  assert.equal(world.calls.switches.length, 7)
  assert.deepEqual(
    world.calls.switches.map((sw) => sw.checked),
    [true, true, true, false, true, false, false],
    '三组提醒默认开；子智能体工作显示默认关（= v2.0 行为），它的子开关默认开；微信两个开关默认都关',
  )
  assert.deepEqual(
    world.calls.switches.map((sw) => sw.disabled),
    [false, false, false, false, true, false, false],
    '前四个开关可改；子开关因为父开关默认关而禁用（灰掉）；微信两个开关本身可改（默认关但没被锁）',
  )
  for (const sw of [...world.calls.switches.slice(0, 4), ...world.calls.switches.slice(5)]) {
    assert.equal(typeof sw.label, 'string')
    assert.ok(sw.label.length > 0)
    assert.equal(sw.disabled, false)
    assert.equal(typeof sw.onChange, 'function')
  }
})

check('开关点击暂存布尔编辑（true/false 文本）', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  world.paint()
  world.calls.switches[0].onChange(false)
  world.calls.switches[2].onChange(true)
  assert.deepEqual(world.calls.edits, [
    { field: 'waitingNotifyEnabled', text: 'false' },
    { field: 'driftNotifyEnabled', text: 'true' },
  ])
  // 文案框的编辑与 reset 也要接对字段
  world.calls.valueFields[1].onEdit('换个说法')
  world.calls.valueFields[1].onReset()
  assert.deepEqual(world.calls.edits.at(-1), { field: 'waitingNotifyText', text: '换个说法' })
  assert.deepEqual(world.calls.resets, ['waitingNotifyText'])
})

// ── 5. 依赖逻辑 ───────────────────────────────────────────────────────────
check('关掉某组开关：该组文案与时长禁用，其它组不受影响', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)

  world.paint({ reviewNotifyEnabled: false })
  // 后四个是 v2.1 子智能体块的父/子开关与微信块的两个开关，不属于"三组提醒"，关某一组不影响它们
  assert.deepEqual(world.calls.switches.map((sw) => sw.checked), [true, false, true, false, true, false, false])
  assert.equal(world.disabled('reviewNotifyText'), true)
  assert.equal(world.disabled('reviewNotifyDelayMs'), true)
  assert.equal(world.disabled('waitingNotifyText'), false, '别的组不许被连坐')
  assert.equal(world.disabled('waitingNotifyDelayMs'), false)
  assert.equal(world.disabled('driftNotifyText'), false)
  assert.equal(world.disabled('driftNotifyMinutes'), false)
  assert.equal(world.disabled('notifyPersona'), false, '通用块始终可改')

  world.paint({ waitingNotifyEnabled: false, reviewNotifyEnabled: false, driftNotifyEnabled: false })
  const groupFields = GROUPS.flatMap((group) => [group.text, group.number])
  assert.equal(groupFields.every((field) => world.disabled(field)), true, '三组全关则三个组的文案与时长全部禁用')
  assert.equal(world.disabled('notifyPersona'), false, '通用块的署名与开关无关，仍可改')
})

check('关掉的组会多一行"该组提醒已关闭"，开着的组没有', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const notice = world.dictionaries[0].dicts.zh.groupOff

  const allOn = world.paint({ waitingNotifyEnabled: true, reviewNotifyEnabled: true, driftNotifyEnabled: true })
  assert.equal(allOn.texts.filter((line) => line === notice).length, 0)

  const oneOff = world.paint({ reviewNotifyEnabled: false })
  assert.equal(oneOff.texts.filter((line) => line === notice).length, 1, '只给关掉的那组提示一次')
})

check('只读部署：所有控件禁用', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const model = world.calls.models.at(-1)
  const original = model.shell.bind(model)
  model.shell = () => ({ ...original(), writable: false })
  world.paint()
  assert.equal(world.calls.switches.every((sw) => sw.disabled), true)
  assert.equal(world.calls.valueFields.every((field) => field.disabled), true)
})

check('布尔字段没值（空串）时按宿主默认值显示，而不是一律显示成关闭', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  world.paint({ waitingNotifyEnabled: undefined, reviewNotifyEnabled: undefined, driftNotifyEnabled: undefined })
  // 三组提醒默认开；子智能体块与微信块的默认值不同（父 false / 子 true / 微信两个 false），由下面专门的用例钉
  assert.deepEqual(world.calls.switches.map((sw) => sw.checked), [true, true, true, false, true, false, false])
})

// ── 5.5 v2.1 子智能体块的依赖逻辑（父开关 → 子开关） ───────────────────────
check('子智能体块：父开关关着时子开关禁用，并给出"已关闭"提示', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const zh = world.dictionaries[0].dicts.zh
  const notice = zh.subagentGroupOff

  const off = world.paint({ subagentDisplayEnabled: false, subagentDoneNotifyEnabled: true })
  const child = world.calls.switches.find((sw) => sw.label === zh.subagentDoneNotifyEnabled)
  assert.ok(child, '子开关必须渲染出来（默认值 true 要看得见）')
  assert.equal(child.checked, true, '父开关关着也不改变子开关自身的值，只是禁用')
  assert.equal(child.disabled, true, '父开关关掉 ⇒ 子开关必须禁用（灰掉）')
  assert.equal(off.texts.filter((line) => line === notice).length, 1, '关掉时给一行提示')

  const on = world.paint({ subagentDisplayEnabled: true, subagentDoneNotifyEnabled: true })
  const childOn = world.calls.switches.find((sw) => sw.label === zh.subagentDoneNotifyEnabled)
  assert.equal(childOn.disabled, false, '父开关打开 ⇒ 子开关可改')
  assert.deepEqual(on.texts.filter((line) => line === notice), [], '打开时不显示"已关闭"')

  // 禁用态的那个子开关即便被点到也不许写入（避免"灰着还能改"的错觉）
  world.paint({ subagentDisplayEnabled: false, subagentDoneNotifyEnabled: true })
  const childDisabled = world.calls.switches.find((sw) => sw.label === zh.subagentDoneNotifyEnabled)
  world.calls.edits.length = 0
  childDisabled.onChange(false)
  assert.deepEqual(world.calls.edits, [], '禁用的子开关不应产生编辑')
})

check('子智能体父开关默认渲染为关（维持 v2.0 行为），且能被点开', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  world.paint({ subagentDisplayEnabled: undefined, subagentDoneNotifyEnabled: undefined })
  const zh = world.dictionaries[0].dicts.zh
  const parent = world.calls.switches.find((sw) => sw.label === zh.subagentDisplayEnabled)
  const child = world.calls.switches.find((sw) => sw.label === zh.subagentDoneNotifyEnabled)
  assert.equal(parent.checked, false, '宿主默认 false，空值也必须回落成"关"')
  assert.equal(child.checked, true, '宿主默认 true，空值回落成"开"')
  assert.equal(child.disabled, true, '父开关是关的，子开关禁用')

  world.calls.edits.length = 0
  parent.onChange(true)
  assert.deepEqual(world.calls.edits, [{ field: 'subagentDisplayEnabled', text: 'true' }], '父开关要接对字段')
})

check('子智能体块的中英字典键齐全，且不出现需求 1 那截后缀的开关', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const { zh, en } = world.dictionaries[0].dicts
  for (const key of ['subagentTitle', 'subagentGroupHint', 'subagentDisplayEnabled',
    'subagentDisplayEnabledHint', 'subagentDoneNotifyEnabled', 'subagentDoneNotifyEnabledHint',
    'subagentGroupOff']) {
    assert.ok(zh[key] && en[key], `缺字典键 ${key}`)
  }
  // 需求 1 的后缀是硬性追加：界面上一个字都不许提
  const copy = visibleCopy(world, world.paint().texts)
  assert.ok(!copy.includes('子智能体仍在工作'), '需求 1 的后缀不能在配置页出现')
  assert.ok(!/\bsuffix\b/i.test(copy), '英文页同样不能提后缀开关')
})

// ── 5.6 v2.1 需求 4 的微信提醒块（两行独立开关 + 宿主可用性闸） ─────────────
check('微信块：两行开关默认都关（需求要求默认不开启），各自的时长禁用并给出提示', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const zh = world.dictionaries[0].dicts.zh
  const painted = world.paint({ wechatDoneEnabled: false, wechatWaitingEnabled: false })

  const switches = WECHAT.enabledFields.map((field) =>
    world.calls.switches.find((sw) => sw.label === zh[field]))
  for (const sw of switches) {
    assert.ok(sw, '两个微信开关都必须渲染出来')
    assert.equal(sw.checked, false, '宿主默认 false，界面也必须显示成关')
    assert.equal(sw.disabled, false, '默认关 ≠ 被锁：用户要能自己打开')
  }
  // 父开关（这里的"父"就是本行自己的开关）关掉 ⇒ 自己的时长输入框禁用
  for (const field of WECHAT.numberFields) {
    assert.equal(world.disabled(field), true, `${field} 应在开关关着时禁用`)
  }
  assert.equal(painted.texts.filter((line) => line === zh.wechatGroupOff).length, 2, '两行各提示一次')
  // 只影响本行：别的组和通用块不受影响
  assert.equal(world.disabled('notifyPersona'), false)
  assert.equal(world.disabled('waitingNotifyDelayMs'), false)
})

check('微信块：打开某一行 → 只解禁它自己的时长框，另一行不受影响', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  world.paint({ wechatDoneEnabled: true, wechatWaitingEnabled: false })
  assert.equal(world.disabled('wechatDoneDelayMs'), false, '开着的行可以改时长')
  assert.equal(world.disabled('wechatWaitingDelayMs'), true, '关着的行不许改时长')

  world.paint({ wechatDoneEnabled: false, wechatWaitingEnabled: true })
  assert.equal(world.disabled('wechatDoneDelayMs'), true)
  assert.equal(world.disabled('wechatWaitingDelayMs'), false)
})

check('微信块：两个开关各自接对字段（独立开关，不是共用一个父开关）', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  world.paint()
  const zh = world.dictionaries[0].dicts.zh
  world.calls.edits.length = 0
  for (const field of WECHAT.enabledFields) {
    const sw = world.calls.switches.find((item) => item.label === zh[field])
    sw.onChange(true)
  }
  assert.deepEqual(world.calls.edits, [
    { field: 'wechatDoneEnabled', text: 'true' },
    { field: 'wechatWaitingEnabled', text: 'true' },
  ])
})

await checkAsync('微信块：宿主说联动插件不可用 → 整节不可开启 + 显示宿主给的 reason', async () => {
  const reason = '未检测到 dsh-wechat-plugin'
  const world = createWorld({
    fetch: async () => ({ ok: true, status: 200, json: async () => ({ available: false, reason }) }),
  })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  const painted = world.paint()

  // ① 两个开关都被禁用（整节不可开启）
  for (const field of WECHAT.enabledFields) {
    const sw = world.calls.switches.find((item) => item.label === zh[field])
    assert.equal(sw.disabled, true, `不可用时 ${field} 必须禁用（灰掉）`)
  }
  // ② 两个时长框也禁用
  for (const field of WECHAT.numberFields) {
    assert.equal(world.disabled(field), true, `不可用时 ${field} 必须禁用`)
  }
  // ③ 原因文案用的是宿主 probe() 的 reason，而不是我们编的
  assert.ok(painted.texts.some((line) => line.includes(zh.wechatUnavailable)), '应显示"本节无法开启"')
  assert.ok(painted.texts.some((line) => line.includes(reason)), `应原样显示宿主给的原因：${painted.texts}`)
  assert.ok(world.fetchCalls.some((call) => call.url === WECHAT.statePath && call.init?.credentials === 'same-origin'),
    '走的是宿主自带的同源只读路由，且带 cookie')

  // ④ 禁用态下即便被点到也不许写入（避免"灰着还能改"的错觉）
  world.calls.edits.length = 0
  for (const field of WECHAT.enabledFields) {
    const sw = world.calls.switches.find((item) => item.label === zh[field])
    sw.onChange(true)
  }
  assert.deepEqual(world.calls.edits, [], '不可用的开关不应产生编辑')
})

await checkAsync('微信块：通道不通（fetch 抛 / 401）→ 判为"未知"，绝不误报成"插件缺失"', async () => {
  for (const impl of [
    async () => { throw new Error('network down') },
    async () => ({ ok: false, status: 401, json: async () => ({}) }),
  ]) {
    const world = createWorld({ fetch: impl })
    world.moduleExports.apply(world.ctx)
    await world.settle()
    const zh = world.dictionaries[0].dicts.zh
    const painted = world.paint()
    for (const field of WECHAT.enabledFields) {
      const sw = world.calls.switches.find((item) => item.label === zh[field])
      assert.equal(sw.disabled, false, '问不到 ≠ 插件不在：这种情况必须保持可用（发送侧另有严格拦截）')
    }
    assert.equal(painted.texts.some((line) => line.includes(zh.wechatUnavailable)), false,
      '不确定时不许显示"插件缺失"的结论')
  }
})

await checkAsync('微信块：宿主说可用 → 不显示"无法开启"，开关可以打开', async () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  const painted = world.paint()
  assert.equal(painted.texts.some((line) => line.includes(zh.wechatUnavailable)), false)
  for (const field of WECHAT.enabledFields) {
    const sw = world.calls.switches.find((item) => item.label === zh[field])
    assert.equal(sw.disabled, false)
  }
})

check('微信块的中英字典键齐全（四个字段 + 标题/提示/关闭/不可用 + v2.1.3 的重新检测）', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const { zh, en } = world.dictionaries[0].dicts
  const keys = ['wechatTitle', 'wechatGroupHint', 'wechatGroupOff', 'wechatUnavailable',
    'wechatRecheck', 'wechatRechecking', 'wechatRecheckHint',
    ...WECHAT.enabledFields, ...WECHAT.numberFields,
    ...WECHAT.enabledFields.map((field) => `${field}Hint`),
    ...WECHAT.numberFields.map((field) => `${field}Hint`)]
  for (const key of keys) {
    assert.ok(zh[key] && en[key], `缺字典键 ${key}`)
  }
})

// ── 5.7 v2.1.3：状态不许停在"页面加载那一刻" ────────────────────────────────
//
// 真机证据（README 第 11 节 v2.1.3）：20:43:17 探到"微信里还没有对话"，21:01:35
// 绑定才建立，而设置页一直显示 20:43 那次的结论 —— 因为控制器只在构造时 fetch 一次。
// 下面这几条把这个行为钉死：打开页面要重探、重渲染不许重探、按钮要强刷、失败仍是"未知"。
await checkAsync('v2.1.3：以 page 视图渲染会重新探测一次，同一次挂载内重渲染不再发请求', async () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  await world.settle()
  assert.equal(world.fetchCalls.length, 1, '构造控制器时先问一次（旧版本唯一的一次，就是"页面加载那一刻"）')
  assert.equal(world.fetchCalls[0].url, WECHAT.statePath, '构造那次走普通路径')

  // 插件行上的那句话（summary）不该探测
  world.render('summary')
  await world.settle()
  assert.equal(world.fetchCalls.length, 1, 'summary 视图只渲染一句话，不该发请求')

  // 点进「配置」：page 视图 ⇒ 重新探测一次
  world.paint({}, 'page')
  await world.settle()
  assert.equal(world.fetchCalls.length, 2, '打开配置页必须重新探测一次')
  assert.equal(world.fetchCalls.at(-1).url, WECHAT.statePath,
    '打开页面走普通路径：宿主 30 秒缓存继续挡住"来回点配置"，强刷是按钮的事')

  // 同一次挂载里继续渲染（编辑、重渲染、重新收集文案）：一次都不许再发
  world.paint()
  world.paint({ wechatDoneEnabled: true })
  world.texts(world.render('page'))
  await world.settle()
  assert.equal(world.fetchCalls.length, 2, '同一挂载周期只发一次；重渲染不重发（effect 的 deps 只有 view）')

  // view 变了才重发：page → summary → page
  world.render('summary')
  world.paint({}, 'page')
  await world.settle()
  assert.equal(world.fetchCalls.length, 3, 'view 变化时重发一次')
})

await checkAsync('v2.1.3：点「重新检测」带强刷参数，宿主改口后界面从禁用恢复可用', async () => {
  const reason = '微信里还没有对话，请先用手机给机器人发一条消息'
  let available = false
  const world = createWorld({
    fetch: async () => ({ ok: true, status: 200, json: async () => ({ available, reason: available ? '' : reason }) }),
  })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh

  // ① 宿主说不可用：整节灰掉 + 原样显示宿主给的原因（既有语义不变）
  const before = world.paint()
  for (const field of WECHAT.enabledFields) {
    const sw = world.calls.switches.find((item) => item.label === zh[field])
    assert.equal(sw.disabled, true, `不可用时 ${field} 必须禁用`)
  }
  assert.ok(before.texts.some((line) => line.includes(reason)), '原因要看得见')

  // ② 用户这时在手机上给机器人发了消息 → 宿主会改口
  available = true

  const button = world.calls.buttons.find((item) => item.children === zh.wechatRecheck)
  assert.ok(button, `微信这一节必须有「${zh.wechatRecheck}」按钮：${JSON.stringify(world.calls.buttons.map((b) => b.children))}`)
  assert.equal(button.disabled, false, '整节不可用时这个按钮必须仍然可点 —— 否则用户没有任何出路')

  button.onClick()
  // ③ 探测在飞：按钮禁用、文案变"检测中…"，但**上一轮的结论还在**（不闪、不擦）
  const flying = world.face().useTaskbarCard((snapshot) => snapshot).wechat
  assert.equal(flying.checking, true, '探测在飞时 checking 为真（按钮据此禁用）')
  assert.equal(flying.status, 'unavailable', '飞行中保留上一次结论，界面不先闪成"未知"')
  assert.equal(world.fetchCalls.at(-1).url, `${WECHAT.statePath}${WECHAT.refreshQuery}`,
    '「重新检测」必须带强刷参数，宿主据此先 invalidate() 再 probe()')

  await world.settle()
  const after = world.paint()
  for (const field of WECHAT.enabledFields) {
    const sw = world.calls.switches.find((item) => item.label === zh[field])
    assert.equal(sw.disabled, false, `强刷成功后 ${field} 必须恢复可开启`)
    assert.equal(sw.checked, false, '恢复可用 ≠ 自动打开：开关值仍是用户的设置')
  }
  assert.equal(world.disabled('wechatDoneDelayMs'), true, '开关还关着，时长框照旧禁用（与可用性无关的那条规则不变）')
  assert.equal(after.texts.some((line) => line.includes(zh.wechatUnavailable)), false,
    '刷新成功后"本节无法开启"的结论必须消失')
  assert.equal(after.texts.some((line) => line.includes(reason)), false, '旧原因必须一起清掉')
  assert.equal(world.calls.buttons.at(-1).children, zh.wechatRecheck, '探测结束后按钮回到常态文案')
})

await checkAsync('v2.1.3：强刷自身失败（fetch 抛 / 401）→ 仍按"未知"处理，不显示插件缺失', async () => {
  for (const mode of ['throw', '401']) {
    const reason = '未检测到 dsh-wechat-plugin'
    let failing = false
    const world = createWorld({
      fetch: async () => {
        if (failing) {
          if (mode === 'throw') throw new Error('network down')
          return { ok: false, status: 401, json: async () => ({}) }
        }
        return { ok: true, status: 200, json: async () => ({ available: false, reason }) }
      },
    })
    world.moduleExports.apply(world.ctx)
    await world.settle()
    const zh = world.dictionaries[0].dicts.zh
    world.paint()
    await world.settle()

    failing = true
    const button = world.calls.buttons.find((item) => item.children === zh.wechatRecheck)
    button.onClick()
    await world.settle()
    assert.equal(world.fetchCalls.at(-1).url, `${WECHAT.statePath}${WECHAT.refreshQuery}`, `${mode}：强刷请求照发`)

    const painted = world.paint()
    for (const field of WECHAT.enabledFields) {
      const sw = world.calls.switches.find((item) => item.label === zh[field])
      assert.equal(sw.disabled, false, `${mode}：问不到 ≠ 插件不在，必须保持可开启`)
    }
    assert.equal(painted.texts.some((line) => line.includes(zh.wechatUnavailable)), false,
      `${mode}：不确定时不许显示"插件缺失"的结论`)
    assert.equal(painted.texts.some((line) => line.includes(reason)), false,
      `${mode}：上一轮的旧原因也不许留着（它已经不成立了）`)
  }
})

await checkAsync('v2.1.3：重新检测按钮走中英两套字典，没有硬编码文案', async () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const { zh, en } = world.dictionaries[0].dicts
  // 先让构造期那次探测落地、再渲染：否则按钮显示的是"检测中…"（探测在飞）
  await world.settle()
  world.paint()
  await world.settle()
  assert.ok(world.calls.buttons.some((item) => item.children === zh.wechatRecheck), '中文界面用中文字典')
  world.setLocale('en')
  world.paint()
  await world.settle()
  assert.ok(world.calls.buttons.some((item) => item.children === en.wechatRecheck), '英文界面用英文字典')
  assert.ok(en.wechatRecheckHint && zh.wechatRecheckHint, '两个语种都要有说明文案')
  world.setLocale('zh')
})

await checkAsync('v2.1.3：探测在飞时按钮显示"检测中…"并禁用（打开页面那一刻就是这种状态）', async () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  // 故意不等构造期那次探测：此刻就是"探测在飞"
  const zh = world.dictionaries[0].dicts.zh
  world.paint()
  const flying = world.calls.buttons.at(-1)
  assert.equal(flying.children, zh.wechatRechecking, '在飞时按钮文案是"检测中…"')
  assert.equal(flying.disabled, true, '在飞时按钮禁用，避免连点把五道闸连着跑')
  await world.settle()
  world.paint()
  assert.equal(world.calls.buttons.at(-1).children, zh.wechatRecheck, '落地后按钮回到"重新检测"且可点')
  assert.equal(world.calls.buttons.at(-1).disabled, false)
})

// ── 6. 硬性 UI 要求 ───────────────────────────────────────────────────────
check('渲染结果里没有「故障」字样（该功能不可关闭，界面不提供任何选项）', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const zh = visibleCopy(world, world.paint().texts)
  assert.ok(!zh.includes('故障'), '配置页必须完全不提故障提醒')
  // "default" 里含 "fault"，所以英文按整词匹配
  world.setLocale('en')
  const en = visibleCopy(world, world.paint().texts)
  world.setLocale('zh')
  assert.ok(!/\bfault\b/i.test(en), '英文页同样不能出现故障提醒')
  assert.ok(!/\bfailure\b/i.test(en), '也不该有 failure 相关的措辞')
})

check('渲染结果里没有旧配置键名，也没有故意不上界面的键', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const zh = visibleCopy(world, world.paint().texts)
  for (const key of BANNED_KEYS) assert.ok(!zh.includes(key), `界面上不该出现 ${key}`)
  for (const field of world.calls.valueFields) {
    for (const key of BANNED_KEYS) assert.ok(!field.id.includes(key), `控件 id 里不该出现 ${key}`)
  }
})

check('文案带单位：中文毫秒/分钟，英文 (ms)/(minutes)', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const zh = visibleCopy(world, world.paint().texts)
  assert.ok(zh.includes('毫秒'), '①② 的时长要标毫秒')
  assert.ok(zh.includes('分钟'), '③ 的时长要标分钟')
  world.setLocale('en')
  const en = visibleCopy(world, world.paint().texts)
  world.setLocale('zh')
  assert.ok(en.includes('(ms)'))
  assert.ok(en.includes('(minutes)'))
})

check('三组标题、通用块与 v2.1 子智能体块、微信块都渲染出来了', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const copy = visibleCopy(world, world.paint().texts)
  const zh = world.dictionaries[0].dicts.zh
  for (const key of ['generalTitle', 'waitingTitle', 'reviewTitle', 'driftTitle', 'subagentTitle', 'wechatTitle']) {
    assert.ok(copy.includes(zh[key]), `缺了 ${key} 的标题`)
  }
  // 每组标题各一次
  assert.equal(copy.split(zh.waitingTitle).length - 1, 1)
  assert.equal(copy.split(zh.driftTitle).length - 1, 1)
  assert.equal(copy.split(zh.subagentTitle).length - 1, 1)
  assert.equal(copy.split(zh.wechatTitle).length - 1, 1)
})

// ── 7. 字典与 jsx 调用规范 ────────────────────────────────────────────────
check('zh / en 字典键集一致，每条都是非空字符串，且渲染用到的键都在', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  world.setLocale('en')
  world.paint()
  world.setLocale('zh')
  world.paint()
  const { zh, en } = world.dictionaries[0].dicts
  assert.deepEqual(new Set(Object.keys(zh)), new Set(Object.keys(en)))
  for (const [locale, dict] of [['zh', zh], ['en', en]]) {
    for (const [key, value] of Object.entries(dict)) {
      assert.equal(typeof value, 'string', `${locale}.${key} 应是字符串`)
      assert.ok(value.length > 0, `${locale}.${key} 不应为空`)
    }
  }
  assert.deepEqual([...world.missingKeys], [], '渲染过程中有取不到的字典键')
  // 字段名与提示键必须成对存在
  for (const field of EXPECTED_FIELDS) {
    assert.ok(zh[field] && en[field], `${field} 缺 label`)
    if (!field.endsWith('Enabled')) assert.ok(zh[`${field}Hint`] && en[`${field}Hint`], `${field} 缺 hint`)
  }
})

check('jsx 调用规范：key 只走第三个参数，没有重复 key', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  world.paint()
  world.paint({ waitingNotifyEnabled: false, reviewNotifyEnabled: false, driftNotifyEnabled: false })
  assert.deepEqual(world.calls.duplicateKeys, [], 'config 里和第三个参数里同时给 key 属于不规范写法')
})

// ── 5.8 v2.2.0：两条通道的界面（联动提示 / 独立连接） ────────────────────────
//
// 需求原文：检测到联动插件且可用 → 显示「请在联动插件设置界面连接」，**不再显示本插件
// 自己的二维码/连接按钮**（避免重复连接）；未检测到或不可用 → 显示「连接微信」按钮，
// 点下去要能出二维码、刷新二维码、显示状态、要验证码、已连接时能断开/重连，
// 并且**必须**显示那两句踩过坑的人话。
//
// 这一节全是结构级断言（假 fetch / 假原语），真机渲染仍要在 DSH 桌面端点一遍。

/** v2.2.0：独立连接的动作路径（必须与 lib/client.js 的 WECHAT_ACTION_PATHS 一致）。 */
const WECHAT_ACTIONS = {
  login: `${WECHAT.statePath}/login`,
  verify: `${WECHAT.statePath}/verify`,
  cancel: `${WECHAT.statePath}/cancel`,
  disconnect: `${WECHAT.statePath}/disconnect`,
}

/** 独立通道 status() 的默认快照（契约里的十个字段；v2.2.1 加了 tokenFallback）。 */
const standaloneOf = (overrides = {}) => ({
  phase: 'disconnected',
  qrContent: '',
  qrRefreshed: false,
  verifyAttempts: 0,
  accountId: '',
  peerId: '',
  error: '',
  connected: false,
  tokenFallback: false,
  ...overrides,
})

/**
 * 造一个"独立模式"的世界：GET 回宿主状态，POST 回动作结果。
 *
 * @param options.standalone - status() 快照
 * @param options.onPost - (url) => 下一次 GET 要回的状态（模拟"点完连接出现二维码"）
 */
function createStandaloneWorld(options = {}) {
  const reason = options.reason ?? '未检测到 dsh-wechat-plugin'
  const base = {
    available: options.available === true,
    reason: options.available === true ? '' : reason,
    mode: 'standalone',
    linked: { available: false, reason },
    standalone: options.standalone ?? standaloneOf(),
    standaloneReady: options.standaloneReady !== false,
    standaloneError: options.standaloneError ?? '',
  }
  let current = base
  const posts = []
  const world = createWorld({
    fetch: async (url, init) => {
      if (init?.method === 'POST') {
        posts.push({ url, body: init.body === undefined ? undefined : JSON.parse(init.body) })
        if (options.postThrows === true) throw new Error('network down')
        if (typeof options.onPost === 'function') {
          const next = options.onPost(url, posts.length)
          if (next !== undefined) current = next
        }
        return {
          ok: true,
          status: 200,
          json: async () => ({
            ok: options.postOk !== false,
            error: options.postError ?? '',
            state: current,
          }),
        }
      }
      return { ok: true, status: 200, json: async () => current }
    },
  })
  return { world, posts, state: () => current, setState: (next) => { current = next } }
}

/** 把一棵渲染树里的某类元素挑出来。 */
const elementsOf = (world, type) => world.calls.elements.filter((element) => element.type === type)

await checkAsync('v2.2.0：联动可用 → 只显示「请在联动插件设置界面连接」，不显示自己的二维码/连接按钮', async () => {
  const world = createWorld({
    fetch: async () => ({
      ok: true,
      status: 200,
      json: async () => ({
        available: true,
        reason: '',
        mode: 'linked',
        linked: { available: true, reason: '' },
        standalone: null,
        standaloneReady: false,
        standaloneError: '',
      }),
    }),
  })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  const painted = world.paint()
  // ① 提示文案在
  assert.ok(painted.texts.includes(zh.wechatLinkedHint), `应显示"去联动插件设置界面连接"：${painted.texts}`)
  // ② 本插件自己的连接入口**一个都不许有**（避免两条连接同时连同一个微信号）
  const labels = world.calls.buttons.map((button) => button.children)
  for (const banned of [zh.wechatConnect, zh.wechatRefreshQr, zh.wechatReconnect, zh.wechatDisconnect, zh.wechatCancel]) {
    assert.ok(!labels.includes(banned), `联动可用时不该出现「${banned}」按钮`)
  }
  assert.equal(elementsOf(world, 'img').length, 0, '联动可用时不该显示本插件的二维码')
  assert.equal(elementsOf(world, 'input').length, 0, '联动可用时不该显示验证码输入框')
  assert.equal(painted.texts.includes(zh.wechatScanHint), false, '那两句人话属于独立连接块，联动模式下不渲染')
  assert.equal(painted.texts.includes(zh.wechatUnavailable), false, '可用时不该显示"不可用"结论')
})

await checkAsync('v2.2.0：宿主没给 mode（旧宿主 / 探测失败）→ 不做任何模式专属展示（问不到 ≠ 没有）', async () => {
  const world = createWorld({
    fetch: async () => ({ ok: true, status: 200, json: async () => ({ available: false, reason: '未检测到 dsh-wechat-plugin' }) }),
  })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  const painted = world.paint()
  const labels = world.calls.buttons.map((button) => button.children)
  assert.ok(!labels.includes(zh.wechatConnect), '宿主没说过有独立通道，就不能冒出「连接微信」这个假入口')
  assert.equal(painted.texts.includes(zh.wechatLinkedHint), false, '没 mode 也不该显示"去联动插件"这句')
  // 但"不可用 + 原因"照旧要显示（v2.1.3 的行为一个字不改）
  assert.ok(painted.texts.some((line) => line.includes(zh.wechatUnavailable)))
  assert.ok(painted.texts.some((line) => line.includes('未检测到 dsh-wechat-plugin')))
})

await checkAsync('v2.2.0：独立模式（未连接）→ 显示「连接微信」按钮 + 两句人话；点按钮 POST /login', async () => {
  const { world, posts } = createStandaloneWorld()
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  const painted = world.paint()

  // 两句人话：这是踩过坑的硬要求，必须原样出现
  assert.ok(painted.texts.includes(zh.wechatScanHint), `缺第一句人话：${painted.texts}`)
  assert.ok(painted.texts.includes(zh.wechatBindHint), `缺第二句人话：${painted.texts}`)
  assert.equal(
    zh.wechatScanHint,
    '扫码后如果要求输入数字，请输入手机微信上显示的那串验证码',
    '第一句人话必须逐字一致',
  )
  assert.equal(
    zh.wechatBindHint,
    '连上后请先用手机给机器人发一条消息，之后才能主动推送提醒',
    '第二句人话必须逐字一致',
  )
  // 状态行显示"未连接"
  assert.ok(painted.texts.includes(zh.wechatPhaseDisconnected))

  const connect = world.calls.buttons.find((button) => button.children === zh.wechatConnect)
  assert.ok(connect, `要有「${zh.wechatConnect}」按钮：${JSON.stringify(world.calls.buttons.map((b) => b.children))}`)
  assert.equal(connect.disabled, false)
  connect.onClick()
  await world.settle()
  assert.deepEqual(posts, [{ url: WECHAT_ACTIONS.login, body: {} }], '点「连接微信」应 POST /login')
})

await checkAsync('v2.2.0：点完连接 → 二维码用 <img src="data:..."> 渲染；刷新二维码 POST {refresh:true}', async () => {
  const qrImage = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUg=='
  const { world, posts } = createStandaloneWorld({
    // 点完 /login，宿主回来的状态就是"等待扫码 + 已经渲染好的 data URL"
    onPost: () => ({
      available: false,
      reason: '未检测到 dsh-wechat-plugin',
      mode: 'standalone',
      linked: { available: false, reason: '未检测到 dsh-wechat-plugin' },
      standalone: standaloneOf({
        phase: 'awaiting-scan',
        qrContent: 'https://liteapp.weixin.qq.com/q/7GiQu1?qrcode=deadbeef&bot_type=3',
        qrImage,
      }),
      standaloneReady: true,
      standaloneError: '',
    }),
  })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  world.paint()
  world.calls.buttons.find((button) => button.children === zh.wechatConnect).onClick()
  await world.settle()

  const painted = world.paint()
  const images = elementsOf(world, 'img')
  assert.equal(images.length, 1, `要显示一张二维码：${JSON.stringify(world.calls.elements.map((e) => e.type))}`)
  assert.equal(images[0].props.src, qrImage, '二维码就是宿主渲染好的 data URL，直接当图片用')
  assert.equal(images[0].props.alt, zh.wechatQrAlt)
  assert.ok(painted.texts.includes(zh.wechatPhaseAwaitingScan), '状态要显示"等待扫码"')

  // 刷新二维码 = 先取消再重来（宿主那边就是 refresh 语义）
  const refresh = world.calls.buttons.find((button) => button.children === zh.wechatRefreshQr)
  assert.ok(refresh, '要有「刷新二维码」按钮')
  refresh.onClick()
  await world.settle()
  assert.deepEqual(posts.at(-1), { url: WECHAT_ACTIONS.login, body: { refresh: true } })

  // 登录在飞时给一个「取消」出口
  const cancel = world.calls.buttons.find((button) => button.children === zh.wechatCancel)
  assert.ok(cancel, '等待扫码时应提供「取消」')
  cancel.onClick()
  await world.settle()
  assert.deepEqual(posts.at(-1), { url: WECHAT_ACTIONS.cancel, body: {} })
})

await checkAsync('v2.2.0：二维码渲染不出来 → 原样显示 payload 并标注 TODO（不假装有图）', async () => {
  const raw = 'https://liteapp.weixin.qq.com/q/7GiQu1?qrcode=deadbeef&bot_type=3'
  const { world } = createStandaloneWorld({ standalone: standaloneOf({ phase: 'awaiting-scan', qrContent: raw }) })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  const painted = world.paint()
  assert.equal(elementsOf(world, 'img').length, 0, '没有 qrImage 就不该编一张图出来')
  assert.ok(painted.texts.includes(raw), '原始 payload 要原样给用户（还能自己复制去转二维码）')
  assert.ok(painted.texts.includes(zh.wechatQrTodo), '并且明确标注 TODO，而不是默默什么都不显示')
})

await checkAsync('v2.2.0：需要验证码 → 数字输入框 + 提交；空输入不发请求、显示本地提示', async () => {
  const { world, posts } = createStandaloneWorld({ standalone: standaloneOf({ phase: 'awaiting-verify', verifyAttempts: 1 }) })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  const painted = world.paint()

  const input = elementsOf(world, 'input')[0]
  assert.ok(input, '要有验证码输入框')
  assert.equal(input.props.type, 'text')
  assert.equal(input.props.inputMode, 'numeric', '手机键盘应该是数字键盘')
  assert.equal(input.props.placeholder, zh.wechatVerifyPlaceholder)
  assert.ok(painted.texts.includes(zh.wechatVerifyLabel), '必须有「请输入手机微信上显示的数字」这句话')
  assert.ok(painted.texts.includes(zh.wechatPhaseAwaitingVerify))

  const submit = world.calls.buttons.find((button) => button.children === zh.wechatVerifySubmit)
  assert.ok(submit, '要有「提交」按钮')

  // ① 空输入：不发请求，本地给一句人话
  submit.onClick()
  await world.settle()
  assert.deepEqual(posts, [], '空验证码不该发请求（宿主那边是 400）')
  assert.ok(world.paint().texts.some((line) => line.includes(zh.wechatVerifyRequired)), '空输入要有人话提示')

  // ② 填了数字：POST /verify，body 带 code
  input.props.onChange({ target: { value: ' 1234 ' } })
  submit.onClick()
  await world.settle()
  assert.deepEqual(posts, [{ url: WECHAT_ACTIONS.verify, body: { code: '1234' } }], '验证码要去空格后提交')
})

await checkAsync('v2.2.0：已连接 → 显示「已连接微信」+「断开连接」「重新连接」', async () => {
  const { world, posts } = createStandaloneWorld({
    available: true,
    standalone: standaloneOf({ phase: 'connected', connected: true, accountId: 'acct-1' }),
  })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  const painted = world.paint()
  assert.ok(painted.texts.includes(zh.wechatPhaseConnected), '要显示「已连接微信」')
  const labels = world.calls.buttons.map((button) => button.children)
  assert.ok(labels.includes(zh.wechatDisconnect))
  assert.ok(labels.includes(zh.wechatReconnect))
  assert.ok(!labels.includes(zh.wechatConnect))

  world.calls.buttons.find((button) => button.children === zh.wechatDisconnect).onClick()
  await world.settle()
  assert.deepEqual(posts.at(-1), { url: WECHAT_ACTIONS.disconnect, body: {} })

  world.calls.buttons.find((button) => button.children === zh.wechatReconnect).onClick()
  await world.settle()
  assert.deepEqual(posts.at(-1), { url: WECHAT_ACTIONS.login, body: { refresh: true } }, '重新连接 = 先取消再重来')
})

await checkAsync('v2.2.0：连接失败 / 断开 → 明确提示「连接已失效，请重新扫码」并展示通道给的原因', async () => {
  const { world } = createStandaloneWorld({
    standalone: standaloneOf({ phase: 'failed', error: '二维码反复过期' }),
  })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  const painted = world.paint()
  assert.ok(painted.texts.includes(zh.wechatPhaseFailed), '状态要显示"连接失败"')
  assert.ok(painted.texts.includes(zh.wechatFailedHint), '要告诉用户重新扫码')
  assert.ok(painted.texts.some((line) => line.includes('二维码反复过期')), '通道给的原因要原样显示')
})

await checkAsync('v2.2.0：独立模块不可用（还没交付）→ 按钮禁用 + 显示原因，不假装能连', async () => {
  const { world, posts } = createStandaloneWorld({
    standalone: null,
    standaloneReady: false,
    standaloneError: 'Cannot find module ./wechat-standalone.js',
  })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  const painted = world.paint()
  const connect = world.calls.buttons.find((button) => button.children === zh.wechatConnect)
  assert.ok(connect, '仍然要显示入口（让用户知道有这条路）')
  assert.equal(connect.disabled, true, '模块不可用时按钮必须禁用，别让用户点了没反应')
  assert.ok(painted.texts.some((line) => line.includes(zh.wechatModuleMissing)), '要说清是独立连接模块不可用')
  assert.ok(painted.texts.some((line) => line.includes('wechat-standalone.js')), '并带上原因')
  connect.onClick()
  await world.settle()
  assert.deepEqual(posts, [], '禁用状态即便被点到也不该发请求')
})

await checkAsync('v2.2.0：动作请求失败（网络不通）→ 界面显示"最近一次错误"，不静默失败', async () => {
  const { world } = createStandaloneWorld({ postThrows: true })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  world.paint()
  world.calls.buttons.find((button) => button.children === zh.wechatConnect).onClick()
  await world.settle()
  const painted = world.paint()
  const line = painted.texts.find((text) => text.includes(zh.wechatLastError))
  assert.ok(line, `要显示"最近一次错误"这一行：${painted.texts}`)
  assert.ok(line.includes('network down'), '错误原因要看得见（不静默）')
})

await checkAsync('v2.2.0：动作被宿主拒绝（ok:false）→ 显示宿主给的原因', async () => {
  const { world } = createStandaloneWorld({ postOk: false, postError: '验证码没有被接受，请重新扫码或再输一次' })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  world.paint()
  world.calls.buttons.find((button) => button.children === zh.wechatConnect).onClick()
  await world.settle()
  const painted = world.paint()
  assert.ok(painted.texts.some((text) => text.includes('验证码没有被接受')), `宿主的原因要原样显示：${painted.texts}`)
})

await checkAsync('v2.2.0：探测通道不通时也留下"最近一次错误"（v2.1.3 的"未知"语义不变）', async () => {
  const world = createWorld({ fetch: async () => { throw new Error('network down') } })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  const painted = world.paint()
  for (const field of WECHAT.enabledFields) {
    const sw = world.calls.switches.find((item) => item.label === zh[field])
    assert.equal(sw.disabled, false, '问不到 ≠ 插件不在（v2.1.3 的语义一个字不改）')
  }
  assert.equal(painted.texts.some((line) => line.includes(zh.wechatUnavailable)), false)
  assert.ok(painted.texts.some((line) => line.includes(zh.wechatLastError)), '但错误要看得见')
})

check('v2.2.0：独立连接相关的中英字典键齐全（按钮/状态/两句人话/验证码/错误）', () => {
  const world = createWorld()
  world.moduleExports.apply(world.ctx)
  const { zh, en } = world.dictionaries[0].dicts
  for (const key of [
    'wechatLinkedHint', 'wechatStandaloneLead', 'wechatConnect', 'wechatConnecting', 'wechatReconnect',
    'wechatDisconnect', 'wechatCancel', 'wechatRefreshQr', 'wechatQrAlt', 'wechatScanHint', 'wechatBindHint',
    'wechatVerifyLabel', 'wechatVerifyPlaceholder', 'wechatVerifySubmit', 'wechatVerifyRequired',
    'wechatQrTodo', 'wechatFailedHint', 'wechatModuleMissing', 'wechatLastError',
    'wechatPhaseDisconnected', 'wechatPhaseConnecting', 'wechatPhaseAwaitingScan',
    'wechatPhaseAwaitingVerify', 'wechatPhaseConnected', 'wechatPhaseFailed',
  ]) {
    assert.ok(typeof zh[key] === 'string' && zh[key].length > 0, `中文缺字典键 ${key}`)
    assert.ok(typeof en[key] === 'string' && en[key].length > 0, `英文缺字典键 ${key}`)
  }
})

await checkAsync('v2.2.0：宿主报来的"最近一次发送失败"也会显示在界面上（不静默）', async () => {
  // 发送是宿主侧异步发生的，界面只能靠状态路由带回来的 lastError 看见
  const { world, setState } = createStandaloneWorld()
  setState({
    available: true,
    reason: '',
    mode: 'standalone',
    linked: { available: false, reason: '未检测到 dsh-wechat-plugin' },
    standalone: standaloneOf({ phase: 'connected', connected: true }),
    standaloneReady: true,
    standaloneError: '',
    lastError: '微信回信窗口已关闭，请先用手机给机器人发一条消息',
  })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  const painted = world.paint()
  const line = painted.texts.find((text) => text.includes(zh.wechatLastError))
  assert.ok(line, `要显示"最近一次错误"：${painted.texts}`)
  assert.ok(line.includes('微信回信窗口已关闭'), '宿主报的原因要原样显示')
})

await checkAsync('v2.2.0：独立模式不漏英文枚举值，也没有「故障」字样（中英各渲染一遍）', async () => {
  // 用一个"认不出的相位"驱动：界面必须回落成"未连接"，而不是把 `weird-phase` 漏出去
  const { world } = createStandaloneWorld({ standalone: standaloneOf({ phase: 'weird-phase' }) })
  world.moduleExports.apply(world.ctx)
  await world.settle()
  const zh = world.dictionaries[0].dicts.zh
  for (const locale of ['zh', 'en']) {
    world.setLocale(locale)
    const painted = world.paint()
    const copy = visibleCopy(world, painted.texts)
    assert.ok(!copy.includes('weird-phase'), `${locale}：认不出的相位要回落成"未连接"，不能漏枚举值`)
    assert.ok(painted.texts.includes(locale === 'zh' ? zh.wechatPhaseDisconnected : world.dictionaries[0].dicts.en.wechatPhaseDisconnected))
    assert.ok(!copy.includes('故障'), `${locale}：配置页仍然不许出现「故障」字样`)
    assert.ok(!/\bfault\b/i.test(copy), `${locale}：英文页同样不许出现 fault`)
  }
  world.setLocale('zh')
})

console.log(`\nclient: ${passed} 项全部通过\n`)
