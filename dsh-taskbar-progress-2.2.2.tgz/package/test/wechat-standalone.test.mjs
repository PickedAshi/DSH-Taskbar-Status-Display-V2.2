/**
 * 微信 openclaw 独立连接 · **凭据持久化 + 登录状态机 + 发送**单测。
 *
 * 全部离线：`fetchImpl` / `sleep` / `now` / `store` 全注入；
 * 持久化部分用**临时目录**里的真文件（不碰 `~/.dsh/wechat/`）。
 * 不联网、不 spawn、不发真消息。
 *
 *   node test/wechat-standalone.test.mjs
 */

import assert from 'node:assert/strict'
import { existsSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync, writeFileSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'

import { CREDENTIALS_FILE_MODE, createWechatStore } from '../lib/wechat-store.js'
import {
  DEFAULT_LOGIN_TIMEOUT_MS,
  DEFAULT_MAX_QR_REFRESH,
  DEFAULT_MAX_VERIFY_ATTEMPTS,
  DEFAULT_POLL_INTERVAL_MS,
  STANDALONE_CREDENTIALS_VERSION,
  UNKNOWN_SESSION_TITLE,
  buildStandaloneNoticeText,
  createStandaloneChannel,
} from '../lib/wechat-standalone.js'

let passed = 0
const check = (label, fn) => {
  fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}
const checkAsync = async (label, fn) => {
  await fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

/* ------------------------------------------------------------------ 通用夹具 */

/** 假时钟：sleep 会推进它，于是"5 分钟超时"在测试里是瞬间的事。 */
function makeClock(start = 1_700_000_000_000) {
  let value = start
  return {
    now: () => value,
    advance: (ms) => {
      value += ms
    },
    get value() {
      return value
    },
  }
}

/** 假 fetch：记录 url / method / headers / body；handler 决定响应。 */
function makeFetch(handler) {
  const calls = []
  const fetchImpl = async (url, init = {}) => {
    if (init.signal?.aborted === true) {
      const error = new Error('The operation was aborted')
      error.name = 'AbortError'
      throw error
    }
    const call = {
      url,
      method: init.method,
      headers: init.headers ?? {},
      body: typeof init.body === 'string' ? JSON.parse(init.body) : init.body,
    }
    calls.push(call)
    const reply = (await handler(call, calls.length - 1)) ?? {}
    if (reply instanceof Error) throw reply
    const status = reply.status ?? 200
    return {
      ok: status >= 200 && status < 300,
      status,
      async json() {
        return reply.body ?? {}
      },
      async text() {
        return reply.text ?? JSON.stringify(reply.body ?? {})
      },
    }
  }
  return { fetchImpl, calls }
}

const qrReply = (qrcode = 'QR-1', image = 'IMG-1') => ({ status: 200, body: { qrcode, qrcode_img_content: image } })
const statusReply = (status, extra = {}) => ({ status: 200, body: { status, ...extra } })

const CRED = Object.freeze({
  version: 1,
  account: {
    accountId: 'acct-1',
    token: 'tk-existing',
    baseUrl: 'https://ilinkai.weixin.qq.com',
    userId: 'user-1',
    savedAt: '2026-01-01T00:00:00.000Z',
    boundAt: '2026-01-01T00:00:00.000Z',
  },
  peerId: 'peer-existing',
  conversationId: 'acct-1:peer-existing',
  contextToken: 'ctx-existing',
  savedAt: '2026-01-01T00:00:00.000Z',
})

const clone = (value) => (value === undefined ? undefined : structuredClone(value))

/** 内存 store 替身：只实现接口契约里的方法（外加 standalone 会用的两个可选项）。 */
function makeStore({ credentials, shared = {}, saveThrows = false } = {}) {
  // ⚠️ `accountIds` / `sharedAccountIds` 是**诱饵**（v2.2.1）：真 store 已经删掉这个方法，
  //    这里故意留着，任何一次调用都会被计数，用例里断言它必须是 0 ——
  //    谁要是再把 accountId 混进 local_token_list，这里会立刻响。
  const calls = { load: 0, saves: [], clears: 0, accountIds: 0, tokens: 0, peerFor: [], bindingFor: [] }
  let current = clone(credentials)
  let sharedState = clone(shared)
  return {
    calls,
    /** 模拟"别的进程在我们启动之后写了凭据文件"。 */
    setCredentials(next) {
      current = clone(next)
    },
    /** 模拟"共享 state.json 后来才出现"。 */
    setShared(next) {
      sharedState = clone(next)
    },
    loadCredentials() {
      calls.load += 1
      return clone(current)
    },
    saveCredentials(next) {
      if (saveThrows) throw new Error('磁盘满了')
      calls.saves.push(clone(next))
      current = clone(next)
      return true
    },
    clearCredentials() {
      calls.clears += 1
      current = undefined
      return true
    },
    sharedAccountIds() {
      calls.accountIds += 1
      return sharedState.accountIds ?? []
    },
    sharedTokens() {
      calls.tokens += 1
      return sharedState.tokens ?? []
    },
    sharedPeerFor(accountId) {
      calls.peerFor.push(accountId)
      return sharedState.bindings?.[accountId]?.peerId
    },
    sharedBindingFor(accountId) {
      calls.bindingFor.push(accountId)
      return sharedState.bindings?.[accountId]
    },
    get current() {
      return current
    },
  }
}

/** 契约最小替身：只有文档里承诺的 4 个方法（验证 standalone 不对扩展方法硬依赖）。 */
function makeMinimalStore({ credentials } = {}) {
  let current = clone(credentials)
  const calls = { saves: [], clears: 0 }
  return {
    calls,
    loadCredentials: () => clone(current),
    saveCredentials: (next) => {
      calls.saves.push(clone(next))
      current = clone(next)
      return true
    },
    clearCredentials: () => {
      calls.clears += 1
      current = undefined
      return true
    },
    sharedPeerFor: () => undefined,
    get current() {
      return current
    },
  }
}

/** 组装一个通道：假时钟 + 假 fetch + 假 store + 记录 log/debug。 */
function harness({ handler, store = makeStore(), options = {}, onSleep } = {}) {
  const clock = makeClock()
  const logs = []
  const traces = []
  const phases = []
  const fetchBox = makeFetch(handler ?? (() => statusReply('wait')))
  const sleeper = { onSleep }
  const channel = createStandaloneChannel({
    log: (level, message) => logs.push({ level, message }),
    debug: (event, data) => traces.push({ event, data }),
    store,
    fetchImpl: fetchBox.fetchImpl,
    now: clock.now,
    sleep: async (ms) => {
      clock.advance(ms)
      if (sleeper.onSleep) {
        phases.push(channel.status().phase)
        sleeper.onSleep(ms)
      }
      await new Promise((resolve) => setImmediate(resolve))
    },
    ...options,
  })
  return { channel, clock, logs, traces, phases, store, calls: fetchBox.calls, sleeper }
}

/** 只是"把共享文件写一份"的辅助（共享文件永远只读，这里由测试自己造）。 */
function writeShared(home, state) {
  const dir = join(home, '.dsh', 'wechat')
  mkdirSync(dir, { recursive: true })
  const text = `${JSON.stringify(state, null, 2)}\n`
  writeFileSync(join(dir, 'state.json'), text, { mode: 0o600 })
  return text
}

/* ------------------------------------------------------------------ 临时目录 */

const tempDirs = []
function makeTempHome() {
  const dir = mkdtempSync(join(tmpdir(), 'dsh-wechat-standalone-'))
  tempDirs.push(dir)
  return dir
}
process.on('exit', () => {
  for (const dir of tempDirs) {
    try {
      rmSync(dir, { recursive: true, force: true })
    } catch {
      /* 清理失败不影响结论 */
    }
  }
})

const SHARED_SAMPLE = {
  version: 1,
  accounts: {
    'acct-shared': {
      accountId: 'acct-shared',
      token: 'tk-shared',
      baseUrl: 'https://ilinkai.weixin.qq.com',
      userId: 'user-shared',
      savedAt: '2026-02-02T00:00:00.000Z',
      boundAt: '2026-02-02T00:00:00.000Z',
    },
  },
  bindings: {
    'acct-shared:peer-shared': {
      conversationId: 'acct-shared:peer-shared',
      accountId: 'acct-shared',
      peerId: 'peer-shared',
      sessionId: 'session-x',
      title: '手机上的对话',
    },
  },
  contextTokens: {
    'acct-shared': { 'acct-shared:peer-shared': 'ctx-shared' },
  },
}

/* ================================================================== 凭据持久化 */

console.log('微信独立连接 · 凭据持久化（临时目录，真文件）')

check('saveCredentials：落盘形状 + 2 空格缩进 + 结尾换行 + version', () => {
  const home = makeTempHome()
  const store = createWechatStore({ home })
  assert.equal(store.saveCredentials(CRED), true)
  const file = store.paths.credentialsFile
  assert.equal(file, join(home, '.dsh', 'wechat', 'standalone.json'), '路径必须从 home 推导')
  assert.equal(existsSync(file), true)
  const text = readFileSync(file, 'utf8')
  assert.ok(text.endsWith('\n'), '结尾必须有换行')
  assert.ok(text.includes('\n  "account": {'), '必须是 2 空格缩进')
  const parsed = JSON.parse(text)
  assert.equal(parsed.version, STANDALONE_CREDENTIALS_VERSION)
  assert.equal(parsed.account.accountId, 'acct-1')
  assert.equal(parsed.account.token, 'tk-existing')
  assert.equal(parsed.peerId, 'peer-existing')
  assert.equal(parsed.contextToken, 'ctx-existing')
  assert.equal(typeof parsed.savedAt, 'string')
})

check('saveCredentials：权限 0600（POSIX 可见；Windows 只映射只读位，见说明）', () => {
  const home = makeTempHome()
  const store = createWechatStore({ home })
  store.saveCredentials(CRED)
  const mode = store.credentialsMode()
  // Windows 的 statSync 不反映 POSIX mode（一律报 0o666）：那条断言只在 POSIX 上作数。
  // 这里同时钉住"我们请求的就是 0600"这个事实（常量即契约）。
  assert.equal(CREDENTIALS_FILE_MODE, 0o600, '请求的权限必须逐字是 0600')
  if (process.platform === 'win32') {
    assert.equal(mode, 0o666, 'Windows 上 mode 报告不出 0600，这是平台限制不是实现问题')
  } else {
    assert.equal(mode, 0o600)
  }
  assert.notEqual(mode & 0o200, 0, '文件必须可写（否则下次保存会失败）')
})

check('原子写：目录里不留临时文件，重复写内容完整（覆盖）', () => {
  const home = makeTempHome()
  const store = createWechatStore({ home })
  store.saveCredentials(CRED)
  store.saveCredentials({ ...CRED, peerId: 'peer-2' })
  const files = readdirSync(store.paths.stateDir)
  assert.deepEqual(files, ['standalone.json'], `目录里不该有临时文件残留：${files.join(',')}`)
  const parsed = JSON.parse(readFileSync(store.paths.credentialsFile, 'utf8'))
  assert.equal(parsed.peerId, 'peer-2')
  assert.equal(statSync(store.paths.credentialsFile).size > 0, true)
})

check('loadCredentials：读回自己写的凭据（round-trip）', () => {
  const home = makeTempHome()
  const store = createWechatStore({ home })
  store.saveCredentials(CRED)
  const loaded = store.loadCredentials()
  assert.equal(loaded.account.accountId, 'acct-1')
  assert.equal(loaded.account.token, 'tk-existing')
  assert.equal(loaded.account.baseUrl, 'https://ilinkai.weixin.qq.com')
  assert.equal(loaded.account.userId, 'user-1')
  assert.equal(loaded.peerId, 'peer-existing')
  assert.equal(loaded.conversationId, 'acct-1:peer-existing')
  assert.equal(loaded.contextToken, 'ctx-existing')
  assert.equal(loaded.version, 1)
})

check('共享 state.json 从不被写：内容逐字节不变，也没有临时文件', () => {
  const home = makeTempHome()
  const before = writeShared(home, SHARED_SAMPLE)
  const store = createWechatStore({ home })
  store.loadCredentials()
  store.sharedTokens()
  store.sharedPeerFor('acct-shared')
  store.saveCredentials(CRED)
  store.clearCredentials()
  const after = readFileSync(store.paths.sharedFile, 'utf8')
  assert.equal(after, before, '共享文件必须逐字节不变')
  assert.deepEqual(readdirSync(store.paths.stateDir).sort(), ['state.json'], '共享文件旁边不该多出任何东西')
  assert.equal(store.paths.sharedFile.endsWith('state.json'), true)
  assert.equal(store.paths.credentialsFile.endsWith('standalone.json'), true)
})

check('迁移回退：只有共享文件时读出 account + binding + contextToken，并留 debug 一笔', () => {
  const home = makeTempHome()
  writeShared(home, SHARED_SAMPLE)
  const traces = []
  const store = createWechatStore({ home, debug: (event, data) => traces.push({ event, data }) })
  const loaded = store.loadCredentials()
  assert.equal(loaded.account.accountId, 'acct-shared')
  assert.equal(loaded.account.token, 'tk-shared')
  assert.equal(loaded.peerId, 'peer-shared')
  assert.equal(loaded.conversationId, 'acct-shared:peer-shared')
  assert.equal(loaded.contextToken, 'ctx-shared')
  assert.equal(loaded.version, 1)
  assert.equal(existsSync(store.paths.credentialsFile), false, '迁移是只读的：不能顺手落盘')
  const migrateTrace = traces.find((entry) => entry.data?.event === 'migrate')
  assert.ok(migrateTrace, '迁移必须留一笔诊断')
  assert.equal(migrateTrace.data.source, 'shared')
  assert.equal(migrateTrace.data.hasContextToken, true)
})

check('自己的文件优先于共享文件', () => {
  const home = makeTempHome()
  writeShared(home, SHARED_SAMPLE)
  const store = createWechatStore({ home })
  store.saveCredentials(CRED)
  const loaded = store.loadCredentials()
  assert.equal(loaded.account.accountId, 'acct-1')
  assert.equal(loaded.account.token, 'tk-existing')
})

check('自己的文件坏掉（非法 JSON）→ 回退到共享', () => {
  const home = makeTempHome()
  writeShared(home, SHARED_SAMPLE)
  const store = createWechatStore({ home })
  mkdirSync(store.paths.stateDir, { recursive: true })
  writeFileSync(store.paths.credentialsFile, '{"version":1,"account":', 'utf8')
  const loaded = store.loadCredentials()
  assert.equal(loaded.account.accountId, 'acct-shared')
})

check('两边都没有 → undefined（不抛）', () => {
  const home = makeTempHome()
  const store = createWechatStore({ home })
  assert.equal(store.loadCredentials(), undefined)
  assert.equal(store.readSharedState(), undefined)
  assert.equal(store.sharedPeerFor('acct-x'), undefined)
  // v2.2.1：`sharedAccountIds()` 已删除（它只会诱导后人把 accountId 混进 local_token_list）
  assert.equal(typeof store.sharedAccountIds, 'undefined')
})

check('迁移时 account 里没有 token → 当作没有凭据（不返回半截）', () => {
  const home = makeTempHome()
  writeShared(home, { version: 1, accounts: { 'acct-x': { accountId: 'acct-x', baseUrl: 'https://x' } } })
  const store = createWechatStore({ home })
  assert.equal(store.loadCredentials(), undefined)
})

check('sharedTokens / sharedPeerFor 都从共享文件读（accountId 已经没有对应 API）', () => {
  const home = makeTempHome()
  writeShared(home, SHARED_SAMPLE)
  const store = createWechatStore({ home })
  assert.deepEqual(store.sharedTokens(), ['tk-shared'])
  assert.equal(store.sharedPeerFor('acct-shared'), 'peer-shared')
  assert.equal(store.sharedPeerFor('nope'), undefined)
  assert.deepEqual(store.sharedBindingFor('acct-shared'), {
    conversationId: 'acct-shared:peer-shared',
    peerId: 'peer-shared',
    contextToken: 'ctx-shared',
  })
})

check('saveCredentials：凭据不完整直接拒绝（不写出坏文件）', () => {
  const home = makeTempHome()
  const logs = []
  const store = createWechatStore({ home, log: (level, message) => logs.push({ level, message }) })
  assert.equal(store.saveCredentials({ account: { accountId: 'a' } }), false)
  assert.equal(store.saveCredentials(undefined), false)
  assert.equal(existsSync(store.paths.credentialsFile), false)
  assert.ok(logs.some((entry) => entry.level === 'warn' && entry.message.includes('凭据不完整')))
})

check('clearCredentials：只删自己的文件，共享原封不动', () => {
  const home = makeTempHome()
  const before = writeShared(home, SHARED_SAMPLE)
  const store = createWechatStore({ home })
  store.saveCredentials(CRED)
  assert.equal(store.clearCredentials(), true)
  assert.equal(existsSync(store.paths.credentialsFile), false)
  assert.equal(readFileSync(store.paths.sharedFile, 'utf8'), before)
  assert.equal(store.clearCredentials(), true, '重复清理不报错')
})

/* ================================================================== 状态机 */

console.log('\n微信独立连接 · 登录状态机')

check('status()：初始快照形状固定，且不读盘两次', () => {
  const store = makeStore()
  const h = harness({ store })
  const snapshot = h.channel.status()
  assert.deepEqual(Object.keys(snapshot).sort(), [
    'accountId',
    'connected',
    'error',
    'peerId',
    'phase',
    'qrContent',
    'qrRefreshed',
    'tokenFallback',
    'verifyAttempts',
  ])
  assert.equal(snapshot.phase, 'disconnected')
  assert.equal(snapshot.connected, false)
  assert.equal(snapshot.qrContent, undefined)
  assert.equal(snapshot.qrRefreshed, 0)
  assert.equal(snapshot.verifyAttempts, 0)
  assert.equal(snapshot.error, undefined)
  assert.equal(snapshot.tokenFallback, false, '没降级过就是 false（不是 undefined）')
  assert.equal(h.channel.isConnected(), false)
  h.channel.status()
  h.channel.status()
  h.channel.isConnected()
  assert.equal(store.calls.load, 1, '凭据只该懒加载一次')
})

check('默认参数与契约一致（1s 轮询 / 刷 3 次 / 验 3 次 / 5 分钟）', () => {
  assert.equal(DEFAULT_POLL_INTERVAL_MS, 1_000)
  assert.equal(DEFAULT_MAX_QR_REFRESH, 3)
  assert.equal(DEFAULT_MAX_VERIFY_ATTEMPTS, 3)
  assert.equal(DEFAULT_LOGIN_TIMEOUT_MS, 5 * 60_000)
  assert.equal(UNKNOWN_SESSION_TITLE, '未知对话')
})

check('已有凭据 → 开机即 connected，startLogin 不再走扫码', async () => {
  const store = makeStore({ credentials: CRED })
  const h = harness({ store, handler: () => qrReply() })
  assert.equal(h.channel.isConnected(), true)
  const snapshot = h.channel.status()
  assert.equal(snapshot.phase, 'connected')
  assert.equal(snapshot.accountId, 'acct-1')
  assert.equal(snapshot.peerId, 'peer-existing')
  return h.channel.startLogin().then((result) => {
    assert.deepEqual(result, { ok: true, phase: 'connected' })
    assert.equal(h.calls.length, 0, '已经连上了就不该再取码')
  })
})

await checkAsync('startLogin 幂等：并发第二次调用返回 pending，不会起第二条轮询', async () => {
  const h = harness({
    handler: (call) => {
      if (call.url.includes('get_bot_qrcode')) return qrReply()
      return statusReply('wait')
    },
    options: { loginTimeoutMs: 2_000, pollIntervalMs: 1_000 },
  })
  const first = h.channel.startLogin()
  const second = await h.channel.startLogin()
  assert.equal(second.pending, true)
  assert.equal(second.ok, false)
  assert.ok(['connecting', 'awaiting-scan'].includes(second.phase), `phase=${second.phase}`)
  const final = await first
  assert.equal(final.ok, false)
  assert.equal(h.calls.filter((call) => call.url.includes('get_bot_qrcode')).length, 1, '只该取一次码')
})

await checkAsync('startLogin：取码 → wait → scaned → confirmed 全流程', async () => {
  const store = makeStore({ shared: { accountIds: ['acct-shared'], tokens: ['tk-shared'] } })
  let poll = 0
  const h = harness({
    store,
    handler: (call) => {
      if (call.url.includes('get_bot_qrcode')) return qrReply('QR-ENC', 'data:image/png;base64,IMG')
      poll += 1
      if (poll === 1) return statusReply('wait')
      if (poll === 2) return statusReply('scaned')
      return statusReply('confirmed', {
        bot_token: 'tk-new',
        ilink_bot_id: 'acct-new',
        baseurl: 'https://ilinkai.weixin.qq.com',
        ilink_user_id: 'user-new',
      })
    },
  })

  // 取码之后立刻看一眼快照：二维码内容必须**原样**透传，不做任何加工
  const result = await h.channel.startLogin()
  assert.deepEqual(result, { ok: true, phase: 'connected' })
  const snapshot = h.channel.status()
  assert.equal(snapshot.phase, 'connected')
  assert.equal(snapshot.connected, true)
  assert.equal(snapshot.accountId, 'acct-new')
  assert.equal(snapshot.error, undefined)
  assert.equal(snapshot.qrRefreshed, 0)
  assert.equal(snapshot.qrContent, undefined, '登录成功后二维码内容要清掉')

  assert.equal(store.calls.saves.length, 1)
  const saved = store.calls.saves[0]
  assert.equal(saved.account.accountId, 'acct-new')
  assert.equal(saved.account.token, 'tk-new')
  assert.equal(saved.account.baseUrl, 'https://ilinkai.weixin.qq.com')
  assert.equal(saved.account.userId, 'user-new')
  assert.equal(saved.version, STANDALONE_CREDENTIALS_VERSION)

  // GET 轮询不许带 Authorization / UIN
  const pollCalls = h.calls.filter((call) => call.url.includes('get_qrcode_status'))
  assert.ok(pollCalls.length >= 3)
  for (const call of pollCalls) {
    assert.equal(call.method, 'GET')
    assert.deepEqual(Object.keys(call.headers).sort(), ['iLink-App-ClientVersion', 'iLink-App-Id'])
  }
})

/* ------------------------------------------------- v2.2.1：local_token_list 只放 token + 兜底 */

/**
 * 假服务端：**照真机行为**校验 `local_token_list`（见 `lib/wechat-proto.js` 文件头那张表，
 * 2026-10-13 实测）。
 *
 *  · 列表里**只要有一个不是有效 token**（例如混进了 accountId）→ **整批**失败：
 *    `{ret:-3, err_msg:'batch verify bot token fail'}`；
 *  · 空列表 → 照常出码（真机就是如此）；
 *  · `failEmpty` = 连空列表都失败（模拟"服务端/网络真的坏了"，用于验"兜底失败才算失败"）；
 *  · `networkError` = 取码请求直接抛网络异常（不该触发兜底）。
 */
function qrFake({ validTokens = [], failEmpty = false, networkError = false } = {}) {
  return (call) => {
    if (!call.url.includes('get_bot_qrcode')) {
      return statusReply('confirmed', { bot_token: 'tk-new', ilink_bot_id: 'acct-new' })
    }
    if (networkError) return new Error('socket hang up')
    const list = call.body.local_token_list
    const rejected = list.length === 0 ? failEmpty : !list.every((item) => validTokens.includes(item))
    if (rejected) return { status: 200, body: { ret: -3, err_msg: 'batch verify bot token fail' } }
    return qrReply('QR-OK', 'IMG-OK')
  }
}

/** 取码请求的次数与每次带上去的列表（`local_token_list` 的现场）。 */
const qrLists = (h) =>
  h.calls.filter((call) => call.url.includes('get_bot_qrcode')).map((call) => call.body.local_token_list)

await checkAsync('startLogin：local_token_list **只放 token**（自己 + 共享），一个 accountId 都不许有', async () => {
  const store = makeStore({ shared: { accountIds: ['acct-shared'], tokens: ['tk-shared'] } })
  const h = harness({ store, handler: qrFake({ validTokens: ['tk-existing', 'tk-shared'] }) })
  // 现场：UI 启动时读过一次（那时文件还没出现），随后凭据才落到自己的文件里
  h.channel.status()
  store.setCredentials(CRED)
  const result = await h.channel.startLogin()
  const list = qrLists(h)[0]
  // 真机证据（2026-10-13）：混进 accountId 会让**整批**校验失败（ret:-3），用户拿不到二维码
  assert.ok(list.includes('tk-existing'), '自己文件里的 token 必须在（否则会被重新绑定）')
  assert.ok(list.includes('tk-shared'), '共享 token 必须在')
  assert.equal(list.includes('acct-shared'), false, '⚠️ accountId 绝不能进这个列表（本次真机 bug 的成因）')
  assert.equal(list.some((item) => item.includes('@')), false, '列表里不许有任何"像 accountId"的东西')
  assert.equal(new Set(list).size, list.length, '不能重复')
  assert.equal(store.calls.accountIds, 0, '连问都不该去问 accountId')
  assert.equal(result.ok, true, '只放 token 就该正常出码')
  assert.equal(qrLists(h).length, 1, '没失败就不该重试')
  assert.equal(h.channel.status().tokenFallback, false)
})

await checkAsync('startLogin：旧 token 失效（ret:-3）→ 自动用**空列表重试一次**，并留下可查的降级痕迹', async () => {
  const store = makeStore({ shared: { tokens: ['tk-stale'] } })
  // 真 token 一个都不认 = "连接已失效，请重新扫码"的现场
  const h = harness({ store, handler: qrFake({ validTokens: [] }) })
  const result = await h.channel.startLogin()
  const lists = qrLists(h)
  assert.equal(lists.length, 2, '第一次带 token 失败、第二次空列表：**只重试一次**')
  assert.deepEqual(lists[0], ['tk-stale'])
  assert.deepEqual(lists[1], [], '兜底用的必须是空列表')
  assert.equal(result.ok, true, '空列表取到码照样登录成功')
  assert.equal(h.channel.status().phase, 'connected')
  assert.equal(h.channel.status().tokenFallback, true, '上层要能知道"旧绑定没能复用"')
  // 诊断与 info 日志都要有，而且**不许出现 token 本身**
  const fallback = h.traces.find((entry) => entry.data?.event === 'qr-token-fallback')
  assert.ok(fallback, '降级必须留一笔诊断')
  assert.equal(fallback.data.knownTokens, 1)
  assert.equal(fallback.data.ret, -3)
  assert.ok(String(fallback.data.errmsg).includes('batch verify bot token fail'))
  assert.ok(
    h.logs.some((entry) => entry.level === 'info' && entry.message.includes('空 token 列表')),
    '要有一条中文 info 说明降级了',
  )
  const dump = JSON.stringify({ logs: h.logs, traces: h.traces })
  assert.equal(dump.includes('tk-stale'), false, '降级日志里绝不能出现 token')
})

await checkAsync('startLogin：空列表也失败 → 才判失败，错误里带着服务端原话，且前缀只有一层', async () => {
  const store = makeStore({ shared: { tokens: ['tk-stale'] } })
  const h = harness({ store, handler: qrFake({ validTokens: [], failEmpty: true }) })
  const result = await h.channel.startLogin()
  assert.equal(result.ok, false)
  assert.equal(result.phase, 'failed')
  assert.equal(qrLists(h).length, 2, '兜底只试一次，不能死循环')
  assert.match(result.error, /ret=-3/)
  assert.match(result.error, /err_msg=batch verify bot token fail/)
  // 真机 bug 的原话是 `获取二维码失败：获取二维码失败：服务端未返回 qrcode` —— 前缀只能一层
  assert.equal(result.error.split('获取二维码失败').length - 1, 1, `前缀只该出现一次：${result.error}`)
  assert.equal(h.channel.status().error, result.error)
  assert.ok(h.logs.some((entry) => entry.level === 'warn' && entry.message.includes('err_msg=batch verify bot token fail')))
})

await checkAsync('startLogin：网络异常 → 不兜底、不重试，文案只包一层前缀', async () => {
  const store = makeStore({ shared: { tokens: ['tk-stale'] } })
  const h = harness({ store, handler: qrFake({ networkError: true }) })
  const result = await h.channel.startLogin()
  assert.equal(result.ok, false)
  assert.equal(qrLists(h).length, 1, '网络炸了不是 token 的问题，不该用空列表重试')
  assert.equal(result.error, '获取二维码失败：socket hang up')
  assert.equal(result.error.split('获取二维码失败').length - 1, 1)
  assert.equal(h.traces.some((entry) => entry.data?.event === 'qr-token-fallback'), false)
  assert.equal(h.channel.status().tokenFallback, false)
})

await checkAsync('startLogin：本来就没有已知 token → 空列表直接失败，不做"降级重试"', async () => {
  const store = makeStore()
  const h = harness({ store, handler: qrFake({ failEmpty: true }) })
  const result = await h.channel.startLogin()
  assert.equal(result.ok, false)
  assert.equal(qrLists(h).length, 1, '没有可降级的余地，就不该多发一次请求')
  assert.deepEqual(qrLists(h)[0], [])
  assert.equal(result.error.split('获取二维码失败').length - 1, 1)
})

await checkAsync('startLogin：qrContent 原样透传服务端的 qrcode_img_content', async () => {
  let seen
  const h = harness({
    handler: (call) => {
      if (call.url.includes('get_bot_qrcode')) return qrReply('QR-ENC', '<img src="data:image/png;base64,AAA">')
      seen = h.channel.status().qrContent
      return statusReply('confirmed', { bot_token: 't', ilink_bot_id: 'a' })
    },
  })
  await h.channel.startLogin()
  assert.equal(seen, '<img src="data:image/png;base64,AAA">')
})

/* ---------------------------------------------------------------- 8 个 status 分支 */

await checkAsync('分支 wait：继续轮询（不会把 wait 当错误）', async () => {
  let polls = 0
  const h = harness({
    handler: (call) => {
      if (call.url.includes('get_bot_qrcode')) return qrReply()
      polls += 1
      return polls < 3 ? statusReply('wait') : statusReply('confirmed', { bot_token: 't', ilink_bot_id: 'a' })
    },
    options: { loginTimeoutMs: 60_000 },
  })
  const result = await h.channel.startLogin()
  assert.equal(result.ok, true)
  assert.equal(polls, 3)
  assert.ok(h.traces.some((entry) => entry.data?.event === 'qr-ready'))
})

await checkAsync('分支 scaned：清掉 verifyCode，后续轮询不再带它', async () => {
  let poll = 0
  const h = harness({
    handler: (call) => {
      if (call.url.includes('get_bot_qrcode')) return qrReply()
      poll += 1
      if (poll === 1) return statusReply('need_verifycode')
      if (poll === 2) return statusReply('scaned')
      return statusReply('confirmed', { bot_token: 't', ilink_bot_id: 'a' })
    },
  })
  h.sleeper.onSleep = () => h.channel.provideVerifyCode('4321')
  const result = await h.channel.startLogin()
  assert.equal(result.ok, true)
  const polls = h.calls.filter((call) => call.url.includes('get_qrcode_status'))
  assert.ok(polls[1].url.includes('verify_code=4321'), '提交后那一轮要带上验证码')
  assert.equal(polls[2].url.includes('verify_code'), false, 'scaned 之后必须清掉')
})

await checkAsync('分支 need_verifycode：进入 awaiting-verify，provideVerifyCode 返回 true', async () => {
  let poll = 0
  const submitted = []
  const h = harness({
    handler: (call) => {
      if (call.url.includes('get_bot_qrcode')) return qrReply()
      poll += 1
      if (poll === 1) return statusReply('need_verifycode')
      return statusReply('confirmed', { bot_token: 't', ilink_bot_id: 'a' })
    },
  })
  let accepted
  h.sleeper.onSleep = () => {
    if (h.channel.status().phase === 'awaiting-verify') {
      accepted = h.channel.provideVerifyCode('8888')
      submitted.push(h.channel.status().verifyAttempts)
    }
  }
  const result = await h.channel.startLogin()
  assert.equal(result.ok, true)
  assert.equal(accepted, true)
  assert.ok(h.phases.includes('awaiting-verify'), `等待期间快照应是 awaiting-verify：${h.phases.join(',')}`)
  assert.deepEqual(submitted, [0], '提交前 verifyAttempts 还是 0')
  const poll2 = h.calls.filter((call) => call.url.includes('get_qrcode_status'))[1]
  assert.ok(poll2.url.includes('verify_code=8888'))
  assert.equal(h.channel.status().verifyAttempts, 1)
})

await checkAsync('分支 verify_code_blocked：终止并给出"验证码被锁定，请稍后重试"', async () => {
  const h = harness({
    handler: (call) => (call.url.includes('get_bot_qrcode') ? qrReply() : statusReply('verify_code_blocked')),
  })
  const result = await h.channel.startLogin()
  assert.deepEqual(result, { ok: false, phase: 'failed', error: '验证码被锁定，请稍后重试' })
  assert.equal(h.channel.status().error, '验证码被锁定，请稍后重试')
  assert.ok(h.logs.some((entry) => entry.level === 'warn' && entry.message.includes('验证码被锁定')))
})

await checkAsync('分支 expired：重新取二维码（同一张作废），qrRefreshed 递增', async () => {
  let qrCount = 0
  let statusCount = 0
  const h = harness({
    handler: (call) => {
      if (call.url.includes('get_bot_qrcode')) {
        qrCount += 1
        return qrReply(`QR-${qrCount}`, `IMG-${qrCount}`)
      }
      statusCount += 1
      if (statusCount === 1) return statusReply('expired')
      return statusReply('confirmed', { bot_token: 't', ilink_bot_id: 'a' })
    },
  })
  let secondQrContent
  h.sleeper.onSleep = () => {
    if (h.channel.status().qrRefreshed === 1) secondQrContent = h.channel.status().qrContent
  }
  const result = await h.channel.startLogin()
  assert.equal(result.ok, true)
  assert.equal(qrCount, 2, '过期后必须重新取码')
  assert.equal(secondQrContent, undefined, 'onSleep 只在 nap 时触发，这里只用于断言不炸')
  assert.equal(h.traces.some((entry) => entry.data?.event === 'qr-refresh'), true)
})

await checkAsync('分支 scaned_but_redirect：baseUrl 换成 https://redirect_host 并沿用同一 qrcode', async () => {
  let poll = 0
  const h = harness({
    handler: (call) => {
      if (call.url.includes('get_bot_qrcode')) return qrReply('QR-KEEP')
      poll += 1
      if (poll === 1) return statusReply('scaned_but_redirect', { redirect_host: 'redirect.example.com' })
      return statusReply('confirmed', { bot_token: 't', ilink_bot_id: 'a' })
    },
  })
  const result = await h.channel.startLogin()
  assert.equal(result.ok, true)
  const polls = h.calls.filter((call) => call.url.includes('get_qrcode_status'))
  assert.ok(polls[0].url.startsWith('https://ilinkai.weixin.qq.com/'))
  assert.ok(polls[1].url.startsWith('https://redirect.example.com/'), polls[1].url)
  assert.ok(polls[1].url.includes('qrcode=QR-KEEP'), '同一张二维码继续轮询')
})

await checkAsync('分支 scaned_but_redirect：redirect_host 缺失时忽略，不改 baseUrl（不崩）', async () => {
  let poll = 0
  const h = harness({
    handler: (call) => {
      if (call.url.includes('get_bot_qrcode')) return qrReply('QR-KEEP')
      poll += 1
      if (poll === 1) return statusReply('scaned_but_redirect')
      return statusReply('confirmed', { bot_token: 't', ilink_bot_id: 'a' })
    },
  })
  assert.equal((await h.channel.startLogin()).ok, true)
  const polls = h.calls.filter((call) => call.url.includes('get_qrcode_status'))
  assert.ok(polls[1].url.startsWith('https://ilinkai.weixin.qq.com/'))
})

await checkAsync('分支 binded_redirect：成功，且**不覆盖**已有凭据', async () => {
  const store = makeStore()
  const h = harness({
    store,
    handler: (call) =>
      call.url.includes('get_bot_qrcode')
        ? qrReply()
        : statusReply('binded_redirect', { bot_token: 'tk-should-be-ignored', ilink_bot_id: 'acct-other' }),
  })
  // 现场：进程启动时还没有凭据，扫码期间才发现"其实本地已经有了"
  h.channel.status()
  store.setCredentials(CRED)
  const result = await h.channel.startLogin()
  assert.equal(result.ok, true, 'binded_redirect 是成功分支')
  assert.equal(h.channel.status().phase, 'connected')
  assert.equal(h.channel.status().accountId, 'acct-1', '必须沿用本地已有账号，而不是响应里的 acct-other')
  assert.equal(store.calls.saves.length, 0, '已有绑定不许覆盖已有凭据：一个字节都不该写')
  const list = h.calls[0].body.local_token_list
  assert.ok(list.includes('tk-existing'), '取码时必须带上自己已知的 token，否则会被重新绑定')
})

await checkAsync('分支 binded_redirect：本地确实没有凭据时才采用响应里的凭据', async () => {
  const store = makeStore()
  const h = harness({
    store,
    handler: (call) =>
      call.url.includes('get_bot_qrcode')
        ? qrReply()
        : statusReply('binded_redirect', { bot_token: 'tk-adopt', ilink_bot_id: 'acct-adopt' }),
  })
  const result = await h.channel.startLogin()
  assert.equal(result.ok, true)
  assert.equal(store.calls.saves.length, 1)
  assert.equal(store.calls.saves[0].account.accountId, 'acct-adopt')
  assert.equal(store.calls.saves[0].account.token, 'tk-adopt')
})

await checkAsync('分支 binded_redirect：本地没凭据、响应也没给 → 失败（不能假装连上）', async () => {
  const store = makeStore()
  const h = harness({
    store,
    handler: (call) => (call.url.includes('get_bot_qrcode') ? qrReply() : statusReply('binded_redirect')),
  })
  const result = await h.channel.startLogin()
  assert.equal(result.ok, false)
  assert.equal(result.phase, 'failed')
  assert.match(result.error, /重新扫码/)
  assert.equal(h.channel.isConnected(), false)
})

await checkAsync('分支 confirmed：baseUrl 用响应里的 baseurl，userId 用 ilink_user_id', async () => {
  const store = makeStore()
  const h = harness({
    store,
    handler: (call) =>
      call.url.includes('get_bot_qrcode')
        ? qrReply()
        : statusReply('confirmed', {
            bot_token: 'tk-x',
            ilink_bot_id: 'acct-x',
            baseurl: 'https://redirect.example.com',
            ilink_user_id: 'user-x',
          }),
  })
  assert.equal((await h.channel.startLogin()).ok, true)
  const saved = store.calls.saves[0]
  assert.equal(saved.account.baseUrl, 'https://redirect.example.com')
  assert.equal(saved.account.userId, 'user-x')
})

await checkAsync('分支 confirmed：baseurl 缺失时沿用当前 baseUrl', async () => {
  const store = makeStore()
  const h = harness({
    store,
    handler: (call) =>
      call.url.includes('get_bot_qrcode') ? qrReply() : statusReply('confirmed', { bot_token: 'tk-x', ilink_bot_id: 'acct-x' }),
  })
  await h.channel.startLogin()
  assert.equal(store.calls.saves[0].account.baseUrl, 'https://ilinkai.weixin.qq.com')
})

await checkAsync('分支 confirmed：响应缺 bot_token/ilink_bot_id → 失败（不落半截凭据）', async () => {
  const store = makeStore()
  const h = harness({
    store,
    handler: (call) => (call.url.includes('get_bot_qrcode') ? qrReply() : statusReply('confirmed', { ilink_bot_id: 'acct-only' })),
  })
  const result = await h.channel.startLogin()
  assert.equal(result.phase, 'failed')
  assert.match(result.error, /登录响应不完整/)
  assert.equal(store.calls.saves.length, 0)
})

await checkAsync('未知 status：记一笔继续等，不崩（最终 confirmed）', async () => {
  let poll = 0
  const h = harness({
    handler: (call) => {
      if (call.url.includes('get_bot_qrcode')) return qrReply()
      poll += 1
      return poll === 1 ? statusReply('new_status_from_future') : statusReply('confirmed', { bot_token: 't', ilink_bot_id: 'a' })
    },
  })
  assert.equal((await h.channel.startLogin()).ok, true)
  assert.ok(h.traces.some((entry) => entry.data?.event === 'unknown-status'))
})

/* ---------------------------------------------------------------- 上限与超时 */

await checkAsync('二维码刷新上限：刷满 3 次仍 expired → 失败（共取码 4 次）', async () => {
  const h = harness({
    handler: (call) => (call.url.includes('get_bot_qrcode') ? qrReply() : statusReply('expired')),
  })
  const result = await h.channel.startLogin()
  assert.equal(result.phase, 'failed')
  assert.match(result.error, /二维码已多次过期/)
  assert.equal(h.calls.filter((call) => call.url.includes('get_bot_qrcode')).length, 1 + DEFAULT_MAX_QR_REFRESH)
  assert.equal(h.channel.status().qrRefreshed, DEFAULT_MAX_QR_REFRESH)
})

await checkAsync('登录超时：一直 wait → failed"登录超时，请重试"（时钟由 sleep 推进）', async () => {
  const h = harness({
    handler: (call) => (call.url.includes('get_bot_qrcode') ? qrReply() : statusReply('wait')),
    options: { loginTimeoutMs: 5_000, pollIntervalMs: 1_000 },
  })
  const result = await h.channel.startLogin()
  assert.equal(result.ok, false)
  assert.equal(result.phase, 'failed')
  assert.equal(result.error, '登录超时，请重试')
  assert.ok(h.clock.value >= 1_700_000_000_000 + 5_000)
})

await checkAsync('验证码尝试上限：连错 3 次后终止，只提交过 3 次', async () => {
  let submitted = 0
  const h = harness({
    handler: (call) => (call.url.includes('get_bot_qrcode') ? qrReply() : statusReply('need_verifycode')),
  })
  h.sleeper.onSleep = () => {
    if (h.channel.provideVerifyCode('0000')) submitted += 1
  }
  const result = await h.channel.startLogin()
  assert.equal(result.phase, 'failed')
  assert.equal(result.error, '验证码错误次数过多，请稍后重试')
  assert.equal(submitted, DEFAULT_MAX_VERIFY_ATTEMPTS)
  assert.equal(h.channel.status().verifyAttempts, DEFAULT_MAX_VERIFY_ATTEMPTS)
})

await checkAsync('provideVerifyCode：没在等验证码时返回 false（含非法输入）', async () => {
  const h = harness({ handler: (call) => (call.url.includes('get_bot_qrcode') ? qrReply() : statusReply('confirmed', { bot_token: 't', ilink_bot_id: 'a' })) })
  assert.equal(h.channel.provideVerifyCode('1234'), false, '还没开始登录')
  await h.channel.startLogin()
  assert.equal(h.channel.provideVerifyCode('1234'), false, '已经连上了')
  assert.equal(h.channel.provideVerifyCode(''), false)
  assert.equal(h.channel.provideVerifyCode(undefined), false)
})

await checkAsync('cancelLogin：等验证码时取消 → 返回 disconnected，之后不再发请求', async () => {
  const h = harness({
    handler: (call) => (call.url.includes('get_bot_qrcode') ? qrReply() : statusReply('need_verifycode')),
  })
  let cancelled = false
  h.sleeper.onSleep = () => {
    if (!cancelled && h.channel.status().phase === 'awaiting-verify') {
      cancelled = true
      h.channel.cancelLogin()
    }
  }
  const result = await h.channel.startLogin()
  assert.deepEqual(result, { ok: false, phase: 'disconnected' })
  assert.equal(h.channel.status().error, undefined, '取消不是失败，不该留 error')
  const countAfterCancel = h.calls.length
  await new Promise((resolve) => setImmediate(resolve))
  assert.equal(h.calls.length, countAfterCancel, '取消后不该再发请求')
})

await checkAsync('取码失败（网络炸了）→ ok:false + failed + 中文原因，绝不抛', async () => {
  const h = harness({ handler: () => new Error('socket hang up') })
  const result = await h.channel.startLogin()
  assert.equal(result.ok, false)
  assert.equal(result.phase, 'failed')
  assert.match(result.error, /获取二维码失败/)
  assert.ok(h.logs.some((entry) => entry.level === 'warn' && entry.message.includes('获取二维码失败')))
  assert.ok(h.traces.some((entry) => entry.event === 'wechat-standalone' && entry.data?.event === 'login-failed'))
})

await checkAsync('轮询单次网络异常不致命：记一笔继续等到 confirmed', async () => {
  let poll = 0
  const h = harness({
    handler: (call) => {
      if (call.url.includes('get_bot_qrcode')) return qrReply()
      poll += 1
      if (poll === 1) return new Error('ECONNRESET')
      return statusReply('confirmed', { bot_token: 't', ilink_bot_id: 'a' })
    },
  })
  const result = await h.channel.startLogin()
  assert.equal(result.ok, true)
  assert.ok(h.traces.some((entry) => entry.data?.event === 'poll-error'))
})

await checkAsync('登录失败之后可以重来（第二次 startLogin 真的重新开始）', async () => {
  let fail = true
  const h = harness({
    handler: (call) => {
      if (call.url.includes('get_bot_qrcode')) return qrReply()
      if (fail) {
        fail = false
        return statusReply('verify_code_blocked')
      }
      return statusReply('confirmed', { bot_token: 't', ilink_bot_id: 'a' })
    },
  })
  assert.equal((await h.channel.startLogin()).phase, 'failed')
  const second = await h.channel.startLogin()
  assert.equal(second.ok, true)
  assert.equal(h.channel.status().error, undefined, '重试成功后旧 error 要清掉')
})

/* ================================================================== 发送 */

console.log('\n微信独立连接 · 发送任务提醒')

check('文案逐字：done / waiting / 未知标题兜底 / 未知 kind', () => {
  const done = buildStandaloneNoticeText({ title: '任务栏进度条', kind: 'done' })
  assert.equal(done, '您在任务栏进度条对话中的任务 已完成，请及时处理。')
  assert.equal(buildStandaloneNoticeText({ title: '任务栏进度条', kind: 'waiting' }), '您在任务栏进度条对话中的任务 等待选择，请及时处理。')
  assert.equal(buildStandaloneNoticeText({ title: '   ', kind: 'done' }), '您在未知对话对话中的任务 已完成，请及时处理。')
  assert.equal(buildStandaloneNoticeText({ title: undefined, kind: 'waiting' }), '您在未知对话对话中的任务 等待选择，请及时处理。')
  assert.equal(buildStandaloneNoticeText({ title: 'x', kind: 'whatever' }), undefined)

  // 逐字符钉住标点：状态词前是**半角空格 U+0020**，逗号 U+FF0C，句末 U+3002
  assert.equal(done.charCodeAt(done.length - 1), 0x3002, '句末必须是 U+3002')
  const commaIndex = done.indexOf('已完成')
  assert.equal(done.charCodeAt(commaIndex + 3), 0xff0c, '逗号必须是全角 U+FF0C')
  assert.equal(done.charCodeAt(commaIndex - 1), 0x20, '状态词前必须是半角空格 U+0020')
  assert.equal(done.includes('['), false, '标题两侧不带方括号（与 lib/wechat.js 现有文案一致）')
})

await checkAsync('sendTaskNotice(done)：文案逐字 + 走 to_user_id/context_token', async () => {
  const store = makeStore({ credentials: CRED })
  const h = harness({ store, handler: () => statusReply('x') })
  const result = await h.channel.sendTaskNotice({ title: '任务栏进度条', kind: 'done' })
  assert.deepEqual(result, { ok: true })
  assert.equal(h.calls.length, 1)
  const call = h.calls[0]
  assert.equal(call.url, 'https://ilinkai.weixin.qq.com/ilink/bot/sendmessage')
  assert.equal(call.method, 'POST')
  assert.equal(call.headers.Authorization, 'Bearer tk-existing')
  assert.equal(call.body.msg.to_user_id, 'peer-existing')
  assert.equal(call.body.msg.context_token, 'ctx-existing')
  assert.equal(call.body.msg.item_list[0].text_item.text, '您在任务栏进度条对话中的任务 已完成，请及时处理。')
})

await checkAsync('sendTaskNotice(waiting)：文案逐字（含方括号标题原样保留）', async () => {
  const store = makeStore({ credentials: CRED })
  const h = harness({ store, handler: () => statusReply('x') })
  const result = await h.channel.sendTaskNotice({ title: '[重点] 修复登录', kind: 'waiting' })
  assert.equal(result.ok, true)
  assert.equal(h.calls[0].body.msg.item_list[0].text_item.text, '您在[重点] 修复登录对话中的任务 等待选择，请及时处理。')
})

await checkAsync('sendTaskNotice：标题取不到 → 用"未知对话"兜底，但仍然发', async () => {
  const store = makeStore({ credentials: CRED })
  const h = harness({ store, handler: () => statusReply('x') })
  assert.equal((await h.channel.sendTaskNotice({ kind: 'done' })).ok, true)
  assert.equal(h.calls[0].body.msg.item_list[0].text_item.text, '您在未知对话对话中的任务 已完成，请及时处理。')
})

await checkAsync('sendTaskNotice：未连接 → {ok:false, error:"未连接微信"}，且一个请求都不发', async () => {
  const h = harness({ store: makeStore() })
  const result = await h.channel.sendTaskNotice({ title: 't', kind: 'done' })
  assert.deepEqual(result, { ok: false, error: '未连接微信' })
  assert.equal(h.calls.length, 0)
  assert.ok(h.logs.some((entry) => entry.level === 'warn' && entry.message.includes('尚未连接微信')))
})

await checkAsync('sendTaskNotice：-14（用户还没给机器人发过消息）原样带回，附 errcode', async () => {
  const store = makeStore({ credentials: { ...CRED, contextToken: undefined } })
  const h = harness({ store, handler: () => ({ status: 200, body: { errcode: -14, errmsg: 'window closed' } }) })
  const result = await h.channel.sendTaskNotice({ title: 't', kind: 'done' })
  assert.equal(result.ok, false)
  assert.equal(result.error, '微信回信窗口已关闭，请先用手机给机器人发一条消息')
  assert.equal(result.errcode, -14)
  assert.equal(result.errmsg, 'window closed')
  assert.equal('context_token' in h.calls[0].body.msg, false, '没有 contextToken 就不带 context_token')
  assert.ok(h.logs.some((entry) => entry.level === 'warn' && entry.message.includes('-14')))
  assert.ok(h.traces.some((entry) => entry.data?.event === 'send-window-closed'))
})

await checkAsync('sendTaskNotice：其他 errcode 非 0 → 原样报"发送被拒绝 errcode=…"', async () => {
  const store = makeStore({ credentials: CRED })
  const h = harness({ store, handler: () => ({ status: 200, body: { errcode: 10001, errmsg: 'bad' } }) })
  const result = await h.channel.sendTaskNotice({ title: 't', kind: 'done' })
  assert.equal(result.ok, false)
  assert.equal(result.error, '发送被拒绝 errcode=10001 errmsg=bad')
  assert.equal(result.errcode, 10001)
})

await checkAsync('sendTaskNotice：fetch 抛异常不冒泡，返回失败结构 + warn', async () => {
  const store = makeStore({ credentials: CRED })
  const h = harness({ store, handler: () => new Error('管子断了') })
  const result = await h.channel.sendTaskNotice({ title: 't', kind: 'done' })
  assert.equal(result.ok, false)
  assert.match(result.error, /管子断了/)
  assert.ok(h.logs.some((entry) => entry.level === 'warn' && entry.message.includes('发送失败')))
})

await checkAsync('sendTaskNotice：未知 kind → 拒发（不猜文案）', async () => {
  const store = makeStore({ credentials: CRED })
  const h = harness({ store })
  const result = await h.channel.sendTaskNotice({ title: 't', kind: 'whatever' })
  assert.deepEqual(result, { ok: false, error: '未知的提醒类型' })
  assert.equal(h.calls.length, 0)
})

await checkAsync('sendTaskNotice：还没有对话对象 → 提示先给机器人发一条消息', async () => {
  const store = makeStore({ credentials: { ...CRED, peerId: undefined, conversationId: undefined, contextToken: undefined } })
  const h = harness({ store })
  const result = await h.channel.sendTaskNotice({ title: 't', kind: 'done' })
  assert.equal(result.ok, false)
  assert.match(result.error, /还没有微信对话/)
  assert.equal(h.calls.length, 0)
})

await checkAsync('sendTaskNotice：发送前从共享刷新 peer / contextToken（自愈：用户刚在手机上说了话）', async () => {
  const store = makeStore({
    credentials: { ...CRED, peerId: undefined, conversationId: undefined, contextToken: undefined },
    shared: { bindings: { 'acct-1': { peerId: 'peer-fresh', conversationId: 'acct-1:peer-fresh', contextToken: 'ctx-fresh' } } },
  })
  const h = harness({ store, handler: () => statusReply('x') })
  const result = await h.channel.sendTaskNotice({ title: 't', kind: 'done' })
  assert.equal(result.ok, true)
  assert.equal(h.calls[0].body.msg.to_user_id, 'peer-fresh')
  assert.equal(h.calls[0].body.msg.context_token, 'ctx-fresh')
})

await checkAsync('sendTaskNotice：store 保存/读取抛异常也不影响发送（本次会话仍可用）', async () => {
  const store = makeStore({ credentials: CRED, saveThrows: true })
  const h = harness({ store, handler: () => statusReply('x') })
  assert.equal((await h.channel.sendTaskNotice({ title: 't', kind: 'done' })).ok, true)
})

await checkAsync('契约最小 store（只有 4 个方法）也能跑通登录 + 发送', async () => {
  const store = makeMinimalStore()
  const h = harness({
    store,
    handler: (call) =>
      call.url.includes('get_bot_qrcode') ? qrReply() : statusReply('confirmed', { bot_token: 'tk-m', ilink_bot_id: 'acct-m' }),
  })
  assert.equal((await h.channel.startLogin()).ok, true)
  assert.equal(store.calls.saves.length, 1)
  const send = await h.channel.sendTaskNotice({ title: 't', kind: 'done' })
  assert.equal(send.ok, false, '没有 peerId 时发不出去（但绝不抛）')
  assert.match(send.error, /还没有微信对话/)
})

/* ================================================================== 断开 / 释放 / 隐私 */

console.log('\n微信独立连接 · 断开、释放与日志隐私')

await checkAsync('disconnect：清掉自己的凭据（只调 clearCredentials），状态回到 disconnected', async () => {
  const store = makeStore({ credentials: CRED })
  const h = harness({ store })
  assert.equal(h.channel.isConnected(), true)
  await h.channel.disconnect()
  assert.equal(store.calls.clears, 1)
  assert.equal(store.current, undefined)
  assert.equal(h.channel.isConnected(), false)
  assert.equal(h.channel.status().phase, 'disconnected')
  assert.equal(h.channel.status().accountId, undefined)
})

await checkAsync('disconnect：store 抛异常也吞掉（不冒泡）', async () => {
  const store = makeStore({ credentials: CRED })
  store.clearCredentials = () => {
    throw new Error('删不掉')
  }
  const h = harness({ store })
  await h.channel.disconnect()
  assert.equal(h.channel.isConnected(), false)
  assert.ok(h.logs.some((entry) => entry.level === 'warn' && entry.message.includes('清除本地凭据失败')))
})

await checkAsync('dispose：之后 startLogin / sendTaskNotice 都拒绝，且不再发任何请求', async () => {
  const store = makeStore({ credentials: CRED })
  const h = harness({ store, handler: () => statusReply('x') })
  h.channel.dispose()
  const login = await h.channel.startLogin()
  assert.equal(login.ok, false)
  assert.equal(login.error, '插件已释放')
  const send = await h.channel.sendTaskNotice({ title: 't', kind: 'done' })
  assert.deepEqual(send, { ok: false, error: '插件已释放' })
  assert.equal(h.channel.isConnected(), false)
  assert.equal(h.calls.length, 0)
  assert.equal(h.channel.provideVerifyCode('1'), false)
})

await checkAsync('dispose：正在等验证码时释放 → 登录循环立刻收口', async () => {
  const h = harness({
    handler: (call) => (call.url.includes('get_bot_qrcode') ? qrReply() : statusReply('need_verifycode')),
  })
  let disposed = false
  h.sleeper.onSleep = () => {
    if (!disposed && h.channel.status().phase === 'awaiting-verify') {
      disposed = true
      h.channel.dispose()
    }
  }
  const result = await h.channel.startLogin()
  assert.equal(result.ok, false)
  assert.equal(result.phase, 'disconnected')
  assert.ok(h.channel.status().connected === false)
})

await checkAsync('dispose：status() 仍然可以安全读（不抛）', async () => {
  const h = harness({ store: makeStore({ credentials: CRED }) })
  h.channel.dispose()
  const snapshot = h.channel.status()
  assert.equal(snapshot.phase, 'disconnected')
  assert.equal(snapshot.connected, false)
})

await checkAsync('日志隐私：正文与标题可打，token / peerId / accountId / contextToken 一个都不许出现', async () => {
  const store = makeStore({
    credentials: {
      version: 1,
      account: { accountId: 'acct-SECRET-ID', token: 'tk-SECRET-TOKEN', baseUrl: 'https://ilinkai.weixin.qq.com' },
      peerId: 'peer-SECRET-ID',
      contextToken: 'ctx-SECRET-TOKEN',
      conversationId: 'acct-SECRET-ID:peer-SECRET-ID',
    },
  })
  let sends = 0
  const h = harness({
    store,
    handler: () => {
      sends += 1
      return { status: 200, body: sends === 1 ? { errcode: -14, errmsg: 'closed' } : { errcode: 0 } }
    },
  })
  await h.channel.startLogin()
  await h.channel.sendTaskNotice({ title: '任务栏进度条', kind: 'done' }) // -14 分支也要留痕
  await h.channel.sendTaskNotice({ title: '任务栏进度条', kind: 'done' }) // 成功分支（标题进诊断）
  await h.channel.disconnect()
  const dump = JSON.stringify({ logs: h.logs, traces: h.traces })
  for (const secret of ['tk-SECRET-TOKEN', 'peer-SECRET-ID', 'ctx-SECRET-TOKEN', 'acct-SECRET-ID']) {
    assert.equal(dump.includes(secret), false, `日志不该出现 ${secret}`)
  }
  assert.ok(dump.includes('任务栏进度条'), '标题应可出现在诊断里（排障需要）')
})

await checkAsync('log / debug 回调自己抛异常也不影响结果', async () => {
  const channel = createStandaloneChannel({
    log: () => {
      throw new Error('日志炸了')
    },
    debug: () => {
      throw new Error('诊断炸了')
    },
    store: makeStore({ credentials: CRED }),
    fetchImpl: makeFetch(() => statusReply('x')).fetchImpl,
  })
  assert.equal((await channel.sendTaskNotice({ title: 't', kind: 'done' })).ok, true)
})

await checkAsync('fetchImpl 不是函数时也不抛（返回失败结构，绝不退回全局 fetch）', async () => {
  // 注意：这里**故意**传一个不可调用的东西（而不是 null/undefined）——
  // 传 null 会回落到 Node 自带的全局 fetch，那就真的联网了，测试必须离线。
  const channel = createStandaloneChannel({
    store: makeStore(),
    fetchImpl: {},
    sleep: async () => {},
    now: () => 1,
  })
  const result = await channel.startLogin()
  assert.equal(result.ok, false)
  assert.equal(result.phase, 'failed')
  assert.match(result.error, /获取二维码失败/)
  assert.match(result.error, /没有可用的 fetch/)
})

console.log(`\nwechat-standalone: ${passed} 项全部通过\n`)
