/**
 * 延迟提醒单测：注入假定时器，不用真等 30 秒。
 *   node test/reminder.test.mjs
 */

import assert from 'node:assert/strict'
import { createDelayedReminder } from '../lib/reminder.js'

let passed = 0
const check = (label, fn) => {
  fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

/** 假定时器：可手动"到点"。 */
function fakeTimers() {
  let nextId = 1
  const pending = new Map()
  return {
    setTimeoutFn(fn, ms) {
      const id = nextId++
      const handle = { id, unrefCalled: false, unref() { this.unrefCalled = true } }
      pending.set(id, { fn, ms, handle })
      return handle
    },
    clearTimeoutFn(handle) {
      pending.delete(handle.id)
    },
    get count() {
      return pending.size
    },
    get delays() {
      return [...pending.values()].map((t) => t.ms)
    },
    fireAll() {
      for (const [id, t] of [...pending]) {
        pending.delete(id)
        t.fn()
      }
    },
    handles() {
      return [...pending.values()].map((t) => t.handle)
    },
  }
}

const makeReminder = (delayMs, timers, sink) =>
  createDelayedReminder({ delayMs, onFire: () => sink.push(delayMs), ...timers })

console.log('delayed reminder')

check('delayMs<=0 视为关闭：arm 不排任何计时', () => {
  const timers = fakeTimers()
  const sink = []
  const r = makeReminder(0, timers, sink)
  assert.equal(r.enabled, false)
  r.arm()
  assert.equal(timers.count, 0)
  assert.equal(r.armed, false)
  r.arm()
  timers.fireAll()
  assert.deepEqual(sink, [], '关闭时不应触发')
})

check('负数同样视为关闭', () => {
  const timers = fakeTimers()
  const r = createDelayedReminder({ delayMs: -5, onFire: () => {}, ...timers })
  assert.equal(r.enabled, false)
  r.arm()
  assert.equal(timers.count, 0)
})

check('arm 按配置的延迟排一个计时，到点触发一次', () => {
  const timers = fakeTimers()
  const sink = []
  const r = makeReminder(30_000, timers, sink)
  assert.equal(r.enabled, true)
  r.arm()
  assert.equal(timers.count, 1)
  assert.deepEqual(timers.delays, [30_000])
  assert.equal(r.armed, true)
  timers.fireAll()
  assert.deepEqual(sink, [30_000])
  assert.equal(r.armed, false, '触发后不再是 armed')
})

check('cancel 之后不会触发', () => {
  const timers = fakeTimers()
  const sink = []
  const r = makeReminder(1000, timers, sink)
  r.arm()
  r.cancel()
  assert.equal(timers.count, 0)
  assert.equal(r.armed, false)
  timers.fireAll()
  assert.deepEqual(sink, [], '取消后不该触发')
})

check('重复 arm 会重置计时（只保留一个）', () => {
  const timers = fakeTimers()
  const sink = []
  const r = makeReminder(1000, timers, sink)
  r.arm()
  r.arm()
  r.arm()
  assert.equal(timers.count, 1, '不应堆积多个计时器')
  timers.fireAll()
  assert.deepEqual(sink, [1000], '只触发一次')
})

check('onFire 抛错被吞掉，不会冒出去', () => {
  const timers = fakeTimers()
  const r = createDelayedReminder({
    delayMs: 10,
    onFire: () => {
      throw new Error('boom')
    },
    ...timers,
  })
  r.arm()
  assert.doesNotThrow(() => timers.fireAll())
})

check('默认会 unref 定时器（不拖住宿主退出）', () => {
  const timers = fakeTimers()
  const r = makeReminder(1000, timers, [])
  r.arm()
  assert.equal(timers.handles()[0].unrefCalled, true)
})

check('unref:false 时不调用 unref', () => {
  const timers = fakeTimers()
  const r = createDelayedReminder({ delayMs: 1000, onFire: () => {}, unref: false, ...timers })
  r.arm()
  assert.equal(timers.handles()[0].unrefCalled, false)
})

check('cancel 幂等', () => {
  const timers = fakeTimers()
  const r = makeReminder(1000, timers, [])
  r.cancel()
  r.arm()
  r.cancel()
  r.cancel()
  assert.equal(timers.count, 0)
})

console.log(`\ndelayed reminder: ${passed} 项全部通过\n`)
