/**
 * 配置规整的单测 —— 重点是 v2.0 的 **volatile 盒子**语义。
 *
 * `.volatile()` 的配置字段在 Cordis 里不是裸值，而是 cosmokit 的 `Volatile` 盒子
 * （`JSON.stringify` 出来是 `{}`），取值要 `.get()`。设置界面靠它做到"改完立即生效、
 * 不用重启"。这里用最小的假盒子验证四件事：
 *   1. 裸值照旧工作（link: 安装退化时就是这种形态）；
 *   2. 盒子能被解包，值被采用；
 *   3. **实时**：盒子里换值后，重新读 `settings.x` 拿到的是新值；
 *   4. 盒子里是坏值时回落默认值，而不是把坏值喂给插件。
 *
 *   node test/config.test.mjs
 */

import assert from 'node:assert/strict'
import { normalizeConfig, FAILURE_NOTICE_TEXT } from '../lib/index.js'

let passed = 0
const check = (label, fn) => {
  fn()
  passed += 1
  console.log(`  ✓ ${label}`)
}

/** 造一个最小的 volatile 盒子（够用的子集：只有 get）。 */
function box(getValue) {
  return { get: getValue, set() {}, subscribe: () => () => {} }
}

console.log('config normalization')

check('裸值照常工作', () => {
  const { settings, warnings } = normalizeConfig({ waitingNotifyText: '甲', waitingNotifyDelayMs: '5000' })
  assert.equal(settings.waitingNotifyText, '甲')
  assert.equal(settings.waitingNotifyDelayMs, 5000, '数字字符串应被接受')
  assert.deepEqual(warnings, [])
})

check('没给的键用默认值', () => {
  const { settings } = normalizeConfig({})
  assert.equal(settings.notifyPersona, '大肥鱼')
  assert.equal(settings.waitingNotifyEnabled, true)
  assert.equal(settings.waitingNotifyDelayMs, 30_000)
  assert.equal(settings.reviewNotifyDelayMs, 15_000)
  assert.equal(settings.driftNotifyMinutes, 10)
})

check('volatile 盒子会被解包，值被采用', () => {
  const { settings } = normalizeConfig({
    waitingNotifyText: box(() => '来自设置界面'),
    waitingNotifyEnabled: box(() => false),
    driftNotifyMinutes: box(() => 3),
  })
  assert.equal(settings.waitingNotifyText, '来自设置界面')
  assert.equal(settings.waitingNotifyEnabled, false)
  assert.equal(settings.driftNotifyMinutes, 3)
})

check('volatile 盒子是实时的：换值后重新读就是新值', () => {
  let text = '第一版'
  let delay = 1000
  const { settings } = normalizeConfig({
    waitingNotifyText: box(() => text),
    waitingNotifyDelayMs: box(() => delay),
  })
  assert.equal(settings.waitingNotifyText, '第一版')
  // 模拟用户在设置界面里保存 —— 不重启 DSH
  text = '改过了'
  delay = 60_000
  assert.equal(settings.waitingNotifyText, '改过了', '不做快照，每次读都取当前值')
  assert.equal(settings.waitingNotifyDelayMs, 60_000)
})

check('盒子里是坏值 → 回落默认值（而不是把坏值喂给插件）', () => {
  const { settings } = normalizeConfig({
    waitingNotifyDelayMs: box(() => '不是数字'),
    waitingNotifyText: box(() => 12345),
    completion: box(() => '不认识的模式'),
  })
  assert.equal(settings.waitingNotifyDelayMs, 30_000)
  assert.equal(settings.waitingNotifyText, '老大请您做出决定')
  assert.equal(settings.completion, 'hold')
})

check('盒子先坏后好也能恢复（设置界面改回来就生效）', () => {
  let value = null
  const { settings } = normalizeConfig({ driftNotifyMinutes: box(() => value) })
  assert.equal(settings.driftNotifyMinutes, 10, '坏值期间用默认值')
  value = 7
  assert.equal(settings.driftNotifyMinutes, 7, '改好后立刻生效')
})

check('未知配置项被忽略并给出警告', () => {
  const { warnings } = normalizeConfig({ 不存在的键: 1 })
  assert.equal(warnings.length, 1)
  assert.match(warnings[0], /未知配置项/)
})

check('枚举值非法 → 回落默认值并给出警告', () => {
  const { settings, warnings } = normalizeConfig({ backend: 'magic' })
  assert.equal(settings.backend, 'auto')
  assert.equal(warnings.length, 1)
})

check('整份配置不是对象 → 全部默认值 + 一条警告', () => {
  const { settings, warnings } = normalizeConfig('不是对象')
  assert.equal(settings.enabled, true)
  assert.equal(warnings.length, 1)
})

check('故障文案是写死的常量，配置改不动', () => {
  assert.equal(FAILURE_NOTICE_TEXT, '故障，请检查')
  // 全部键里都没有"故障"相关的覆盖项
  const { settings } = normalizeConfig({ failureNotifyText: '换个说法', failureNotifyEnabled: false })
  assert.equal(Object.prototype.hasOwnProperty.call(settings, 'failureNotifyText'), false)
  assert.equal(Object.prototype.hasOwnProperty.call(settings, 'failureNotifyEnabled'), false)
})

// ── v2.1 新增的两个子智能体开关 ─────────────────────────────────────────────
check('v2.1：subagentDisplayEnabled 默认 false（= 维持 v2.0 行为）', () => {
  const { settings, warnings } = normalizeConfig({})
  assert.equal(settings.subagentDisplayEnabled, false)
  assert.equal(
    Object.prototype.hasOwnProperty.call(settings, 'subagentDisplayEnabled'),
    true,
    '它必须是正式配置键（要进设置界面）',
  )
  assert.deepEqual(warnings, [])
})

check('v2.1：subagentDoneNotifyEnabled 默认 true（"打开显示功能后默认打开"）', () => {
  const { settings, warnings } = normalizeConfig({})
  assert.equal(settings.subagentDoneNotifyEnabled, true)
  assert.equal(Object.prototype.hasOwnProperty.call(settings, 'subagentDoneNotifyEnabled'), true)
  assert.deepEqual(warnings, [])
})

check('v2.1：两个子智能体开关都接受显式布尔值，坏值回落默认值', () => {
  const on = normalizeConfig({ subagentDisplayEnabled: true, subagentDoneNotifyEnabled: false }).settings
  assert.equal(on.subagentDisplayEnabled, true)
  assert.equal(on.subagentDoneNotifyEnabled, false)

  const bad = normalizeConfig({ subagentDisplayEnabled: 'yes', subagentDoneNotifyEnabled: 0 })
  assert.equal(bad.settings.subagentDisplayEnabled, false, '坏值回落默认值 false')
  assert.equal(bad.settings.subagentDoneNotifyEnabled, true, '坏值回落默认值 true')
  assert.equal(bad.warnings.length, 2, '两个坏值各给一条警告')
})

check('v2.1：两个开关在 volatile 盒子里也是实时的', () => {
  let display = false
  let doneNotify = true
  const { settings } = normalizeConfig({
    subagentDisplayEnabled: box(() => display),
    subagentDoneNotifyEnabled: box(() => doneNotify),
  })
  assert.equal(settings.subagentDisplayEnabled, false)
  assert.equal(settings.subagentDoneNotifyEnabled, true)
  // 用户在【插件 → 配置】里打开显示、再关掉子选项
  display = true
  doneNotify = false
  assert.equal(settings.subagentDisplayEnabled, true, '改完立即生效，不用重启')
  assert.equal(settings.subagentDoneNotifyEnabled, false)
})

check('v2.1：需求 1 的后缀没有配置键（硬性追加，界面无从修改）', () => {
  const { settings } = normalizeConfig({
    subagentSuffix: '自定义后缀',
    subagentSuffixEnabled: false,
    subagentNoticeSuffix: '别的名字',
  })
  for (const key of ['subagentSuffix', 'subagentSuffixEnabled', 'subagentNoticeSuffix']) {
    assert.equal(
      Object.prototype.hasOwnProperty.call(settings, key),
      false,
      `${key} 不该是配置键（后缀写死、不可关）`,
    )
  }
  assert.equal(
    Object.prototype.hasOwnProperty.call(settings, 'subagentDoneNotifyEnabled'),
    true,
    '能配的只有"时机"，不是那截后缀文案',
  )
})

// ── v2.1 需求 4 新增的四个微信提醒键 ────────────────────────────────────────
check('需求 4：四个微信键的默认值就是需求写的那四个（默认不开启）', () => {
  const { settings, warnings } = normalizeConfig({})
  assert.equal(settings.wechatDoneEnabled, false, '完成后微信提醒默认关闭')
  assert.equal(settings.wechatDoneDelayMs, 15_000, '默认 15000ms')
  assert.equal(settings.wechatWaitingEnabled, false, '等待选择微信提醒默认关闭')
  assert.equal(settings.wechatWaitingDelayMs, 30_000, '默认 30000ms')
  for (const key of ['wechatDoneEnabled', 'wechatDoneDelayMs', 'wechatWaitingEnabled', 'wechatWaitingDelayMs']) {
    assert.equal(Object.prototype.hasOwnProperty.call(settings, key), true, `${key} 必须是正式配置键（要进设置界面）`)
  }
  assert.deepEqual(warnings, [])
})

check('需求 4：四个键都接受显式值，坏值回落默认值并各给一条警告', () => {
  const on = normalizeConfig({
    wechatDoneEnabled: true,
    wechatDoneDelayMs: 3000,
    wechatWaitingEnabled: true,
    wechatWaitingDelayMs: 900,
  }).settings
  assert.equal(on.wechatDoneEnabled, true)
  assert.equal(on.wechatDoneDelayMs, 3000)
  assert.equal(on.wechatWaitingEnabled, true)
  assert.equal(on.wechatWaitingDelayMs, 900)

  const bad = normalizeConfig({
    wechatDoneEnabled: 'yes',
    wechatDoneDelayMs: '不是数字',
    wechatWaitingEnabled: 0,
    wechatWaitingDelayMs: null,
  })
  assert.equal(bad.settings.wechatDoneEnabled, false)
  assert.equal(bad.settings.wechatDoneDelayMs, 15_000)
  assert.equal(bad.settings.wechatWaitingEnabled, false)
  assert.equal(bad.settings.wechatWaitingDelayMs, 30_000)
  assert.equal(bad.warnings.length, 4, `四个坏值各给一条警告：${bad.warnings}`)
})

check('需求 4：微信延迟与电脑端延迟是两组独立的键（互不覆盖）', () => {
  const { settings } = normalizeConfig({
    waitingNotifyDelayMs: 1111,
    wechatWaitingDelayMs: 2222,
    reviewNotifyDelayMs: 3333,
    wechatDoneDelayMs: 4444,
  })
  assert.equal(settings.waitingNotifyDelayMs, 1111)
  assert.equal(settings.wechatWaitingDelayMs, 2222, '等待：电脑端与微信是两个值')
  assert.equal(settings.reviewNotifyDelayMs, 3333)
  assert.equal(settings.wechatDoneDelayMs, 4444, '完成：电脑端与微信是两个值')
})

check('需求 4：四个微信键在 volatile 盒子里也是实时的', () => {
  let done = false
  let doneDelay = 15_000
  const { settings } = normalizeConfig({
    wechatDoneEnabled: box(() => done),
    wechatDoneDelayMs: box(() => doneDelay),
  })
  assert.equal(settings.wechatDoneEnabled, false)
  assert.equal(settings.wechatDoneDelayMs, 15_000)
  // 用户在【插件 → 配置】里打开开关并把时长改成 5 秒 —— 不用重启 DSH
  done = true
  doneDelay = 5_000
  assert.equal(settings.wechatDoneEnabled, true)
  assert.equal(settings.wechatDoneDelayMs, 5_000)
})

console.log(`\nconfig normalization: ${passed} 项全部通过\n`)
