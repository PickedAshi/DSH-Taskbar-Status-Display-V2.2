# dsh-taskbar-progress

**DSH 桌面端任务栏进度条状态指示插件** —— 用 Windows **原生任务栏进度条**（不是叠加图标）实时反映 Agent 状态。

| Agent 状态 | 任务栏表现 | 颜色（实测） |
| --- | --- | --- |
| 思考 / 任务中 | 循环滚动的进度条（indeterminate） | 浅蓝，滚动 |
| 等待用户选择 | 静态条（paused） | **黄色** `(218,195,9)`（系统固定） |
| 卡住 / 故障 | 故障条（error） | **红色** `(220,135,146)`（系统固定） |
| 任务完成 | 填满的进度条，保持 30 秒后清除（normal） | 浅钢蓝 `(160,174,183)` —— **不是绿色**，见第 7 节 |
| 无活动 | 进度条清除 | — |

**另外还会以「大肥鱼」的名义弹 Windows 系统通知**，一共四种（见 [四种系统通知](#四种-windows-系统通知)）：

| # | 时机 | 通知正文 | 默认 | 能不能关 |
| --- | --- | --- | --- | --- |
| ① | 等待用户选择**超过 30 秒**还没人应答 | 老大请您做出决定 | 开 | ✅ 能关，也能改文案 / 时长 |
| ② | 任务完成后 **15 秒你还没操作 DSH** | 老大请验收 | 开 | ✅ 能关，也能改文案 / 时长。**另外 v2.1 起，主任务完成但还有子智能体在跑时会在正文后硬性追加「（还有 N 个子智能体仍在工作）」**（不可关、不可改，见需求 1） |
| ③ | **连续工作满 10 分钟**且中途没有任何形式的停止 | 已经连续工作10分钟，建议检查白饭是否被偷 | 开 | ✅ 能关，也能改文案 / 分钟数 |
| ④ | **进入故障相位（立即，不计时）** | 故障，请检查 | **始终开** | ❌ **不可关闭**：文案写死，设置界面里没有任何相关选项（需求硬性要求）。**v2.1.2 起同一个会话的一次故障只提醒一次**，该会话恢复正常（重新开跑）后再出错才会再提醒 |

![任务栏五种状态](docs/taskbar-states.png)

> 上排到下排依次是 idle / working / waiting / error / done。
> 这张图是**直接驱动插件自己的后端代码**（也就是插件运行时调用的同一份实现）拍出来的；
> 其中 working / done / idle 三种状态另外还在**完整接线后的真实 DSH 宿主**里复现过（见文末实测记录）。
> `working`（滚动）实际是**动画**，静帧只能拍到滚动片段的一瞬间，所以看起来偏窄。

**v2.1 新增：子智能体工作显示（用户可选）**。默认关闭，行为与 v2.0 逐字节一致；
打开后，主任务完成后如果还有子智能体在跑，进度条**继续滚动而不是填满**，直到全部工作结束才点完成条。
详见 [第 3 节末尾](#子智能体工作显示v21-新功能用户可选)。

**v2.1 需求 4：微信手机提醒（用户可选）**。上面那四条通知都只到**电脑**上；这一条到**手机**上 ——
任务**完成**、或**等待你做选择**超过设定时间时，通过微信插件给你推一条消息。
**默认关闭**，两个开关独立、两个延迟也独立（和电脑端的 ①② 分开设置）。
详见 [第 3 节「⑤ 微信手机提醒」](#-微信手机提醒需求-4v21-新增)。

**v2.2.0：微信提醒不再只能靠联动插件。** 宿主每次探测时先问"联动插件
（`dsh-wechat-plugin`）能不能用"：**能用就委托它发**（`mode: 'linked'`，行为与 v2.1 逐字一致）；
**不能用就本插件自己连**（`mode: 'standalone'`）—— 设置界面里直接出「连接微信」按钮、
二维码、验证码输入框与「断开连接 / 重新连接」，不再要求先装联动插件。
两条通道共用同一套延迟、同一套去重记账、**同一份文案**（一个字都没改）。
详见 [第 3 节「v2.2.0：两条通道」](#v220两条通道有联动就委托没有就自己连)。

---

## 1. 先看这条：为什么不是 `win.setProgressBar()`

需求书的方案是「用 `ctx.get('window')` 拿到 BrowserWindow，再调 `setProgressBar`」。
在 DSH 0.2.0 桌面端上**这条路走不通**，证据如下：

1. **宿主服务目录里没有窗口服务。** 用 `cordis-inspect` 拉全量 Service 目录，
   `window` / `browserWindow` 之类的 key 都不存在，所以 `ctx.get('window')` 恒为 `undefined`。
2. **插件宿主跟 Electron 不是一个进程。** 真实进程拓扑：

   ```
   DeepSeek Harness.exe            ← Electron 主进程（BrowserWindow 在这里）
     └─ DeepSeek Harness.exe --expose-internals
          .../app.asar/dsh/node_modules/@deepseek-ai/dsh-desktop-host/lib/index.js
                                 ← DSH 宿主进程，整个 profile 插件树在这里加载（本插件也在这里）
   ```

   两者之间只有一条**用法固定**的 `process.send` IPC：
   `ready` / `shutdown` / `quit-inspection` / `update-tasks` / `platform-session` / `fatal`。
   没有给插件预留任何"帮我调一下窗口"的通道，Electron 主进程里也**从未**调用过 `setProgressBar`。

**那怎么办？** 任务栏进度条在 Windows 上本质是 COM 接口 `ITaskbarList3` 作用在某个**窗口句柄 HWND** 上，
而 HWND **跨进程可见**。实测：从插件所在的宿主进程对 Electron 主窗口调用
`SetProgressValue` / `SetProgressState` **返回 S_OK 并且真的生效**，且设置进程退出后状态依然保持。

所以本插件把「窗口服务」保留为**首选层**（DSH 将来若真暴露窗口服务，不改代码就会自动走那条路），
真正干活的是下面三层后端。

---

## 2. 三层后端（自动降级）

| 顺序 | 后端 | 说明 | 依赖 |
| --- | --- | --- | --- |
| 1 | `window-service` | 探测 DSH 是否暴露窗口 / BrowserWindow 服务，有就调 `setProgressBar(value, {mode})` | 无（当前版本会跳过） |
| 2 | `win32-koffi` | **实际生效的那层**：用 koffi FFI 直接调 Win32 COM `ITaskbarList3/4` | koffi（DSH 桌面端**随安装包自带**） |
| 3 | `powershell` | 兜底：常驻 PowerShell 助手 + .NET COM 互操作 | 只用 Windows 自带的 `powershell.exe` |
| 4 | `no-op` | 全都不行就降级为空操作，并在日志里说明原因 | — |

三个实测踩到的坑，都已经在代码里处理（`lib/backends/win32-koffi.js`、`lib/koffi-resolver.js`）：

* 本机 Win11 上 `CoCreateInstance(CLSID_TaskbarList)` 之后 **QI `ITaskbarList3` 返回 `E_NOINTERFACE`**，
  而 QI `ITaskbarList4`（继承自 v3）却成功。所以按 **v4 → v3 → v2** 顺序尝试。
* `ITaskbarList4` 的 vtable 里 `SetProgressValue` / `SetProgressState` 在
  `IUnknown(0..2)` + `ITaskbarList(3..7)` + `ITaskbarList2(8)` 之后，下标是 **9 / 10**。
* **`koffi.proto()` / `koffi.struct()` 是进程内按名字全局注册的，重名第二次会抛
  `Duplicate type name`。** 插件被停用再启用时会二次实例化后端 —— 不缓存类型就会静默降级到
  PowerShell。现在用 `WeakMap` 按 koffi 模块缓存，只注册一次。

---

## 3. 状态映射表与信号来源

映射表的唯一事实来源是 [`lib/status-map.js`](lib/status-map.js) 顶部注释，代码与文档不会漂移：

| 相位 | 触发来源 | Electron 调用 | 原生 `TBPF_*` | 视觉 |
| --- | --- | --- | --- | --- |
| `working` | `agent/status` → `running`；`api-session/status` → `running=true`；轮询 `ctx.agents` | `setProgressBar(2, {mode:'indeterminate'})` | `TBPF_INDETERMINATE` (0x1) | 滚动 |
| `error` | `api-session/error`；`agent/error` | `setProgressBar(1, {mode:'error'})` | `TBPF_ERROR` (0x4) | 红色 |
| `waiting` | 见下方三条路径 | `setProgressBar(1, {mode:'paused'})` | `TBPF_PAUSED` (0x8) | 黄色静态 |
| `done` | `running` → `idle` 的一次转换 | `setProgressBar(1, {mode:'normal'})` | `TBPF_NORMAL` (0x2) | 填满，保持 30s |
| `idle` | 无活动 / 保持期结束 / 插件停用 | `setProgressBar(-1)` | `TBPF_NOPROGRESS` (0x0) | 清除 |

### 「等待用户」为什么有三条路径

需求书原本只写了监听 `user-questions/request` waterfall。**实测只监听它是不够的**：

服务契约里写得很清楚 —— `ctx.userQuestions.ask()` 才走 "scoped answerer waterfall"，
而 `ask_user_question` **工具**用的是 `askTimed()`，描述是
"Foreground wait **whose first settlement the Client decides**"（首次结算由 Client 决定）。
它**不一定派发** `user-questions/request`。实测出现过两种结果：早先几轮交互式问答里，
插件**整整一轮都没收到**该事件（旧版本因此完全不亮）；后来又观察到它会**迟几毫秒**到达。
结论很简单：**不能只依赖它**，需要一个每次必然发生的信号。

于是现在同时接三条：

| 路径 | 覆盖场景 |
| --- | --- |
| `tools/execute`（around-dispatch，判断工具名 ∈ `waitingTools`） | **交互式提问实际走这条** |
| `user-questions/request`（waterfall 观察） | `ask()` 路径（例如 plan review） |
| `approval/request`（waterfall 观察） | 审批 / 授权确认 |

三条都是**观察性透传**：原样 `return await next()`，不代答、不改变下游结果。

**多会话聚合优先级**：`error(4) > waiting(3) > working(2) > done(1) > idle(0)`
（任务栏只有一个进度条，取"最需要被看到"的那个）。

**子代理隔离**：默认 `scope: 'roots'`，只认 `ctx.agents.roots()` 里的顶层会话；
子代理的 `agent/status` / 报错不会污染顶层状态。

**粘性错误**：`lastAgentError` 是粘性的，所以故障信号按**内容签名去重** —— 内容没变不重复触发，
内容变了视为新故障并刷新保持期。
⚠️ **这说的是红条（灯）**：内容签名决定"要不要重新亮红 / 刷新保持期"。
v2.1.2 起 ④ 通知的频率**另有**一套按会话的记账（同一次故障只提醒一次，恢复后再出错才再提醒），
两者互不干涉 —— 见本节后面的「通知四：故障」。

**完成 vs 拆卸**：只有"显式 idle"才算任务完成；会话被关闭 / 从注册表消失属于拆卸，不会点亮完成条。

### 四种 Windows 系统通知

四条通知共用同一套发送实现（见本节末尾），但**开关规则分两类**：
①②③ 是可关闭的业务提醒，④ 是"必须让你知道"的故障——**需求上不允许用户关掉它**。
另外 ② 的正文里还有一截 **v2.1 新加的硬性后缀**（子智能体数量），同样不可关闭、不可配置。

> 下面这四条走的都是 **Windows 系统通知（toast）**，只到电脑上。
> v2.1 需求 4 又加了**第五条**：走**微信**、到**手机**上，默认关闭、可选、可分别设时长 ——
> 它的发送实现与开关规则都不同（不共用 toast），见本节末尾的
> [⑤ 微信手机提醒](#-微信手机提醒需求-4v21-新增)。

| # | 触发时机 | 默认文案 | 相关配置键 | 能不能关 |
| --- | --- | --- | --- | --- |
| ① | 进入 `waiting` 后超时 | 老大请您做出决定 | `waitingNotifyEnabled` / `waitingNotifyText` / `waitingNotifyDelayMs` | 能 |
| ② | 进入 `done` 后超时，且判定你没在操作 DSH | 老大请验收（+ 子智能体后缀） | `reviewNotifyEnabled` / `reviewNotifyText` / `reviewNotifyDelayMs`；**后缀本身没有键** | 能关这条提醒；**后缀不能关也改不了** |
| ③ | 连续工作满 N 分钟，中途没有任何停止 | 已经连续工作10分钟，建议检查白饭是否被偷 | `driftNotifyEnabled` / `driftNotifyText` / `driftNotifyMinutes` | 能 |
| ④ | 进入 `error` —— **立即**，不计时 | 故障，请检查（写死在代码里） | **无** | **不能**（**频率**：同一会话的一次故障只提醒一次，v2.1.2） |

#### 通知一：等待用户选择超时

黄色条亮着说明"在等你"，但你可能正在看别的地方。所以进入 `waiting` 之后开始计时，
**超过 `waitingNotifyDelayMs`（默认 30 秒）还没人应答**，就弹一条 Windows 系统通知：

> **DeepSeek Harness** ← 来源名（由 `notifyAumid` 决定）
> **大肥鱼** ← `notifyPersona`
> 老大请您做出决定 ← `waitingNotifyText`

行为细节：

* **每段等待只提醒一次**；用户作答后相位离开 `waiting`，下次再等会**重新计时**。
* `waitingNotifyEnabled: false` 关掉这一条；`waitingNotifyDelayMs: 0` 同样等于关闭。

#### 通知二：任务完成后你没在操作 DSH

任务跑完时你多半已经切走了。所以完成态亮起后等 `reviewNotifyDelayMs`（默认 15 秒）：

> **DeepSeek Harness**
> **大肥鱼**
> 老大请验收 ← `reviewNotifyText`

**"没在操作" 是怎么判定的**（这点必须说清楚，因为插件做不到完全精确）：

插件跑在 DSH 宿主进程里，**看不到"这次输入是否指向 DSH 窗口"** —— 那要给窗口挂消息钩子
（`SetWindowsHookEx`／子类化），跨进程且侵入性大，不适合插件。所以用两个**真实可测**的系统信号做代理：

| 信号 | 取法 | 含义 |
| --- | --- | --- |
| 前台窗口是不是 DSH | `GetForegroundWindow()` + `GetWindowThreadProcessId()` 比 **PID**（不是比 HWND，这样设置窗口也算 DSH） | 你此刻是不是在 DSH 上 |
| 距上次输入多久 | `GetLastInputInfo()`（**全系统**键盘/鼠标） | 你最近有没有动过键鼠 |

判定规则（`lib/activity.js` 里的 `isUserEngaged`，纯函数、可单测）：

> **"正在操作 DSH" = DSH 是前台窗口 且 在这个时间窗内有过输入**

于是：

* 切去别的程序 → 提醒 ✓
* 人离开电脑（无输入）→ 提醒 ✓
* 盯着 DSH 并且刚动过键鼠 → 不打扰 ✓
* **探测失败**（PowerShell 不可用等）→ **fail-open，照常提醒**：宁可多提醒一次，
  也不要把"任务完成了"这件事吞掉。

注意 `reviewNotifyDelayMs` **既是"等多久"，也是"多久内算操作过"的时间窗** —— 两者语义一致
（"这 15 秒内没被操作"），所以合成一个配置项。设为 `0` 关闭，或 `reviewNotifyEnabled: false` 关掉整条。

##### ② 正文后面那截「（还有 N 个子智能体仍在工作）」（v2.1 需求 1，硬性追加）

主要工作已经完成、但**还有子智能体在跑**时，②的正文后面会自动补一句括号说明还剩几个：

> **DeepSeek Harness**
> **大肥鱼**
> 老大请验收**（还有 2 个子智能体仍在工作）**

规则（全部写死在代码里，**用户关不掉也改不了**，和 ④ 故障同一个处理原则）：

| 情况 | 正文 |
| --- | --- |
| 子智能体数为 0 | `老大请验收` —— **一个字都不加**，保持原文案 |
| 子智能体数为 N ≥ 1 | `老大请验收（还有 N 个子智能体仍在工作）` |

实现位置：`lib/index.js` 的 `SUBAGENT_SUFFIX(count)` + `withSubagentSuffix(text)`，
`lib/config-schema.js` 里**没有**任何相关字段，`lib/client.js`（浏览器半边）里也**故意没有任何**
关于它的开关或说明块 —— 所以设置界面上不可能出现"关掉这个后缀"的选项。
`test/plugin-wiring.test.mjs` 与 `test/config.test.mjs` 各有用例钉住这两点
（包括"配置里塞 `subagentSuffixEnabled: false` 也照样加"）。

**"子智能体"是怎么数的**（判据，`lib/machine.js` 的 `countWorkingSubagents()`）：

> `ctx.agents.list()` 里**不在 `ctx.agents.roots()` 中**、且 `status === 'running'` 的 agent。

* **不在 `roots()` 中**：来自 `@deepseek-ai/dsh-agent` 的 AgentRegistry 源码，不是猜的 ——
  每个 agent 入册时都带一个运行时所有者（`agents.enter(agent, owner)`，子 agent 由
  `loopCtx.agents.enter(agent, parentAgent)` 注册），而 `roots()` 的实现就一句
  `filter((entry) => entry.owner === void 0)`，文档原文是
  "a top-level agent was created without an owning agent context"；`list()` 返回**全部**在册 agent。
  所以"子智能体"的权威判据就是**不在 roots 里**，而不是看 id 长什么样或名字前缀。
* **`status === 'running'`**：`AgentStatus` 只有 `'idle' | 'running'` 两个取值。可继续（continuable）
  的子智能体在一轮跑完之后会**留在注册表里等后续消息**（status 变回 `idle`）——
  那种"等待被唤醒"的子智能体并不是"还在工作"，不该被计数、也不该拖住完成条。
* **拿不准时一律返回 0**（注册表拿不到 / 服务抛错）：宁可少加一次后缀，也不能把插件打挂。

#### 通知三：偏离纠正（连续工作太久，v2.0 新增）

前两条管的是"停下来之后"，这一条管的是**一直没停**：连续工作太久通常意味着已经跑偏了。
`working` 段开始计时，满 `driftNotifyMinutes`（默认 10 分钟）就提醒：

> **DeepSeek Harness**
> **大肥鱼**
> 已经连续工作10分钟，建议检查白饭是否被偷 ← `driftNotifyText`

**"中途没有任何形式的停止"是这条通知的关键语义**，实现上就是看相位有没有离开 `working`：

| 中途发生的事 | 相位变化 | 对计时的影响 |
| --- | --- | --- |
| 等你做选择 | `working` → `waiting` | 计时取消，归零 |
| 故障 | `working` → `error` | 计时取消，归零 |
| 任务完成 | `working` → `done` | 计时取消，归零 |
| 空闲 / 会话消失 | `working` → `idle` | 计时取消，归零 |

也就是说它度量的是**一段不中断的工作**：每个连续工作段只提醒一次，一旦出现任何停止，
下次重新跑满才会再提醒。关掉：`driftNotifyEnabled: false`；改时长：`driftNotifyMinutes`。

#### 通知四：故障（v2.0 新增）—— **不可关闭、不可配置**

进入 `error` 相位就**立即**发一条，没有等待时间、没有开关：

> **DeepSeek Harness**
> **大肥鱼**
> 故障，请检查

为什么把它做成"关不掉"的：需求原文是「卡死后立即发消息说"故障，请检查"，**用户不得关闭该功能，
设置界面不用加入此功能的选项**」。所以：

* 正文写死在 `lib/index.js` 的 `FAILURE_NOTICE_TEXT`，**配置里塞 `failureNotifyEnabled: false`
  之类的东西也照样发**（这些键根本不认识，只会被 `normalizeConfig` 当成未知项警告后忽略）；
* 它**不在 `CONFIG_DEFAULTS` 里，也不在 `lib/config-schema.js` 里** ——
  于是它不会出现在设置界面上，用户无从修改；
* `lib/client.js`（浏览器半边）里也**故意没有任何**关于它的字段、开关或说明块。

**提醒频率（v2.1.2 改成"事件型"）：同一个会话的一次故障只提醒一次；该会话恢复正常
（重新开跑 / 状态回到 running）之后再出错，才允许再提醒一次。** 判据按**会话**记账
（`lib/machine.js` 的 `failureAnnounced` + `consumeFailureAnnouncement()`），
由事件路径上的 `announceFailure()` 出口，而**不是**看全局相位有没有跳变 —— 后者两个方向都错：

| 老逻辑（看 `changed`） | 结果 | v2.1.2 |
| --- | --- | --- |
| 相位本来就是 `error` 时，**另一个会话**也报错（`changed === false`） | **漏发**：那个会话一条提醒都没有 | ✅ 每个会话各提醒一次 |
| `errorHoldMs` 到期、红条消退（相位离开 `error`），粘性错误再把它带回 `error`（`changed === true`） | **刷屏**：会话只要停在故障态就**每 60 秒**再喊一次「故障，请检查」 | ✅ 消退 ≠ 恢复，**不再发** |
| 同一次故障期内错误内容变了 | 老逻辑当"新故障"再发一条 | ✅ 仍然只算一次故障，**不再发** |

**"恢复正常"的判据只有一个：该会话重新开跑**（`setRunning(id, true)`，含轮询观察到的
idle→running 翻转）；会话消失（`forgetSession`）时也一并清掉记账。
**"状态回到 idle"不算恢复** —— 会话卡在故障里时它的状态**本来就是 idle**，
把 idle 当恢复等于"每来一次 idle 事件就还一次配额"，和"消退时清记账"一样会把刷屏放回来
（这正是 `expireErrors()` 一个字都不碰记账的原因）。

**灯与通知是分开的**：红条仍然按 `errorHoldMs`（默认 60 秒）自动消退、重新开跑即清，
视觉行为一个字没改。文案写死、"不可关闭"、不进 schema、界面无选项这些硬性要求同样一个字没改 ——
v2.1.2 只改**频率**。真机证据（通知中心 70 条里约 60 条是这条、成簇出现）见 [第 11 节第 52 条](#v212-的真机证据故障提醒每-60-秒刷一条)。

### ⑤ 微信手机提醒（需求 4，v2.1 新增）

前四条通知都只到电脑上。这一条到**手机**上：任务**完成**、或**等待用户做选择**超过设定时间后，
通过微信给你推一条消息。

> **您在<会话标题>对话中的任务 已完成，请及时处理。**
> **您在<会话标题>对话中的任务 等待选择，请及时处理。**

文案来自 `lib/wechat.js` 的 `buildTaskNoticeText()`（纯函数，逐字断言在 `test/wechat.test.mjs`）。

| 配置键 | 默认值 | 作用 |
| --- | --- | --- |
| `wechatDoneEnabled` | **`false`** | 完成后微信提醒总开关 |
| `wechatDoneDelayMs` | `15000` | 完成后等多久（毫秒）才发；0 = 关闭 |
| `wechatWaitingEnabled` | **`false`** | 等待选择微信提醒总开关 |
| `wechatWaitingDelayMs` | `30000` | 等待多久（毫秒）才发；0 = 关闭 |

**两个默认都是关的**，而且**四个键与电脑端 ①② 的键完全分开**（需求原文：
「用户可以在设置里单独开关该功能并单独设置发送消息的延迟时间（和发到电脑上的分开）」）。
实现上就是**四个独立的 `createDelayedReminder`**：`wechatDoneReminder` / `wechatWaitingReminder`
与 `reviewReminder` / `waitingReminder` 各自 arm、各自 cancel，**谁也不取消谁** ——
把 `reviewNotifyDelayMs` 设成 0 不会影响微信那条，反过来也一样。

#### v2.2.0：两条通道（有联动就委托，没有就自己连）

v2.1 只有一条通道：宿主 `tools.execute('notify_wechat')`，前提是装了联动插件。
v2.2.0 把它抽象成**可插拔的两条通道 + 一个选择器**：

| 通道 | 走什么 | 什么时候用 | 行为 |
| --- | --- | --- | --- |
| **联动 notifier** | 联动插件注册的全局工具 `notify_wechat`（`tools.execute`） | `probe()` 探测到联动插件**可用** | **v2.1.3 逐行未改**（五道闸、调用形状、失败降级全一样） |
| **独立 notifier** | 本插件自己的连接（`lib/wechat-standalone.js` + `lib/wechat-proto.js` + `lib/wechat-store.js`） | 联动插件不可用 | 设置界面里自己扫码登录，之后由本插件直接调腾讯 iLink Bot API 发消息 |

**选择器就是 `probe()`**，规则只有一条：**先跑联动那五道闸，过了就用联动，并且
连独立通道都不去构造**（不 import、不读凭据文件、不连网）；没过才去建独立通道。
这条"有联动就绝不建独立"的规则既是省事也是省心：不会出现两条连接同时在跑。

##### `probe()` 的返回值（v2.2.0 扩展；UI 依赖它）

```js
{
  available: boolean,        // 真的能发出去了吗
  reason: string,            // 不能发时的原因（**旧字段，语义没变**）
  mode: 'linked' | 'standalone',          // 会用哪条通道发
  linked: { available, reason },          // 联动那五道闸的原始结论（reason 永远保留）
  standalone: null | { phase, qrContent, qrRefreshed, verifyAttempts,
                       accountId, peerId, error, connected, tokenFallback },   // 独立通道 status() 的快照
  standaloneReady: boolean,  // 独立通道模块能不能用（false = 加载失败/还没落地）
  standaloneError: string,   // 独立通道不可用的原因（'' = 正常）
  lastError: string,         // 最近一次**发送失败**的原因（'' = 没有；成功会清空）
}
```

**`available` 的确切含义**（这条想清楚了才写的）：

| 现场 | `available` | `mode` | `standalone.phase` | 界面该显示什么 |
| --- | --- | --- | --- | --- |
| 联动五道闸全过 | `true` | `'linked'` | （通常是 `null`，没建） | 「请在联动插件设置界面连接」，**不显示**本插件自己的二维码/连接按钮 |
| 联动不可用 + 独立**已连接** | `true` | `'standalone'` | `'connected'` | 「已连接微信」+「断开连接」「重新连接」 |
| 联动不可用 + 独立**还没连** | `false` | `'standalone'` | `'disconnected'` / `'connecting'` / `'awaiting-scan'` / `'awaiting-verify'` | **「连接微信」按钮**（UI 就是靠"`mode === 'standalone'` 且 `available === false`"认出该显示它） |
| 探测彻底失败 | `false` | `null`（**未知**） | — | 照 v2.1.3 的样子处理：不置灰、不显示任何模式专属内容（"问不到" ≠ "没有"） |

注意 `available === false` **不等于**"要显示独立入口"：只有 `mode === 'standalone'` 才是。
另外"联动不可用但独立已连接"时 `reason` 归空串（此刻确实能发），
"为什么没用联动"仍然查得到 —— 在 `linked.reason` 里。

##### 独立连接怎么走的

* **协议**（`lib/wechat-proto.js`）：腾讯 iLink Bot API —— `get_bot_qrcode` 取二维码、
  `get_qrcode_status` 长轮询扫码状态（服务端会 hold 住请求，客户端超时按 `wait` 处理）、
  `sendmessage` 发消息。请求头带 `iLink-App-Id` / `iLink-App-ClientVersion` / 随机 `X-WECHAT-UIN`，
  鉴权是 `AuthorizationType: ilink_bot_token` + Bearer token。这些常量是**从官方实现里读出来再实测确认**的。
* **凭据**（`lib/wechat-store.js`）：写在 **`~/.dsh/wechat/standalone.json`**（本插件自己的文件），
  与联动插件的 `~/.dsh/wechat/state.json` **同目录、不同文件**。为什么不能共用 `state.json`：
  那是**联动插件的**凭据文件，本插件既没有它的写入契约（版本号、字段、并发写入都是它的），
  也不该在"用户只是想用独立连接"时去改别人的文件。读的时候会**只读地**尝试从
  `state.json` 迁移一份（"用户已经在联动插件里登录过，就别让他再扫一次"），
  但**删除只删自己的文件**（`test/wechat.test.mjs` 里有一条联调用例专门钉这个：
  断开之后 `standalone.json` 没了、`state.json` 一个字节都没变）。
* **二维码的真实格式**（**实测，不是猜的**）：服务端 `get_bot_qrcode` 回的
  `qrcode_img_content` 是一段**纯文本 URL**，例如
  `https://liteapp.weixin.qq.com/q/7GiQu1?qrcode=957c…&bot_type=3`
  —— 既不是 data URL、也不是图片地址，而是**要被编码成二维码的内容**。
  所以不能直接塞给 `<img src>`，必须渲染。渲染放在**宿主侧**（`lib/wechat.js` 的
  `renderQrDataUrl()`）：它**动态 import profile 里已 hoisted 的 `qrcode` 包**
  （实测 `.tgz` 装进 profile 的那份能解析到 `profiles/desktop/node_modules/qrcode`，
  workspace 里的源码副本解析不到），编码成 `data:image/png;base64,…` 之后随状态路由递给界面，
  界面只管 `<img src>`。**没有新增任何第三方依赖**：那包本来就躺在 profile 里
  （是 `dsh-wechat-plugin` 的依赖被提升上去的），拿不到就降级 ——
  界面原样显示那段 URL 并标注 TODO，而不是假装有图。
* **`local_token_list` 只放 token**（**v2.2.1 的修复，真机实测**）：取码请求里的这个字段
  **只认 token**，混入任何非 token（尤其 accountId 如 `c3259b90b378@im.bot`）会让
  **整批**校验失败，用户直接拿不到二维码（原话与四方对照表见第 11 节第 66 条）。
  所以组装这个列表的地方（`lib/wechat-standalone.js` 的 `collectLocalTokens()`）
  只收"自己文件里的 token + 共享 `state.json` 里的 token"；`lib/wechat-store.js` 的
  `sharedAccountIds()` 因为只被这个错误逻辑用着，**已删除**（留一个会诱导后人再犯的 API 不如没有）。
  旧 token 真的失效（服务端回 `ret:-3`）时走**兜底**：自动用**空列表重试一次**，
  并把这次降级记进诊断（`qr-token-fallback`）+ 一条 info；此时 `standalone.tokenFallback === true`，
  界面/排障据此知道"旧绑定没能复用，扫码后可能要重新绑定"。空列表也失败才算失败。

##### 界面上必须有的两句人话（缺了用户会以为插件坏了）

> ① 扫码后如果要求输入数字，请输入手机微信上显示的那串验证码
> ② 连上后请先用手机给机器人发一条消息，之后才能主动推送提醒

这两句在**独立连接块渲染出来时一定出现**（`lib/client.js` 的 `StandaloneWechatBlock`，
`test/client.test.mjs` 逐字断言）。第 ② 句不是客套话：iLink 的**主动推送需要"回信窗口"**，
只扫码登录、用户还没给机器人发过消息时，服务端会回 `-14`（见下面「已知限制」）。

##### 去重键（v2.2.0 显式写下来，**行为一个字没改**）

用户定的去重键是 **`sessionId + eventType + status`**：

| 部分 | 含义 |
| --- | --- |
| `sessionId` | 哪个会话的任务（拿不到就**不发**，绝不猜） |
| `eventType` | `done` / `waiting`（⑤）/ `drift`（③）/ `failure`（④） |
| `status` | 那一段 episode：①②③⑤ 是"每段 episode 各一次"，④ 是"每个会话每次故障一次" |

记账落在**会话 / 提醒器对象**上（`createDelayedReminder` 的 armed/fired 状态、
`lib/machine.js` 的 `failureAnnounced` 集合），**与"用哪条通道发"完全无关** ——
所以联动↔独立切换**不会重置去重**，也不会在切换的瞬间补发一批旧提醒
（`test/plugin-wiring.test.mjs` 有一条专门的端到端用例钉住这件事）。

#### 发送前的三道门（少一道都不发）

| # | 门 | 拿不到就 |
| --- | --- | --- |
| 1 | **拿得到"任务所在的那个会话"** | 不发，并记一条 info 日志（**绝不猜**：猜错就是把消息发到别人的对话里） |
| 2 | `isWechatSession(sessionId) === false` | 不发（任务本身就在微信会话里，再推一遍是回声） |
| 3 | `probe().available === true` | 不发，并把 `probe()` 给的**原因**记一条 info 日志 |

第 3 道门是 `lib/wechat.js` 的五道闸：微信插件在不在（`wechatChannel` 服务）、
发送通道在不在（全局工具 `notify_wechat`）、**跨会话通知开着没有**（`allowCrossSessionNotify`）、
账号扫码连上没有（`status().accounts` 非空）、**有没有一个已绑定的微信对话**（`bindings()` 非空数组）。
五道缺一不可 —— 插件没装 / 没连账号 / 关了跨会话通知 / 还没在微信里给机器人发过消息，
宿主一律只打日志不发。

最后那道闸是 **v2.1.1 补的**：老版本只查"账号在线"，而**账号在线不等于有对话** ——
扫码登录后如果还没用手机给机器人发过消息，插件 store 里的 `bindings` 就是空的，
`notify_wechat` 必然拒发。少了这道闸时设置界面会显示"可用"、用户一发送就静默失败，
只能翻诊断日志（真机现场见第 11 节「v2.1.1 的真机证据」）。现在它会明说
`微信里还没有对话，请先用手机给机器人发一条消息`；
而"读绑定失败"（`bindings()` 抛异常 / 返回非数组 / 插件版本过旧没有这个方法）说的是
`读取微信会话绑定失败` —— 两条文案分开写，因为用户要做的动作不一样（前者去发消息，后者去修/升级插件）。
这道闸**排在账号闸之后**：先确认账号在线，再谈有没有对话，没登录的人该先看到"未连接账号"。

**"只打一次"**：同一条原因只提示一次（`logWechatOnce` 按原因字符串去重），否则每个任务跑完都刷一行。

#### `sessionId` 取哪一个（这里是唯一有推断成分的地方）

需求要求「sessionId 取**任务所在的那个会话**」。宿主里有两条带会话信息的信号，插件**优先第一条**：

| 优先级 | 来源 | 为什么 |
| --- | --- | --- |
| 1 | `api-session/status` 的第一个参数 | 事件名和载荷本身就是**会话层**的 `sessionId`，语义无歧义 |
| 2 | `agent/status` 的 `payload.agent.id` | 只在前者还没到手时兜底。本插件一直把它当会话 id 用（`machine.setRunning` 与 `api-session/status` 共用同一个集合，`agent/disposed` 也拿 `payload.agent.id` 去 `forgetSession`）—— **但那是推断**，所以只当备选 |

只有**顶层**会话会被记下（`scope: 'roots'` 的过滤器），子智能体的 id 不会成为提醒目标；
会话被 `api-session/removed` / `agent/disposed` 拆掉时一并清掉。
两者都拿不到 → **不发**，日志里写清"拿不到任务所属的会话 id（不猜、不发）"。

> ⚠️ 老实说：第 2 条来源成立的前提是"顶层 agent 的 id 与 session id 同值"。
> 这个前提**不是契约**，而是本插件从 v2.0 起就有的用法（`machine.setRunning` 把两者塞进同一个集合，
> `agent/disposed` 也拿 `payload.agent.id` 去 `forgetSession`），本次**没有**在真实宿主里打印比对过。
> 见文末「v2.1 需求 4 尚未实测的部分」。

#### 完成后那条会复用②的"你在不在电脑前"判定

完成类提醒的语义是"你走开了才需要通知"。所以 `wechatDoneReminder` **复用** ② 那套活动探测
（`lib/activity.js` 的前台窗口 + 全系统键鼠空闲），只是时间窗用它**自己**的 `wechatDoneDelayMs`：
你正坐在 DSH 前面 → 跳过微信提醒（电脑上那条 ② 的 toast 已经够了）；探测失败照样 fail-open 照发。

等待类那条**不做**这个判定：等你做选择时人通常就在旁边，手机提醒的意义正是"人走开了也能收到"，
再加一层判定只会把它吞掉。

#### ⑤ 与电脑端 ② 共用的另一条规则：子智能体没跑完就先别催

"还有子智能体在跑 → 扣住完成类提醒"这个判定（`heldForSubagents()`）是 ② 和 ⑤ 共用的一份实现，
两边不会漂移。默认（`subagentDisplayEnabled: false`）它恒为 false，也就是不做任何扣留。

#### 微信这一层为什么单独成文件

`lib/wechat.js`：外部依赖全部从参数进来（`ctx` / `log` / `debug`），**零第三方依赖**，
也不 import 任何 `@deepseek-ai/*`。所以 42 项单测可以完全脱离真实微信、不 spawn 进程、不联网。
发送走的是**全局工具 `notify_wechat`**（`tools.execute`），而不是直接调 `wechatChannel` 的方法 ——
宿主那个 runtime 上压根没有公开的发送方法（`#deliverTo` / `#sendOrQueue` 都是私有字段），
工具注册表才是唯一稳定的可编程入口，而且它顺带复用了宿主的完整执行管线
（工具体内部的异常会被物化成 `{isError: true}` 而**不是抛出来**）。三条硬规则写在文件顶部注释里。

### 子智能体工作显示（v2.1 新功能，用户可选）

v2.0 的相位汇总只认**顶层会话**（`scope: 'roots'`），所以子智能体的 `agent/status`
根本进不了状态机 —— 主任务一停就点完成条，子智能体还在跑也不管。
v2.1 把这个行为改成**显式的、由配置控制**的（而不是"碰巧"），新增两个开关：

| 配置键 | 默认值 | 作用 |
| --- | --- | --- |
| `subagentDisplayEnabled` | **`false`** | 开启后：**主要工作完成后如果还有子智能体在跑，任务栏不显示 done（填满），而是继续显示 working（滚动）**，直到所有工作结束才点完成条。关掉 = **维持 v2.0 行为**（主任务完成即 done） |
| `subagentDoneNotifyEnabled` | **`true`** | 上一个的子选项。开启后：**子智能体没跑完时，即使主任务完成了、即使超过 `reviewNotifyDelayMs`，也不发②那条通知**；只有所有工作都完成了才发。关掉 = 只看主任务（但父开关仍然会让进度条继续滚动） |

两条实现上的关键约定（都写进了注释与用例，避免以后被"优化"掉）：

1. **"主要工作完成后"才算数。** 判定不是"只要有子智能体在跑就点亮进度条"，而是
   `awaitingSubagents`（主任务 `running → idle` 那一刻置位）**且** `subagentBusy`（此刻确实有子智能体在 running）
   **且** 用户打开了开关。所以"主任务从没开工、只是有个子智能体在跑"**不会**把进度条点亮成 working。
2. **子智能体从不直接参与相位汇总。** 它们只通过"数量"间接影响 done，而那个影响完全由开关决定。
   关掉开关时，子智能体连数量都不看 —— 行为与 v2.0 逐字节一致。

**副作用（值得知道，是故意的）**：开启后，被压住的这段时间相位就是 `working`，
所以 ③ 偏离纠正的计时**会在子智能体继续跑的时候继续累计**（它度量的正是"一段不中断的工作"）。
如果你不希望被子智能体拖着算偏离，把开关关掉即可。

**发现延迟最多一个轮询周期。** 子智能体跑完这件事靠 `pollMs`（默认 1.5 秒）的轮询发现 ——
子智能体的 `agent/status` 事件不一定派发到插件总线，也可能晚到。所以从"最后一个子智能体结束"
到"进度条填满 + ②发出"之间，最多会晚一个轮询周期。`test/plugin-wiring.test.mjs` 里对应用例
把 `pollMs` 压到下限 250ms 就是在验证这条路径。

### 四条通知共同的实现与两个坑

1. 插件宿主是纯 Node，既没有 Electron 的 `Notification` 也够不到主进程；
   而 **Windows PowerShell 5.1 原生能加载 WinRT 类型**，所以用一次性 PowerShell 子进程发 toast。
   脚本用 `-EncodedCommand`（UTF-16LE base64）传入 —— 中文才不会乱码，也绕开执行策略与引号转义。
2. **`CreateToastNotifier(aumid)` 要求 AUMID 已注册**，否则 `Show()` 照样返回成功但**什么都不弹**。
   DSH 桌面端注册的是 `com.deepseek.dsh`（来源显示为 "DeepSeek Harness"）。
   查自己的：`Get-StartApps | Where-Object Name -like '*DeepSeek*'`。

`Show()` 是立即返回的、toast 归 shell 所有，所以子进程发完就退出，**不需要常驻助手**。
通知只是锦上添花：发送失败只打一条日志，**绝不影响进度条本身**。

---

## 4. 安装

> 宿主端插件，**装完要重启 DSH 桌面端**才生效（只关窗口不算退出）。

### ⚠️ 先纠正一个常见误解：`dsh plugin --profile desktop` 用不了

`desktop` profile 是**桌面端应用专属**的。用独立装的 `dsh` CLI 去操作它会被直接拒绝：

```
$ dsh plugin --profile desktop add file:C:/path/x.tgz
error: profile "desktop" is managed exclusively by the Electron application
```

（源码里 `dsh-desktop-host/lib/cli.js` 给自己的 CLI 传了 `manageDesktopProfile: true`，
独立 CLI 没有这个开关，所以拒绝。本机实测确认。）

**所以装桌面端插件只能走桌面端自己的「插件」页。**

### 正确装法：桌面端「插件」页 + 一个 spec

打开 DSH 桌面端 → 左侧栏的 **「插件」** 页 → 安装/添加插件，把下面任一种 **spec** 填进去：

| 形式 | 例子 | 装完能不能删源文件 |
| --- | --- | --- |
| **tarball（推荐）** | `C:/path/dsh-taskbar-progress-2.1.0.tgz` | ✅ 能，装完删掉整个目录都行 |
| 目录路径（等价 `link:`） | `C:/path/dsh-taskbar-progress` | ❌ 那个目录不能删也不能挪 |

规则来自插件管理器自己的 `parseInstallSpec`（`lib/types/install-spec.js`），实测结论：

* **必须是绝对路径**；相对路径一律拒绝（`a local path must be absolute`）。
* `file:` / `link:` 前缀**可有可无**，有也会被剥掉。
* 路径以 `.tgz` / `.tar.gz` 结尾 → 按 **tarball** 装（解包进 profile，源文件可删）；
  否则按 **目录** 装（junction，源目录必须保留）。
* 也支持注册表包名、git 地址（`github:user/repo`、`git@…`、仓库 URL）。
* 装不上时会先 `inspect` 一遍，spec 不合法会直接报 `invalid-spec` 并说明原因。

**⚠️ v2.0 起，装法还决定"有没有设置界面"**（新增的依赖只喂设置界面，详见下面的小节）：

| 安装方式 | 设置界面 | 进度条 + 四种通知 |
| --- | --- | --- |
| **`.tgz`（推荐，也是分发方式）** | ✅ 有 | ✅ 正常 |
| `link:` / 目录路径 | ❌ 没有（控制台会打一条 warning） | ✅ 正常 |

### v2.0 的设置界面：在哪儿、怎么用（v2.1 已扩到六块：三组提醒 + 子智能体 + 微信；v2.2.0 微信那块分两种模式）

**位置：DSH 桌面端 → 左侧栏「插件」页 → `dsh-taskbar-progress` → 「配置」。**

页面里有六块（通用 + 三组提醒 + 子智能体工作显示 + 微信提醒，**故障那一组故意不存在**）：

* **通用**：只有 `notifyPersona`（通知署名，可改）一个输入框。
  ⚠️ **`notifyAumid` 不在界面上**：通知来源 AUMID 必须是一个**系统已注册**的值，
  否则 toast 会静默不显示，所以它被排除在设置 schema 之外（页面上连只读展示都没有），
  要改只能写 profile 的 `cordis.patch.yml`；
* **① 等待超时提醒** / **② 完成后未验收提醒** / **③ 偏离纠正提醒**：每组一个开关 + 一个文案输入框
  + 一个时长输入框（①② 是毫秒，③ 是分钟）；
* **④ 子智能体工作显示**（v2.1 新增）：一个父开关 `subagentDisplayEnabled` + 它管着的子开关
  `subagentDoneNotifyEnabled`（下面带一行说明，讲清这个子开关到底改了什么）。
  **父开关关掉（默认）时子开关变灰禁用**，并提示
  "子智能体工作显示已关闭 —— 打开上面的开关才能修改下面的设置"；
* **⑤ 微信提醒**（v2.1 需求 4 新增，见下）；
* **依赖逻辑**：**某一组的开关关掉后，该组的文案与时长输入框会变灰禁用**，并提示
  "该组提醒已关闭 —— 打开上面的开关才能修改下面的设置"。这样"关了开关却还以为改了时长生效"
  这种误解在界面上就不可能发生。子智能体那一块用的是同一条规则，只是被禁用的是一个开关而不是输入框；
  微信那一块用的是同一条规则，只是**逐行**适用（两个功能各自独立，没有共同的父开关）。
* 保存是**暂存表单模型**：改完点保存才写入 profile 的 cordis patch；
  每个字段旁边有"已覆盖 / 恢复默认"（`overridden` / `reset`），
  留空即清除覆盖、回到默认值。

#### ⑤ 微信提醒这一块（含"探测不到联动插件就整节禁用"）

四个字段，**两个开关默认都是关的**：

| 控件 | 字段 | 默认 |
| --- | --- | --- |
| 「启用完成后微信提醒」+「完成后多久发微信（毫秒）」 | `wechatDoneEnabled` / `wechatDoneDelayMs` | 关 / 15000 |
| 「启用等待选择微信提醒」+「等待多久后发微信（毫秒）」 | `wechatWaitingEnabled` / `wechatWaitingDelayMs` | 关 / 30000 |

交互规则与前面几组一致：**某一行开关关掉 → 该行的时长输入框变灰禁用**，并给一行提示
"该组微信提醒已关闭 —— 打开上面的开关才能修改下面的设置"。

**这一节的状态是活的（v2.1.3 修的）**：探测结果**不再停在"页面加载那一刻"**——

* **打开页面就会重新检测一次**：用户点进「配置」时自动再问宿主一遍
  （同一个挂载周期只问一次，来回切页面/重渲染不会反复问）；
* 这一节里有一个 **「重新检测」按钮**（中英文都有），点它会**强制**重新探测，
  也就是**绕过宿主 30 秒的探测缓存**，立刻拿到此刻的真实现场；
* 刚扫码登录、或刚在手机上给机器人发了一条消息以后，点这个按钮就能让这一节
  **从"禁用"恢复成"可开启"**，旧的原因文字随之消失；
* 探测在飞时按钮变「检测中…」并禁用（避免连点把五道闸连着跑），
  而且**飞行中保留上一轮的结论**，界面不会先闪一下"未知"再闪回来。

**探测不到联动插件时，不再只是"整节不可开启"**（v2.2.0 改的）。
宿主会在状态路由里告诉界面用哪条通道（`mode`），界面据此分成两种完全不同的样子：

| `mode` | 界面 |
| --- | --- |
| `'linked'`（联动可用） | 一行提示 **「检测到微信联动插件可用，请到联动插件的设置界面里连接；本插件通过它发送提醒。」** —— **不再显示本插件自己的二维码和连接按钮**（同一个微信号两条连接同时连是需求明确要避免的） |
| `'standalone'`（独立已连接） | 「已连接微信」+「断开连接」「重新连接」；下面照旧是两行提醒开关 |
| `'standalone'`（独立未连接） | **「连接微信」按钮** + 二维码 + 连接状态 + 验证码输入框（需要时）+ 那两句人话；两个提醒开关此时仍是灰的（发不出去，别让用户以为开了就能收） |
| 没有 `mode`（探测失败 / 旧宿主） | 什么都不多显示，与 v2.1.3 完全一致（"问不到" ≠ "没有"） |

独立连接那一块的细节：

* **「连接微信」** → `POST /api/dsh-taskbar-progress/wechat/login`，宿主调独立通道的 `startLogin()`；
  **幂等**，连点不会起第二条轮询；
* **二维码**：宿主用 profile 里 hoisted 的 `qrcode` 把服务端的 URL 渲染成 `data:image/png`
  再递过来，界面直接 `<img src>`；渲染不了就原样显示那段 URL 并标注 TODO（见第 3 节）；
* **「刷新二维码」/「重新连接」** → 同一个 `/login`，但带 `{refresh:true}`：
  宿主先 `cancelLogin()`（独立通道没有单独的 refresh 方法），再 `startLogin()`；
* **连接状态**：未连接 / 连接中 / 等待扫码 / 需要验证码 / 已连接微信 / 连接失败 ——
  直接映射独立通道 `status().phase`，认不出的相位回落"未连接"（绝不把英文枚举值漏到界面上）；
* **验证码**：`phase === 'awaiting-verify'` 时出现一个数字输入框（`inputMode="numeric"`），
  文案是 **「请输入手机微信上显示的数字」**，提交走
  `POST …/wechat/verify`（body `{code}`）。空输入**不发请求**，本地给一句人话；
* **失败不静默**：连接失败 → 「连接已失效，请重新扫码。」；
  通道自己报的错、宿主报的「最近一次发送失败」、以及界面这一侧的网络失败，
  都会显示成一行 **「最近一次错误：…」**；
* **独立模块拿不到时**（例如只有三个 `lib/wechat-*.js` 里的某一个没落地）：
  按钮**禁用**并显示 "独立连接模块不可用：<原因>"，不假装能连。

> **为什么没有「前往联动插件设置」按钮**（查过了，做不到就不硬编）：
> 宿主里确实有跨插件导航服务 —— `ctx.pluginNavigation.openBundle(pkg)`
> （由 `dsh-client-ui-plugin-manager` 的浏览器半边 `ctx.reflect.provide("pluginNavigation", …)`
> 提供，`dsh-experimental-client-ui-voice-input` 就是这么用的），但它只把「插件」面板切到
> **那个 bundle 的详情页**；而微信插件的连接界面注册在 **「设置 → 微信」**
> （`dsh-wechat-plugin/client.js` 注册的是 `settings.section`，`id: 'wechat'`），
> 插件页上没有那个界面。要跳到"设置里的某一节"，需要 settings 外壳暴露选择 section 的服务 ——
> 读遍 `dsh-client-ui-settings` / `dsh-client-ui-settings-general` 都没找到
> （选择状态在 `createSettingsShellStore()` 内部，只对外暴露 `open()`）。
> 所以这里只用**文字**指路，不硬拼一个跳不到地方的按钮。

**探测不到联动插件时，整节不可开启**（这条 v2.1.3 的语义没变，只是文案改成中性的
「微信提醒当前不可用，本节暂时无法开启：<宿主给的原因>」）：
宿主说"微信提醒不可用"时，这一节的**两个开关连同两个时长框全部 `disabled`（置灰）**、
点击不会写入任何编辑 —— 原因文字**原样用宿主 `probe()` 的 `reason`**，界面不自己编一句（编了就是撒谎）。
英文界面里这一行同样是中文原因：那是宿主写的诊断原话，翻译它等于篡改它。
⚠️ 注意「重新检测」按钮**不在**"整节禁用"的范围内（独立连接块里的按钮也不在）——
一节灰掉的界面如果连重问一次的出路都没有，用户就只能重启宿主。

#### 浏览器半边是怎么知道宿主的探测结果的（**这是本节最难的一点**）

`lib/client.js` 是**浏览器半边**，跑在页面里，**拿不到任何宿主服务**。
所以"微信插件到底能不能用"只能由宿主回答，再想办法递到页面上。
下面三条通道的取舍**全部是读源码得出的**（不是"试了一下没成"），证据都在表格里；
最后一列列的是证据出处，不是实测记录。

| 通道 | 结论 | 依据（都是读源码/读运行时服务目录得到的） |
| --- | --- | --- |
| **`host.call(...)`** | ❌ **静态浏览器半边拿不到这个符号** | 它是 `@deepseek-ai/dsh-cordis-client-runner` 给**动态包**准备的闭包符号：动态包的浏览器半边是一段被求值的源码，参数里才有 `React` / `console` / `styles` / `host`。第一方 Builtin inspect provider 的原文就是 *"Plain-JavaScript symbols available to a **dynamic** Client half"*（`dsh-cordis-client-runner/lib/client.js:6186`）。本插件的浏览器半边是 `window.__ModuleLoader__.load({…})` 形态的**静态 bundle**，工厂只拿到 `require`，没有任何 `host`；整个 `dsh/` 里也搜不到 `provide("host")` 这类服务（0 命中），`get("host")` 唯一一处命中还是别的包里的同名局部变量 |
| **`ctx.remote.*`** | ❌ **接不进去** | 那是 typert 代码生成器产出的类型化 RPC（`ctx.remote.credentials.describe()` 这种），需要**生成的反射与 schema 贡献**（`dsh-typert-registry` / `dsh-typert-loader`）。本插件是零依赖手写 JS，跑不了那个生成器 |
| ✅ **宿主注册只读 HTTP 路由 + 浏览器同源 `fetch`** | **采用了这条** | 这个 DSH 里已有两个先例：`dsh-embedded-browser` 的面板（`webServer.register({kind:'exact', path:'/api/dsh-embedded-browser/…'})` + `fetch(url,{credentials:'same-origin'})`，见其 `lib/routes.js` 与 `lib/client.js:227-237`）与 `dsh-wechat-plugin` 自己的设置页（`/.dsh-wechat-plugin`，见其 `lib/host.js:2959`）。**不需要任何新依赖**，用的还是宿主自带的 `webServer`（`cordis_inspect` 查到它在运行中的宿主 Service 目录里，签名 `register(route: WebRoute): () => void`） |

具体形状：

* 宿主（`lib/index.js`）用 `ctx.inject(['webServer'], …)` 等 `webServer` 就绪，
  然后注册路由，注册挂在 `ctx.effect` 上（插件停用自动撤销）；
* **状态路由**（v2.1 起）**只读**：`GET /api/dsh-taskbar-progress/wechat` 回答
  `{available, reason, mode, linked, standalone, standaloneReady, standaloneError, lastError}`，
  非 GET/HEAD 一律 405（v2.2.0 起这个 body 变长了 —— 见下面那张表；`?refresh=1` 的强刷语义不变）；
  有 `connection` 服务时套一层 GUI 自己的请求守卫
  （`connection.requestRejection(req)`，与 GUI 同等保护），没有就退化成"仅本机可见"；
* **动作路由**（v2.2.0 新增，驱动独立连接）：四条 POST，各自一条 exact 路径；

| 方法 | 路径 | 作用 | body / 返回 |
| --- | --- | --- | --- |
| `GET` | `/api/dsh-taskbar-progress/wechat` | 取状态（含独立通道 `status()` 快照与渲染好的二维码 data URL）。带 `?refresh=1` = 先 `invalidate()` 再 `probe()` | → `{available, reason, mode, linked, standalone, standaloneReady, standaloneError, lastError}` |
| `POST` | `/api/dsh-taskbar-progress/wechat/login` | 开始扫码登录（幂等）；`{refresh:true}` = 先 `cancelLogin()` 再 `startLogin()` | `{}` 或 `{"refresh":true}` → `{ok, error, state}` |
| `POST` | `/api/dsh-taskbar-progress/wechat/verify` | 提交手机微信上显示的数字验证码 | `{"code":"1234"}` → `{ok, error, state}`；缺 `code` = **400** |
| `POST` | `/api/dsh-taskbar-progress/wechat/cancel` | 取消正在进行的登录 | `{}` → `{ok, error, state}` |
| `POST` | `/api/dsh-taskbar-progress/wechat/disconnect` | 断开独立连接（只清本插件自己的凭据文件） | `{}` → `{ok, error, state}` |

**为什么是"多条 exact 路由"而不是"一条 GET + query 表达动作"**：先读了
`@deepseek-ai/dsh-host-webserver` 的契约 —— `register(route)` 只要 `{kind, path, handler}`，
`kind: 'exact'` 走精确表、handler **完全拥有响应生命周期**（`await route.handler(req, res)`），
所以 POST body 想要多少有多少；而重复的 `(kind, path)` 会**直接抛错**，动作只能落在不同 path 上。
再看已装插件 `dsh-embedded-browser` 的 `lib/routes.js`：它就是"一条路径一个动作"
（`/open`、`/close`、`/human-done`），POST body 用 `readJson(req)` 读。
于是照抄同一套路：状态仍是那条 GET（v2.1.3 的语义与客户端断言一个字不用改），
动作各占一条 POST。**动作路由的返回**一律是 `{ok, error, state}`，
`state` 就是状态路由的 body —— 界面点完一次动作就能直接用新状态重画，不必再问一次。
业务失败（没连上、验证码不对、模块没落地）回 **200 + `ok:false` + `error`**（界面要拿它显示"最近一次错误"），
只有"方法不对 / body 不是 JSON / 缺必填参数"才是 405/400。

**诊断日志记状态迁移与发送结果，绝不记凭据**：`wechat:standalone-phase`（相位变化）、
`wechat:standalone-login`、`wechat:standalone-verify`（**只记"提交过一次、成没成"，
绝不记验证码本身**）、`wechat:standalone-disconnect`、`wechat:send-error` / `wechat:sent`、
以及每次请求的 `wechat-route` / `wechat-action`。`accountId` / `peerId` / token / 验证码
一个字都不进日志（`test/plugin-wiring.test.mjs` 会把 `debugLogFile` 指到临时文件再读回来断言这一点）。

* 路径**不会**和别的路由打架：读 `@deepseek-ai/dsh-host-webserver` 的实现，
  路由解析是"**先查 exact 表，未命中才走最长前缀**"（`lib/index.js:322-330`），
  `/api` 那套共享通道是前缀路由，命中不了我们这个 exact 路径；而且
  `register()` 对重复的 `(kind, path)` 直接抛错，所以路径冲突会立刻暴露而不是静默错发；
* **query 不影响匹配**（v2.1.3 依赖这一点）：同一个实现里，请求入口先做
  `new URL(req.url ?? "/", "http://x").pathname` **再**查表（`lib/index.js:229-245`），
  query 在匹配之前就被剥掉了 —— 所以 `/api/dsh-taskbar-progress/wechat?refresh=1`
  照样落在同一条 exact 路由上，不会 404；
* **浏览器半边问宿主两次时机**（v2.1.3）：`fetch('/api/dsh-taskbar-progress/wechat', { credentials: 'same-origin' })`
  **开机问一次**，**用户点进「配置」页时再问一次**（React effect，`deps` 只有 `view`，
  所以同一挂载周期只发一次）；结果存进卡片投影（`state.wechat`），组件据此决定显示哪种模式。
  节内的「重新检测」按钮再问一次，但那次带 `?refresh=1`：宿主**先 `invalidate()` 再 `probe()`**，
  绕过 30 秒缓存。不带这个参数时宿主行为**保持原样**（走缓存），
  所以来回点配置页不会把五道闸反复跑一遍。

**三种状态，绝不混为一谈**（这条是刻意的）：

| 状态 | 何时 | 界面行为 |
| --- | --- | --- |
| `available` | 宿主答 `available: true` | 正常，可开关 |
| `unavailable` | 宿主答 `available: false` | **整节禁用 + 显示宿主的原因** |
| `unknown` | 请求失败 / 非 2xx / 答非所问（页面不是由宿主 web 载体服务的） | **保持可用**，不显示任何"插件缺失"的结论 |

第三行很重要：**"问不到"不等于"插件不在"**。把一个能用的配置因为一次 fetch 失败而灰掉，
比不灰掉更糟 —— 而真正权威的拦截在宿主侧（三道门），界面只是提前告知。


实现方式（想改这个页面的话看这里）：

| 位置 | 作用 |
| --- | --- |
| `lib/client.js` | **浏览器半边**（v2.0 新增）。注册进插件页声明的 `plugins.row.config` slot，key 是 `<包名>#<行id>`，即 `dsh-taskbar-progress#taskbar-progress`。v2.1 需求 4 里它还负责向宿主问微信探测结果（同源 `fetch`），据此决定「⑤ 微信提醒」整节是否禁用；**v2.1.3 起这个状态是活的**：`view === 'page'` 时用 `react.useEffect`（`deps` 只有 `view`）重新探测一次，并提供「重新检测」按钮走 `?refresh=1` 强刷（`require("react")` 用的是客户端模块表的平台种子，和第一方 bundle 一样）。**v2.2.0 起它按宿主的 `mode` 分成两种界面**：联动可用只显示一句指路，独立模式显示连接块（二维码 / 状态 / 验证码 / 断开 / 重连），动作走四条 POST 路由；最近一次错误也显示在这里（`state.wechat.lastError` / `sendError`） |
| `lib/config-schema.js` | **宿主半边**（v2.0 新增）。用 `@deepseek-ai/schemastery` 声明哪些字段是 `.volatile()` 的 —— **表单只展示 volatile 字段**，没有 schema 这个「配置」页就是空的。它**只列需要给用户调的键**（所以 AUMID 也不在里面），进度条那批开发者选项继续走 patch。v2.1 在这里补了 `subagentDisplayEnabled` / `subagentDoneNotifyEnabled`，需求 4 又补了四个 `wechat*` 键。**v2.2.0 没有新增配置项**：走哪条通道是探测出来的，不是让用户配的 |
| `lib/wechat.js` | **微信提醒层 / 通道选择器**（v2.1 需求 4 新增，v2.2.0 扩成两条通道）。探测五道闸（v2.1.1 补上"有没有已绑定的对话"那道）、按 `probe()` 选联动还是独立、微信会话判据、标题三级降级、文案拼装、两条通道各自的发送与失败降级、独立通道的控制面（登录/验证码/取消/断开）、二维码渲染（复用 profile 里 hoisted 的 `qrcode`）。零第三方依赖、任何失败都返回 `false` 而不抛，69 项单测完全脱离真实微信（其中 5 项是**对着真交付代码**的联调） |
| `lib/wechat-proto.js` | **独立连接的协议层**（v2.2.0 新增）：iLink Bot API 的头、超时、`get_bot_qrcode` / `get_qrcode_status` / `sendmessage`、`-14` 的判据。不碰状态、不做决策，纯 HTTP |
| `lib/wechat-standalone.js` | **独立连接的状态机**（v2.2.0 新增）：`status/startLogin/provideVerifyCode/cancelLogin/disconnect/isConnected/sendTaskNotice/dispose`，扫码 → 验证码 → 连接 → 发送全流程，凭据懒加载（开机即用）、失败一律不抛 |
| `lib/wechat-store.js` | **独立连接的凭据读写**（v2.2.0 新增）：只写自己的 `~/.dsh/wechat/standalone.json`（原子写 + 0600），**只读地**从联动插件的 `state.json` 迁移一份；**删除只删自己的文件** |
| `lib/index.js` | `apply()` 里用 `ctx.inject(['settings'], …)` + `settings.configure({ auto: false })` 告诉 DSH「本插件自带配置页，别按 schema 自动生成」；这步失败只打日志，不影响进度条。需求 4 的两条提醒器、会话跟踪、状态路由与（v2.2.0 的）四条动作路由都在这里 |

界面用的都是 DSH 自带的客户端包（`@deepseek-ai/dsh-client-ui-primitives` 的
`SettingsForm` / `SettingsValueField` / `Switch`，加 `ctx.configForms` 的暂存表单模型），
所以**不需要往插件里塞任何前端依赖**。

**为什么 `link:` / 目录安装没有设置界面**：`lib/config-schema.js` 要
`import '@deepseek-ai/schemastery'`，而它由 **DSH 运行时自带**（挂在 profile 的
`node_modules/@deepseek-ai/*`）。`link:` 装出来的插件真实位置在 profile 之外，
ESM 解析不到这个包。v2.0 因此把这次 import 做成**动态 import + try/catch 降级**：

* 解析得到 → 有设置界面；
* 解析不到 → `Config` 置空、打一条 warning（"未能加载配置 schema…设置界面不可用；
  进度条与系统通知不受影响"），**插件本体照常加载，进度条和四种通知全部正常**。

这样做是因为：静态 import 一旦失败，宿主会报 `failed to import`，**连进度条都没了**
（这正是老版本那条坑，见第 8 节）。想要设置界面就**用 `.tgz` 安装**。

### 给自己开发用

改代码想让改动立刻生效，用**目录 spec**（等价 `link:`）指向工作目录最方便。
⚠️ 但要记住：**改了源码必须重启 DSH**，插件管理器上的启用/停用只对
"第一次加载失败过"的模块有效（原因见第 8 节）。

### ⚠️ 关于 `link:` / 目录安装（很重要，踩过）

`link:` 建的是 **junction / 符号链接**，而 Node 的 ESM 解析默认会把链接**还原成真实路径**
（`--preserve-symlinks` 未开）。于是：

* 插件装在 profile 里，**真实位置**却在 profile 之外；
* DSH 运行时包挂在 `~/.dsh/profiles/node_modules/@deepseek-ai/*`，
  从真实位置向上找**找不到**。

所以 **`link:` 安装的插件绝对不能静态 `import '@deepseek-ai/*'`** —— 会直接
`ERR_MODULE_NOT_FOUND`，宿主报 `failed to import`，插件**整个加载不起来**
（症状是任务栏毫无反应，且日志里只有一句 "failed to import"）。
作为对照：从 GitHub 装成真实目录的插件（如 `dsh-embedded-browser`）就没这个问题。

**本插件的宿主功能仍然是零第三方依赖**：进度条的后端选择、状态机、配置校验
（`lib/index.js` 的 `normalizeConfig`）全都只用 `node:` 内置模块，
不碰任何 `@deepseek-ai/*` 包，所以 `link:`、复制、npm 安装都能跑。

v2.0 新增的 `@deepseek-ai/schemastery` 依赖是**唯一的例外，而且只用于生成设置界面**：

* 它是 **DSH 运行时自带**的包，不需要用户联网安装，也不进 `dependencies`；
* 用**动态 `import()` + `try/catch`** 拿（见 `lib/index.js` 顶部）：拿不到就安静降级；
* 于是 `link:` / 目录安装的插件**宿主功能一个不少**，只是没有设置界面（见上一小节）。

换句话说：**旧文档里那种"连 `@deepseek-ai/schemastery` 都不敢 import"的限制，v2.0 已经换成了
"import 失败也绝不拖垮插件"**。

### 打包发给别人

**可以直接打包发出去。** 宿主功能零第三方依赖，所以收到的人**不需要联网装任何东西**
（设置界面用的 schemastery 在他自己的 DSH 运行时里就有），
只要他自己的 DSH 是桌面端 0.2.0 附近版本、系统是 Windows。

推荐：打一个 zip，里面放 **tgz + 源码 + 一份中文安装说明**（本机已实测走通全流程）：

```
dsh-taskbar-progress-v2.1.0/
├── INSTALL.txt                       # 中文安装说明（对方先读这个）
├── dsh-taskbar-progress-2.1.0.tgz    # 推荐用它安装（也才有设置界面）
└── dsh-taskbar-progress/             # 完整源码（备用/阅读/跑自测）
```

```powershell
# 你这边
pnpm pack                                  # → dsh-taskbar-progress-2.1.0.tgz
Compress-Archive -Path <上面那个目录> -DestinationPath <桌面>\....zip
```

> ⚠️ **以后改版本号时记得同步本文档**：`package.json` 的 `version` 决定 pack 出来的文件名，
> 而文档里多处引用了这个文件名。

对方那边（**注意：不是命令行**，见第 4 节，`desktop` profile 只归桌面端管）：

1. 解压 zip 到任意位置；
2. 打开 DSH 桌面端 → 左侧栏 **「插件」** 页 → 安装，粘贴解压出来的 tgz 的**绝对路径**：
   `D:/dsh-plugin/dsh-taskbar-progress-v2.1.0/dsh-taskbar-progress-2.1.0.tgz`
3. **完全退出并重新打开** DSH；
4. 装完那个解压目录可以整个删掉。

实测结论：

* DSH 插件管理器自己的 `parseInstallSpec` 把该路径判定为 `tarball`（合法）；
* pnpm 会把包**解包进他自己的 profile**（`profiles/desktop/node_modules/.pnpm/...`），
  装完**删掉 tgz 也照样能用**，`import` 正常、包内 220 项自测可跑（这是当前 v2.1.1 的数字；
v2.1 打包那次是 214 项，v2.0 打包那次是 151 项）；
* 包内没有指向你机器的路径（`lib/` 里零硬编码路径），zip 内条目名全 ASCII 不会乱码。

也支持直接发**解压后的文件夹**（对方在「插件」页填文件夹绝对路径），
但要提醒对方：**那个文件夹不能删也不能挪**，否则链接断掉、插件失效 ——
而且这种装法**没有设置界面**（原因见上一小节）。所以**分发首选 tgz**。

需要注意的四点：

1. **必须重启 DSH** 才生效（宿主端插件）。
2. **只在 Windows 桌面上有效**；纯 `dsh web` 或非 Windows 会安静降级为 no-op。
3. 通知功能依赖 AUMID：如果对方 DSH 的 AUMID 不是 `com.deepseek.dsh`（不同构建可能不同），
   通知会静默不显示 —— 让他跑 `Get-StartApps | Where-Object Name -like '*DeepSeek*'` 查出来，
   配到 `notifyAumid` 即可。**进度条本身不受影响。**
4. **想要设置界面就用 tgz 装**（文件夹 / `link:` 装出来没有界面，但进度条和四种通知照常）。

---

## 5. 配置

两个地方都能改，**写入的是同一个 profile cordis patch**：

* **图形界面**：桌面端 → 「插件」页 → `dsh-taskbar-progress` → 「配置」（只列通知相关的键，见第 4 节）；
* **直接写 patch**：`%USERPROFILE%\.dsh\profiles\desktop\cordis.patch.yml` 里按 row id 覆盖。
  界面保存后也是写回这里，所以用界面改完能在文件里看到结果，两边不会各说各话。

```yaml
- id: taskbar-progress
  config:
    completion: hold            # hold(默认，填满后保持) | clear(立即清除)
    completionHoldMs: 30000     # 保持时长
    errorHoldMs: 60000          # 故障条自动消退；0 = 不自动消退
    flashOnWaiting: false       # 等待用户时同时闪烁任务栏按钮(FlashWindowEx)
    flashOnError: false
    scope: roots                # roots(默认，只看顶层会话) | all
    waitingTools:               # 视为"等待用户"的工具
      - ask_user_question
    pollMs: 1500                # ctx.agents 轮询间隔(降级方案)
    reassertMs: 20000           # 每隔多久重发一次当前相位(自愈)；0 = 关闭
    backend: auto               # auto | window | koffi | powershell | none
    logStateChanges: true
    targetPid: 0                # 0 = 自动(process.ppid，桌面端即 Electron 主进程)
    enabled: true               # 总开关
    debugLogFile: ""            # 诊断日志(JSONL)路径；空 = 关闭

    # —— Windows 系统通知（四条共用前两项）——
    notifyPersona: "大肥鱼"                 # 通知第一行(加粗)的"发信人"；四条通知共用
    notifyAumid: "com.deepseek.dsh"         # 通知来源用的 AUMID（必须已注册）

    # ① 等待用户超时
    waitingNotifyEnabled: true              # 开关；false 时本组文案与时长一律不生效
    waitingNotifyText: "老大请您做出决定"     # 正文
    waitingNotifyDelayMs: 30000             # 等这么久还没人应答就弹；0 也等于关闭

    # ② 完成后你还没验收
    reviewNotifyEnabled: true               # 开关；false 时本组设置不生效
    reviewNotifyText: "老大请验收"           # 正文
    reviewNotifyDelayMs: 15000              # 完成后等这么久；既是等待时长也是"多久内算操作过"；0 也等于关闭

    # ③ 偏离纠正：连续工作太久（v2.0 新增）
    driftNotifyEnabled: true                # 开关；false 时本组设置不生效
    driftNotifyText: "已经连续工作10分钟，建议检查白饭是否被偷"
    driftNotifyMinutes: 10                  # 连续工作满这么多分钟、中途没有任何停止才提醒

    # ④ 故障提醒：**这里没有它的键，也不会有** —— 文案写死、不可关闭（见第 3 节）
    # ② 正文后面那截「（还有 N 个子智能体仍在工作）」同样**没有键、也不会有**（v2.1 需求 1）

    # —— 子智能体工作显示（v2.1 新增，两个开关）——
    subagentDisplayEnabled: false           # 默认 false = 维持 v2.0 行为；true = 主任务完成后若还有子智能体在跑，继续显示 working 而不是 done
    subagentDoneNotifyEnabled: true         # 默认 true；子智能体没跑完就先不发②（只在上面那个开关打开时有意义）

    # —— ⑤ 微信手机提醒（v2.1 需求 4 新增，默认全关）——
    # 有可用的微信联动插件（dsh-wechat-plugin）就委托它发；没有就本插件自己连（v2.2.0）。
    # 宿主探测不到两条通道都不可用时就只打日志不发。两条延迟与电脑端 ①② 的延迟**各自独立**。
    wechatDoneEnabled: false                # 默认 false；完成后给手机发微信提醒
    wechatDoneDelayMs: 15000                # 完成后等这么久（毫秒）；0 = 关闭
    wechatWaitingEnabled: false             # 默认 false；等待用户选择时给手机发微信提醒
    wechatWaitingDelayMs: 30000             # 等待这么久（毫秒）；0 = 关闭
```

**从 v1.2.0 升级上来的话，四个旧键名已废弃**（写了也不报错，但不会生效 ——
`normalizeConfig` 会当成未知配置项警告后忽略）：

| v1.2.0 旧键 | v2.0 新键 |
| --- | --- |
| `waitingReminderMs` | `waitingNotifyDelayMs` |
| `waitingReminderText` | `waitingNotifyText` |
| `completionNudgeMs` | `reviewNotifyDelayMs` |
| `completionNudgeText` | `reviewNotifyText` |

v2.0 另新增了 `waitingNotifyEnabled` / `reviewNotifyEnabled` / `driftNotifyEnabled` 三个开关与
`driftNotifyText` / `driftNotifyMinutes`；④ 故障通知则**没有、也不会有配置键**。

**v2.1 新增 `subagentDisplayEnabled`（默认 `false`）与 `subagentDoneNotifyEnabled`（默认 `true`）**，
以及 ② 正文里那截**硬性追加、没有任何配置键**的子智能体后缀（见第 3 节）。

**v2.1 需求 4 新增四个键：`wechatDoneEnabled`（`false`）、`wechatDoneDelayMs`（`15000`）、
`wechatWaitingEnabled`（`false`）、`wechatWaitingDelayMs`（`30000`）**。
它们**不复用** ①② 的任何键：开关各一套、延迟各一套，四条延迟互不影响（见第 3 节「⑤ 微信手机提醒」）。

**v2.2.0（独立连接）没有新增任何配置键**，一行都没有 —— 走联动还是走独立是**探测出来的**：
有可用的联动插件就委托它，没有就用本插件自己的连接。不交给用户选的理由：
多一个开关只会多一种"配错了却不知道为什么"的现场，而"哪条能用"宿主比用户清楚。
独立连接的凭据**不是配置**，它躺在 `~/.dsh/wechat/standalone.json`（见第 7 节）。

非法值不会让插件挂掉：`normalizeConfig` 会回落默认值并打一条警告。
设置界面上改的值是 **volatile 盒子**（每次读都取当前值），所以**改完不用重启 DSH**；
但直接改 patch 文件的**仍需重启**。

⚠️ `notifyAumid` **只能**在这里改 —— 它不在设置界面上（原因见第 4 节）。

---

## 6. 手动测试步骤（覆盖全部状态）

安装并**重启 DSH 桌面端**后，把 DSH 窗口放在能看到任务栏的位置：

| 要看到的状态 | 怎么手动触发 | 预期 |
| --- | --- | --- |
| **思考 / 任务中**（滚动） | 在任意会话里发一条会跑一会儿的消息，例如「从 1 数到 200，每个数字单独一行」 | 任务栏 DSH 图标上出现循环滚动的进度条 |
| **等待用户选择**（黄色） | 发：「用 ask_user_question 工具问我一个选择题，然后等我回答」；**先别回答** | 变黄色静态条；开了 `flashOnWaiting` 则按钮同时闪烁 |
| **等待超时通知**（①） | 接上一条，**等满 30 秒**再回答 | 弹 Windows 系统通知：标题「大肥鱼」、正文「老大请您做出决定」；整段等待只弹一次 |
| **卡住 / 故障**（红色）+ **故障通知**（④） | 让一次模型请求失败：设置里把 API Key 改错后发消息、断网后发消息、或用余额耗尽的账号 | 变红色条（`errorHoldMs` 后自动消退，或下次重新开跑即清），并且**立即**弹通知：正文「故障，请检查」——**没有等待时间，也没有开关** |
| **（回归）故障提醒不刷屏**（v2.1.2） | 接上一条，**让会话卡在故障态别管它**，盯 2 分钟。`errorHoldMs`（默认 60 秒）到期会让红条自己消退，随后粘性错误再把它点红 | 红条**照旧**亮满 60 秒消退、再被点红（灯的视觉行为没变），但**通知中心只有一条**「故障，请检查」——**不是**每分钟一条。想看"再提醒"：让该会话重新开跑（发一条新消息）后再次触发故障，这时才会收到第二条 |
| **（回归）两个会话各提醒一次**（v2.1.2） | 让会话 A 先进入故障态（红条亮着），再让会话 B 也报错 | B 报错时相位**本来就是** error，但 B 仍然要收到**它自己的那一条**「故障，请检查」（老逻辑在这里会漏掉） |
| **任务完成**（填满） | 等上一条任务正常跑完（Agent 回到 idle） | 进度条填满并保持 30 秒，然后清除 |
| **完成验收通知**（②） | 接上一条，**跑完后立刻切到别的窗口、或干脆离开电脑 15 秒** | 弹 Windows 系统通知：标题「大肥鱼」、正文「老大请验收」 |
| **（反例）不打扰** | 任务跑完后**继续在 DSH 里点一下/敲一下键**，别切走 | 15 秒后**不弹**通知（因为判定你正在操作 DSH） |
| **偏离纠正通知**（③） | 让它连续跑满 10 分钟且**中途不打断**（不要提问、不要切走触发故障）。想快点验证就把 `driftNotifyMinutes` 或界面上的分钟数改成 1 | 满点时弹通知：正文「已经连续工作10分钟，建议检查白饭是否被偷」；期间只要出现过等待/故障/完成/空闲，计时就归零，**不会**提醒 |
| **（反例）中途停一下就不算偏离** | 连续跑到快满点时，故意用 `ask_user_question` 问一次并停够一会儿 | 计时归零，之后即使继续跑满相同的分钟数，也要**重新从头计时**才会提醒 |
| **设置界面：关掉开关** | 在「插件 → dsh-taskbar-progress → 配置」里关掉 ①（或 ②/③）的开关并保存 | 该条通知不再发（比如等满 30 秒也不弹）；同时**该组的文案与时长输入框变灰禁用**，并显示"该组提醒已关闭" |
| **设置界面：改文案/时长** | 把 ① 的文案改成别的、时长改成 5000 并保存 | 下一次等待超时 5 秒就弹，正文是新文案；**不用重启 DSH** |
| **（反例）故障不可关** | 在设置界面里找"故障"相关的开关 | **找不到**：界面上没有任何故障通知的选项；配置里写 `failureNotifyEnabled: false` 也依然会弹「故障，请检查」 |
| **子智能体工作显示：开**（v2.1） | 在「配置」里打开「④ 子智能体工作显示」，保存。然后发一条会**派子智能体**的消息，例如：「用 subagent 工具**后台**跑一个要花 1 分钟的子任务（比如数到 600），你自己先简短总结一句就结束」 | 主任务那段话先跑完 → 按 v2.0 这时该填满了，但因为有子智能体在跑，进度条**继续滚动**；等子智能体也结束后才填满并保持 30 秒 |
| **子智能体的验收通知**（v2.1 需求 2） | 接上一条（`subagentDisplayEnabled: true`、`subagentDoneNotifyEnabled: true`）。主任务结束后**立刻切到别的窗口**，等超过 `reviewNotifyDelayMs` | **不弹**；只有子智能体也全部跑完后才弹一次「老大请验收」 |
| **关掉子选项**（v2.1 需求 2） | 把「子智能体没跑完就先不发验收提醒」关掉（父开关保持打开），重跑上一条 | 主任务一完成、超过 `reviewNotifyDelayMs` 就发② —— 即使子智能体还在跑；但**进度条仍然继续滚动**（那是父开关的职责） |
| **② 正文的子智能体后缀**（v2.1 需求 1） | 把「④ 子智能体工作显示」**关掉**（这样相位立刻进 done），再跑一条带后台子智能体的消息，然后切走等 15 秒 | 弹的正文是 `老大请验收（还有 N 个子智能体仍在工作）`；子智能体数为 0 时正文**没有任何后缀** |
| **（反例）后缀不可关**（v2.1 需求 1） | 在设置界面里找"子智能体数量后缀"相关的开关；或在 patch 里写 `subagentSuffixEnabled: false` | **找不到**：界面上没有这个选项，配置里写了也只是被当成"未知配置项"警告后忽略，后缀**照加** |
| **设置界面：父开关关掉子开关变灰**（v2.1） | 在「配置」里把「④ 子智能体工作显示」关掉并保存 | 下面的「子智能体没跑完就先不发验收提醒」开关**变灰禁用**，并显示"子智能体工作显示已关闭 —— 打开上面的开关才能修改下面的设置" |
| **微信提醒：默认关**（需求 4） | 装好微信联动插件（扫码登录、**在微信里给机器人发过一条消息**、打开跨会话通知），但**不动**「⑤ 微信提醒」的任何开关，跑完一个任务并切走 15 秒以上 | **不收到**任何微信消息（两个开关默认都是关的） |
| **微信提醒：完成后发**（需求 4） | 在「配置」里打开「启用完成后微信提醒」，把「完成后多久发微信」改成 `5000`，保存。然后跑完一个任务、**立刻切走或离开电脑** | 约 5 秒后手机微信收到：`您在<会话标题>对话中的任务 已完成，请及时处理。`；同时电脑上还可能按 `reviewNotifyDelayMs` 弹 ②（**两套延迟独立**，此时按 15 秒算） |
| **（反例）在电脑前就不发微信**（需求 4） | 接上一条，但任务跑完后**继续在 DSH 里点一下/敲一下键** | 5 秒后**不发**微信（复用 ② 的"你在不在电脑前"判定）；电脑端 ② 同样不弹 |
| **微信提醒：等待时发**（需求 4） | 打开「启用等待选择微信提醒」，时长改成 `10000` 并保存；发一条会调 `ask_user_question` 的消息，**先别回答** | 约 10 秒后手机微信收到：`您在<会话标题>对话中的任务 等待选择，请及时处理。`；此时电脑端 ① 按它自己的 30 秒算，**两条互不影响** |
| **（反例）微信会话里不回声**（需求 4） | 在**微信里**给 DSH 发一条会跑一会儿的消息 | 任务完成/等待时**不会再推一条微信**（目标就是那个对话，回声没有意义） |
| **（反例）联动插件缺失**（需求 4） | 把 `dsh-wechat-plugin` 停用或卸掉，重启 DSH，打开「⑤ 微信提醒」 | 整节**灰掉**：两个开关与两个时长框都点不动，并显示"未检测到可用的微信联动插件，本节无法开启：未检测到 dsh-wechat-plugin"（原因是宿主 `probe()` 给的**原话**） |
| **（反例）跨会话通知被关**（需求 4） | 保留插件，但在微信插件自己的设置里**关掉**"跨会话通知" | 界面显示"微信插件的跨会话通知被关闭"；即使强行在 patch 里把 `wechatDoneEnabled` 设为 `true`，宿主也**只打一条 info 日志、不发消息** |
| **（反例）没连账号**（需求 4） | 保留插件但**不扫码登录**（或断开账号） | 同上：提示"微信插件未连接账号"，一条都不发 |
| **（反例）账号在线但还没有对话**（需求 4，v2.1.1 新增） | 保留插件并扫码登录，但**从没在微信里给机器人发过消息**（`~/.dsh/wechat/state.json` 里 `bindings` 是空的），打开「⑤ 微信提醒」 | 整节**灰掉**并提示"微信里还没有对话，请先用手机给机器人发一条消息"。v2.1.1 之前这里显示"可用"：开关能打开、任务跑完却**静默失败**，只有诊断日志里那句 `wechat:send-error`（`tool-error`）能看出原因。给机器人发一条消息后点「重新检测」（v2.1.3 起；此前要重新打开界面）即恢复正常 |
| **状态是活的：打开页面重探 + 「重新检测」强刷**（v2.1.3） | ① 停在「⑤ 微信提醒」这一页不动，**在手机上**给机器人发一条消息（绑定建立）；② 点这一节里的「重新检测」按钮 | 按钮一点就变「检测中…」并禁用，很快恢复成「重新检测」；那一节从**灰掉**变成**可开启**，旧的原因文字消失。注意①之后**不点按钮什么都不会变**（界面只在打开页面时自动重探一次）——这正是 v2.1.3 之前那个 bug 的现场 |
| **（反例）微信窗口关着 → 消息排队延后**（需求 4） | 把微信客户端彻底退出，再触发一次微信提醒 | 消息**不会丢，但也不会立刻到**：微信插件的投递依赖它自己的链路，窗口关着时会排队/延后（见第 7 节已知限制） |
| **（反例）多绑定 → 拒发**（需求 4） | 在微信插件里绑定**两个以上**微信对话，再触发一次提醒 | 微信插件会拒绝"发给哪一个"这种不确定的请求，日志里出现"微信提醒发送被拒绝：当前绑定了 N 个微信对话…"（见第 7 节已知限制） |
| **无活动**（清除） | 完成保持期结束后自动清除；或 `completion: clear` | 进度条消失，只剩 Windows 自己那条运行中下划线 |

补充：

* **窗口最小化时进度条继续显示**，这是 Windows 原生行为，插件不需要额外处理。
* Windows 的任务栏进度条**没有蓝色档**；「等待用户」用 `paused`（黄）表达。
  需要更强提醒就打开 `flashOnWaiting`（走 `FlashWindowEx`，**不是** `SetOverlayIcon`）。
* 本插件全程**不使用** `SetOverlayIcon`（叠加图标）。

### 不依赖 DSH 的独立验证

```powershell
cd <本插件目录>
node test/backend-smoke.mjs                    # 自动选后端，依次走完 5 个相位
node test/backend-smoke.mjs --ms 5000          # 每个相位停 5 秒，方便盯着看
node test/backend-smoke.mjs --phase waiting    # 只设一个相位并**保留**（方便截图核对）
node test/backend-smoke.mjs --phase idle       # 清除
node test/backend-smoke.mjs --backend powershell   # 强制走 PowerShell 兜底后端
```

目标窗口 PID 默认取 `process.ppid`；直接跑时可以用环境变量指定：

```powershell
$env:DSH_TASKBAR_TARGET_PID = "<Electron 主进程 PID>"
```

### 单元测试（不需要 DSH / 不需要 koffi）

```powershell
node test/status-map.test.mjs      # 映射表 + 聚合优先级（9 项）
node test/plugin-state.test.mjs    # 相位状态机 + 子智能体判据 + 故障提醒事件型，假时钟（44 项）
node test/reminder.test.mjs        # 延迟提醒，假定时器（9 项）
node test/notify.test.mjs          # 通知载荷 / XML 转义（5 项）
node test/activity.test.mjs        # "没在操作 DSH" 判定（10 项）
node test/config.test.mjs          # 配置规整 / volatile 盒子 / 子智能体与微信开关（19 项）
node test/plugin-wiring.test.mjs   # 事件接线 + 配置 + 四种通知 + 子智能体 + 微信提醒 + 状态/动作路由（75 项）
node test/client.test.mjs          # 浏览器半边结构级回归（52 项）
node test/wechat.test.mjs          # 微信提醒层：五道闸 / 缓存 / 文案 / 通道选择 / 独立连接（含联调）（69 项）
node test/wechat-proto.test.mjs    # 独立连接协议层：头 / 三个端点 / 错误文案（41 项）
node test/wechat-standalone.test.mjs  # 独立连接状态机 + 凭据读写 + local_token_list 与 -3 兜底（67 项）
```

共 **400 项**（v2.1.3 是 239 项；v2.2.0 是 292 项；v2.2.1 修微信独立连接的真机 bug 后是 400 项 ——
v2.2.0 那次并没有把新增的两个测试文件算进这个总数，本次一并补齐）。
也可以 `pnpm test` 一次跑完（`package.json` 的 `scripts.test` 里**十一个**文件依次跑）。

**v2.2.1 新增的用例**（全部离线：假 `fetch` 注入，不联网）：

* **`local_token_list` 只放 token**（`wechat-standalone`）：真机回归保护 —— 断言列表里
  **只有** token（自己文件里的 + 共享的），`acct-shared` 这类 accountId 一个都不许有，
  并且**连问都不许去问** accountId；假服务端照真机行为"混进非 token 就回 `ret:-3`"，
  所以这条测试**行为上**也拦得住回退。
* **`ret:-3` 兜底**（`wechat-standalone`）：旧 token 全失效时**自动用空列表重试一次**
  （断言取码请求恰好 2 次、第二次的列表是空数组）、`status().tokenFallback === true`、
  诊断 `qr-token-fallback` 与一条中文 info 都在、**降级日志里不出现 token**；
  空列表也失败才判失败（错误里带服务端原话）；网络异常**不**触发兜底；
  本来就没有已知 token 时不做无意义的"降级重试"。
* **错误文案不许吞真相、不许双层前缀**（`wechat-proto` + `wechat-standalone`）：
  `fetchQRCode()` 在 `ret` 非 0 时原样报 `ret=` + `err_msg=`（并挂 `tokenRejected`）、
  在既没错误码又没 qrcode 时才说"未返回 qrcode"且**必须**带上截断的响应体；
  `pollQRStatus()` 缺 status 时同样带 `ret`/`err_msg`/响应体；`sendText()` 也认 `err_msg`；
  `获取二维码失败` 在最终文案里**只出现一次**。
* **透传到界面**（`plugin-wiring`）：状态路由把 `standalone.tokenFallback` 原样带给界面。

**v2.2.0 新增的用例覆盖**（全部离线：假 `ctx` / 假 `fetch` / 假 standalone，不联网、不发真微信）：

* **通道选择**（`wechat.test.mjs`）：联动可用 → `mode: 'linked'` 且**完全不去构造独立通道**；
  联动不可用 + 独立未连 → `mode: 'standalone'`、`available: false`、相位可见；
  联动不可用 + 独立已连 → `available: true`、`reason` 归空；独立模块建不起来 → 安全降级且只试一次；
  嵌套结果都是副本；独立通道的相位**每次现取**（不跟着联动的 30 秒缓存一起陈旧）。
* **独立发送**：走 `channel.sendTaskNotice({title, kind})` 且不碰 `notify_wechat`；
  取不到标题时把「未知对话」交过去；`ok:false` / 抛异常 / 未连接三种失败都是 `false` + warn + 诊断。
* **控制面**：`startLogin` / `provideVerifyCode` / `cancelLogin` / `disconnect` 的转发与失败降级、
  动作之后探测缓存立即作废、`dispose()` 会释放独立通道、`accountId`/`peerId` 不进日志。
* **二维码渲染**：payload 原样交给渲染器、同一张只编码一次、空/失败都回 `null`。
* **联调（对着对方真交付的三个模块）**：默认加载路径真的建得起通道（工厂名/参数名对得上）、
  `startLogin` 真的跑到 `awaiting-scan` 且 `qrContent` 就是服务端给的 URL、
  扫码确认后进 `connected` 并把凭据落进本插件自己的文件、
  **已连接时发出的正文与需求逐字一致**（连 U+0020 / U+FF0C / U+3002 都逐字符钉）、
  断开只删 `standalone.json` 而共享 `state.json` 一个字节不变。
  这一节用**临时目录**里的真 store + 假 fetch + 空 sleep，所以既不联网也不碰用户真实凭据。
* **宿主路由**（`plugin-wiring.test.mjs`）：五条路由的注册/注销与 exact 匹配、状态 body 的完整形状、
  四条动作路由各自的转发（含 `{refresh:true}` = 先取消再登录）、缺 `code` 是 400、
  **验证码绝不进日志**（真读 `debugLogFile` 断言）、动作与状态路由都套 GUI 请求守卫、
  以及**"联动↔独立切换不重置去重"**那条端到端用例。
* **界面**（`client.test.mjs`）：联动可用 → 只显示指路文案、**一个自己的连接按钮都不许有**、
  不渲染 `<img>` / `<input>`；没 `mode` → 不做模式专属展示；
  独立模式的「连接微信」→ `POST /login`、二维码用 `<img src="data:…">`、
  刷新二维码 `{refresh:true}`、「取消」、验证码输入与提交（空输入不发请求）、
  已连接的断开/重连、失败提示与「最近一次错误」、模块不可用时按钮禁用、
  两句人话**逐字断言**、中英字典齐全。

`config.test.mjs` 专门盯 v2.0 的**volatile 盒子**语义：设置界面保存的值在 Cordis 里不是裸值，
而是一个要 `.get()` 的盒子（`JSON.stringify` 出来是 `{}`）。它验证四件事 ——
裸值照旧能用（`link:` 安装退化时就是这种形态）、盒子能被解包、**换值后重新读就是新值**
（所以"改完不用重启"不是玄学）、盒子里是坏值就回落默认值而不是把坏值喂给插件。

`plugin-wiring.test.mjs` 用**假 Cordis 上下文**驱动真实的 `apply()`，并且用
`setToastTransport()` 注入假通知发送器 —— 所以"什么时候该弹、弹几条、文案对不对"
全部可断言，**不真的弹通知、也不 spawn 进程**。v2.0 新增的用例覆盖：
故障立即弹且关不掉、连续工作到点提醒、中途停止就归零、三组开关各自能关、
以及同一个故障不重复刷屏。**v2.1 新增的用例**覆盖：
② 正文的子智能体后缀（有 / 无 / 塞了假开关也照加）、
子智能体工作显示开着时的相位与②门控、所有工作结束后才补发②、
以及"子智能体不参与相位汇总"这条隔离约束。
**v2.1.2 又新增 3 项（端到端，真定时器、真事件）**：两个不同会话各自报错 → 各弹一条；
会话重新开跑后再次出错 → 再弹一条（同一次故障期内反复上报一条都不弹）；
以及本次 bug 的**回归保护** —— `errorHoldMs` 到点让红条消退、粘性错误再把它点红时，
**绝不再弹第 2 条**（老逻辑在这条上会弹 2 条，见第 11 节第 53 条的变异验证）。
**v2.1 需求 4 又新增 16 项**：默认关闭不动微信、完成后按自己的延迟发且 `sessionId`/`kind` 正确、
拿不到 `sessionId` 就不发、等待相位 arm/离开取消、微信与电脑端两套延迟互不取消、
"你在操作 DSH 就不震手机"与探测失败 fail-open、微信会话不回声、
插件不可用时不发且同一原因只提示一次、`wechat*DelayMs = 0` 等于关闭、
停用会取消计时并释放提醒器、只读状态路由的注册/注销/应答/405/请求守卫/没有 webServer 时的降级 ——
**全程用假提醒器（`setWechatNotifierFactory`）注入，不连微信、不联网**。
**v2.1.3 又新增 2 项**（同样是假提醒器）：带 `?refresh=1` 时**按顺序**先 `invalidate()` 再 `probe()`
（不带参数时一次都不调 `invalidate`，`?refresh=0` 也按"不强刷"处理，并断言带 query 仍然命中 exact 路由）；
以及强刷探测抛错时仍降级成"不可用 + 一句话"，不把请求打成 500。

`wechat.test.mjs` 单独覆盖微信那一层（五道闸、30 秒探测缓存、文案逐字、标题三级降级、
微信会话排除、失败一律降级为 `false`、日志不泄漏账号/peerId/contextToken），
外部依赖全部用假 `ctx` 注入，**不连真实微信、不 spawn 进程、不发网络请求**。
其中 6 项是 **v2.1.1 新增**的第五道闸用例：有绑定 → 可用；`bindings: []` → 不可用且给"先发一条消息"；
`bindings()` 抛异常 / 返回非数组 / 方法缺失 → 不可用且给"读取失败"（两条文案分开断言）；
以及"它排在账号闸之后"（账号也没连时不读绑定、报的仍是"未连接账号"）和"这道闸的结论同样进 30 秒缓存"。

`client.test.mjs`（v2.1 需求 4 后 32 项）现在还会用**假 `fetch`** 驱动那三种状态：
宿主答不可用 → 整节禁用并原样显示宿主给的原因；通道不通/401 → 保持可用、不误报"插件缺失"。
**v2.1.3 又新增 5 项**（为此给假世界补了 `react` 的 `useEffect` 替身与 `Button` 原语替身）：
`page` 视图渲染会重新探测一次而 `summary` 不会、同一挂载周期重渲染不再发请求、
`view` 变化才重发；点「重新检测」带 `?refresh=1` 且宿主改口后**界面从禁用恢复可用**
（含"飞行中保留上一轮结论、按钮变检测中…并禁用"）；强刷自身失败（抛 / 401）仍按 `unknown`
处理、不显示插件缺失也不留旧原因；按钮文案走中英两套字典。
它仍然是**结构级**断言（假 React + 假原语），真机渲染与保存流程**没有**在桌面端里点过 ——
包括 v2.1.3 这个按钮，真机点按仍未验证（见第 11 节第 60 条）。

---

## 7. 已知限制 / 注意事项

* **只在 Windows 上有效。** 非 Windows 平台三个后端都会跳过，插件降级为 no-op。
* **需要 DSH 桌面端（Electron）**。纯 `dsh web` 没有 Electron 窗口，任务栏上没有属于它的按钮，
  插件找不到目标窗口 —— 同样降级为 no-op。
* **颜色不完全由我们决定**：`TBPF_*` 只有 4 档（indeterminate / normal / paused / error），
  **没有任何颜色参数**。本机实测（Win11，任务栏不使用强调色）各档取色：

  | 相位 | `TBPF_*` | 实测均值 RGB | 观感 |
  | --- | --- | --- | --- |
  | waiting | `TBPF_PAUSED` | `(218, 195, 9)` | **亮黄**（系统固定） |
  | error | `TBPF_ERROR` | `(220, 135, 146)` | **红/粉**（系统固定） |
  | done | `TBPF_NORMAL` | `(160, 174, 183)` | 浅钢蓝（**不是绿色**） |
  | idle | `TBPF_NOPROGRESS` | `(117, 126, 135)` | 只剩系统那条灰色"运行中"下划线 |

  也就是说 **Windows 7/8 时代那个"完成 = 绿色"已经不存在了**：Win10/11 的 `NORMAL`
  呈现为浅蓝/钢灰（开启"在任务栏显示强调色"后跟随强调色）。
  想要"一定是绿色"在原生进度条上**做不到** —— 只有两条路：
  ① 把 Windows 主题色改成绿色并开启"在任务栏显示强调色"（系统级改动，影响整机 UI）；
  ② 改用叠加图标（`SetOverlayIcon`）画一个绿勾，而那正是需求书明确不要的。
  另外窗口**未获得焦点**时，进度条颜色会被系统调暗。
* **多会话**：默认 `scope: 'roots'`，任何顶层会话在跑都会亮。
  注意这条只管**相位汇总**；v2.1 的「子智能体工作显示」是另外一条独立通道
  （只数"数量"，且由开关控制是否影响 done），两者互不干扰。
* **子智能体的发现延迟最多一个 `pollMs`（默认 1.5 秒）**：子智能体跑完这件事靠轮询发现
  （它们的 `agent/status` 事件不一定派发到插件总线，也可能晚到）。
  所以"最后一个子智能体结束"到"进度条填满 + ②发出"之间最多晚一个轮询周期。
* **打开子智能体工作显示后，③偏离纠正的计时会把子智能体那段算进去**（相位在这段时间是
  `working`）。这是"一段不中断的工作"这个语义的自然结果，不是 bug；不想要就关掉开关。
* **"子智能体"只在同进程注册表里可见**：判据是 `ctx.agents` 的运行时父子关系。
  **跨进程 / 远端 provider 起的 agent 不在这个注册表里，也就不会被计数**（既不会被当成子智能体，
  也不会拖住完成条，更不会进②的后缀数量）。
* **微信提醒（需求 4）的四条已知限制**：
  * **微信窗口关着时消息会排队延后。** 投递链路由微信插件负责，它自己的客户端不在线时，
    消息不会被丢弃，但也不会立刻到 —— 有可能在你重新打开微信之后才到。
    插件对这一层**无能为力**，只能"交出去了就算成功"（`notify_wechat` 返回成功 ≠ 用户已经看到）。
  * **多绑定时插件会拒发。** 在微信插件里绑定了**两个以上**微信对话时，
    `notify_wechat` 无法确定该发给哪一个，会直接返回失败；
    插件（本插件）会把它记成"微信提醒发送被拒绝：当前绑定了 N 个微信对话…"并**不重试**。
    想要稳定收到提醒就只绑一个对话。
  * **微信会话自身不推送。** 任务本身就在微信对话里时，提醒会被跳过（否则就是回声）。
  * **`sessionId` 的来源有一处推断**：优先取 `api-session/status` 的 `sessionId`，
    只有它还没到手时才退到 `agent/status` 的 `payload.agent.id`。
    后者等于前者是**本插件自 v2.0 起的用法**（不是契约，本次也没在真实宿主里打印比对过），
    见文末待验证清单。
* **独立连接（v2.2.0）的五条已知限制**：
  * **二维码有效期以服务端的 `expired` 为准，不承诺秒数。** 协议里没有"还能用几秒"这种字段：
    客户端只能轮询，服务端什么时候回 `expired` 就是什么时候过期。收到之后独立通道会**自己再取一张**
    （最多 3 次，`DEFAULT_MAX_QR_REFRESH`），用户也可以点「刷新二维码」立刻换一张。
    界面上**不会**显示倒计时 —— 编一个数字出来只会骗人。
  * **`-14` 是双语义的。** 服务端返回 `errcode: -14` 时既可能是「用户还没给机器人发过消息，
    回信窗口没打开」，也可能是「token 过期 / 会话超时」—— 协议没有把这两种情况分开。
    本插件的处理是**原样把服务端的话带给用户**（日志里写清 `-14 回信窗口已关闭`，
    界面显示"请先用手机给机器人发一条消息"），**不猜是哪一种**。
    联动插件那条通道上的 `-14` 语义相同（`dsh-wechat-plugin` 自己的文案也是这么写的）。
  * **独立凭据不能与联动插件共用 `state.json`**（设计决定，不是没做）：
    `state.json` 是**联动插件的**文件，字段、版本、写入时机都是它的契约，本插件既没有写入权
    也不该去改；本插件自己的凭据写在同目录的 `standalone.json`（原子写 + 0600），
    **读取**时会只读地从 `state.json` 迁移一份（省掉重复扫码），**断开只删自己的文件**。
  * **独立模式下无法判断"这个 DSH 会话是不是微信会话"**：那张"DSH 会话 ↔ 微信对话"的绑定表
    是联动插件的 domain，独立通道只认识自己的 `peerId`。所以独立模式下
    `isWechatSession()` 恒为 `false`（保守：宁可多发一条也不静默漏发）。
    实际影响很小：独立连接不接收入站消息，也就不存在"发进微信会话"这种回声场景。
  * **"自动恢复连接"只到"凭据还在"这一层**：DSH 重启后独立通道第一次 `status()` 会去读
    `standalone.json`，读得到就直接进 `connected`（不用重新扫码）；读不到 / 文件坏了就当"未连接"。
    它**不会**在启动时去向服务端验证 token（协议里没有廉价的校验端点），
    所以"token 其实已经失效"这件事要等**第一次真正发送**才会暴露 —— 那一刻会 `log('warn')` +
    `debug()`，并把原因记进 `probe().lastError`，界面下次打开/重新检测时显示成
    「最近一次错误：…」。**界面不会主动推送**这条错误（没有反向通道），这是已知的延迟。
* **设置界面能否感知"联动插件缺失"取决于页面是不是宿主 web 载体服务的**：
  浏览器半边问的是宿主 `webServer` 上的 `/api/dsh-taskbar-progress/wechat`。
  页面不是由宿主 web 载体服务时（自定义外壳载体 / `file://`），
  这条询问会失败，界面会退化成"**感知不到**插件缺失"（状态 `unknown`，不置灰）。
  **但发送侧的拦截不受影响** —— 宿主那三道门永远生效，探测不到就只打日志不发。
  这条降级路径**没有在真实桌面端里验证过**（见文末待验证清单）。
* **微信探测结果最长有 30 秒的陈旧，但可以手动绕开（v2.1.3）**：界面问的那条路由默认复用
  `lib/wechat.js` 的探测缓存（可用/不可用都缓存 30 秒），所以刚扫完码登录时**不点按钮**
  最长要等 30 秒才会变绿。点这一节里的 **「重新检测」** 会带 `?refresh=1`，
  宿主先 `invalidate()` 再 `probe()` —— 立刻拿到真实现场。
  （v2.1.3 之前更糟：界面只在"页面加载那一刻"问过一次，之后**再也不问**，
  于是用户连上微信后界面永远显示旧的"未连接"，见第 11 节第 57 条的真机时间线。）
* **设置界面只在 `.tgz` 安装时出现**（且要求 DSH 桌面端带客户端插件页）。
  `link:` / 目录安装时 `@deepseek-ai/schemastery` 解析不到，插件会打一条 warning 后安静降级：
  **进度条与四种通知照常工作，只是没有那个「配置」页**（见第 4 节）。
  这是**故意的降级**，不是故障 —— 静态 import 会让插件整个加载失败，那样连进度条都没了。
* **界面上只能改通知、子智能体与微信相关的键**（v2.1 共 16 个字段；v2.2.0 一个都没加）。
  进度条那批开发者选项（`backend` / `pollMs` / `debugLogFile` …）
  仍然只能写 profile 的 `cordis.patch.yml`：`lib/config-schema.js` 只声明需要给用户调的字段。
  **走联动还是走独立不由用户选** —— 那是探测出来的（有联动就用联动），
  多一个开关只会多一种"配错了却不知道为什么"的现场。
* **④ 故障通知没有开关，也不打算有**：这是需求硬性要求，不是"忘了做"。
* **② 正文里的子智能体数量后缀同样没有开关、也不打算有**：v2.1 需求硬性要求
  （"硬性追加、用户不能关、不能改，设置界面上不能出现任何相关选项"）。
* **宿主日志**：桌面端宿主进程的 stdout 由 Electron 主进程接管，通常不落盘。
  排障请打开 `debugLogFile`（见下节）。

---

## 8. 排障

### 插件改了代码但不生效？—— 需要重启宿主

**Node 的 ESM 模块缓存会让重载拿到旧模块。** 实测：改完代码用插件管理器
disable → enable，日志显示加载的仍是旧版本（新增的配置项被当成"未知配置项"拒绝）。
用插件管理器重载只对**第一次加载失败的模块**有效（那时没有成功缓存）。
**改了插件源码就重启 DSH 桌面端。**

### 什么都看不到？按顺序查

1. **确认插件加载成功**：插件管理器里 `dsh-taskbar-progress` 的 `application` 应为 `applied`。
   若是 `failed to import`，基本只有一种成因：**`link:` 安装的插件里出现了静态 `import '@deepseek-ai/*'`**
   （见第 4 节）。v2.0 的 `@deepseek-ai/schemastery` 已经是**动态 import + try/catch**，
   解析不到只会少一个设置界面、**不会**把插件打挂。
2. **打开诊断日志**：在 profile patch 里配 `debugLogFile`，会得到一份 JSONL，看清每一步：

   ```yaml
   - id: taskbar-progress
     config:
       debugLogFile: "C:/Users/abc/taskbar-progress-debug.jsonl"
   ```

   正常的话会看到 `apply` → `backend-ready`（`backendId` 是 `win32-koffi` 还是降级的 `powershell`）
   → `win32 resolveWindow`（HWND）→ `win32 setProgress`（flags / HRESULT 都是 0）→ `phase`。
   通知相关的排查看 `notify` / `review-reminder` / `ev tools/execute(waiting)` 这几条记录。
   **v2.1 的子智能体相关记录**：`subagents`（数量变化时记一次：`count` / `displayEnabled`）
   与 `poll` 里的 `workingSubagents` 字段 —— 想知道"到底有没有数到子智能体"就看这两条。
3. **确认后端能单独驱动任务栏**：跑 `node test/backend-smoke.mjs`，与 DSH 无关。
4. **确认窗口句柄对**：`win32 resolveWindow` 报的 HWND 应该是 Electron 主进程（`process.ppid`）
   那个有标题的可见顶层窗口。
5. **进度条和通知都正常，只是没有「配置」页？** 这是预期行为，不是故障：
   `link:` / 目录安装解析不到 `@deepseek-ai/schemastery`，控制台会有一条
   "未能加载配置 schema…设置界面不可用；进度条与系统通知不受影响" 的 warning。
   改用 `.tgz` 安装即可获得设置界面（见第 4 节）。
6. **设置界面改完不生效？** 先确认点过**保存**（表单是暂存的，改完不点保存不会写回 profile）；
   再确认那个开关是打开的 —— 关掉的组，它的文案与时长输入框是**禁用**的，改了也不会生效；
   v2.1 的子智能体子开关同理，父开关关着时它是灰的。
7. **打开了子智能体工作显示，但进度条还是一完成就填满？** 按顺序确认：
   ① 那个开关真的保存了（打开界面看它是开着的，或看 profile patch 里
   `subagentDisplayEnabled: true`）；② `debugLogFile` 里有没有 `subagents` 记录 ——
   没有记录说明 `ctx.agents` 没拿到、或者真的没有子智能体在跑（`countWorkingSubagents` 拿不准时返回 0）；
   ③ 子智能体是不是**前台**跑的（前台调用时父会话会一直 running，相位本来就是 working，
   也就没有"被拖住"这回事）；④ 子智能体跑完到进度条填满最多会晚一个 `pollMs`（默认 1.5 秒），
   这是设计如此（见第 3 节末尾）。
8. **「⑤ 微信提醒」显示"未连接/还没有对话"，但我明明已经连上微信了？**
   （v2.1.3 修的正是这个）先确认浏览器地址是宿主 web 载体（自定义外壳 / `file://` 会退化成
   感知不到，见第 7 节）；再看 `~/.dsh/wechat/state.json` 里的 `bindings` 是不是真的非空；
   然后**点这一节里的「重新检测」**—— 它会强刷宿主缓存并立刻更新界面。
   界面显示的结论只影响"能不能在界面上开这个开关"，**发送前宿主仍会自己 probe 一次**
   （不可用就不发），所以界面旧了不会导致误发。
8. **微信提醒没发出去？** 打开 `debugLogFile`，按顺序看两类记录：
   * `wechat-skip`（带 `reason`）—— 门控没过的原因，和 info 日志里那句"微信提醒未发送：…"是同一件事。
     常见值：`未检测到 dsh-wechat-plugin`（插件没装）、`微信插件未连接账号`（没扫码）、
     `微信里还没有对话，请先用手机给机器人发一条消息`（账号在线但还没绑定对话，v2.1.1 新增）、
     `读取微信会话绑定失败`（读 `bindings()` 出错 / 插件版本过旧）、
     `微信插件的跨会话通知被关闭`、`拿不到任务所属的会话 id（不猜、不发）`、`该任务就在微信会话里（不回声）`。
     ⚠️ **同一条原因只提示一次**是故意的（不刷屏），所以翻日志时往前面找。
   * `wechat:probe` / `wechat:sent` / `wechat:send-error`（来自 `lib/wechat.js` 的诊断）——
     探测结论与真实发送结果。`wechat:send-error` 的 `stage` 会说清卡在哪一步
     （`no-tools` / `execute-threw` / `no-result` / `tool-error` / `unexpected`）。
     若看到 `wechat:probe` 答 `available:true` 却仍有 `stage:"tool-error"` 且详情是
     "还没有微信对话…"，那就是 v2.1.1 之前那道缺失的闸（见第 11 节的真机证据）。
   另外确认界面上那两个开关**真的打开了**（默认都是关的）；只改延迟不开开关不会发。
   若日志里连 `wechat-skip` 都没有，说明两个开关压根没开，或者插件版本不是 v2.1 及以后。
9. **「⑤ 微信提醒」整节是灰的 / 明明装好了插件却点不开？** 那行提示里的原因就是宿主 `probe()` 的原话。
   按它排：插件没装 / 没扫码登录 / **扫码了但还没在微信里给机器人发过一条消息** /
   插件的跨会话通知被关 / 读会话绑定失败（插件版本过旧）。
   如果**没看到原因、却能正常点**，那是"问不到宿主"的降级状态（页面不是由宿主 web 载体服务的），
   顺带看一眼有没有"没有 webServer 服务，未注册 /api/dsh-taskbar-progress/wechat"这条 info 日志。
10. **v2.2.0：界面上出现了「连接微信」按钮，我该点吗？**
    **看到了就说明宿主探测不到可用的联动插件**（没装、没登录、关了跨会话通知，或者没有已绑定对话）——
    这时本插件可以自己连。点「连接微信」→ 用手机微信扫出来的二维码 → 如果要求数字就输手机上那串 →
    **连上后先用手机给机器人发一条消息**（这句在界面上也写着，别跳过）。
    两种界面**只会出现一种**：联动可用时看到的是"请到联动插件的设置界面里连接"，**不会有**二维码按钮 ——
    所以不会出现"两条连接同时在连同一个微信号"。
11. **v2.2.0：点了「连接微信」什么都没有 / 一直"等待扫码"？**
    按顺序看：① 界面上有没有一行「最近一次错误：…」（网络不通 / 宿主动作失败都会显示在这里，
    不会静默）；② `debugLogFile` 里的 `wechat:standalone-phase`（相位迁移）、
    `wechat:standalone-error`（独立模块加载失败的原因）、`wechat:standalone-login`（登录结果）；
    ③ 若看到"独立连接模块不可用：…"，说明 `lib/wechat-standalone.js` / `lib/wechat-store.js`
    没被装进去（`.tgz` 里 `files` 列的是整个 `lib`，正常都在）。
    二维码过期不用慌：服务端自己会回 `expired`，独立通道会再取一张（最多 3 次），
    也可以直接点「刷新二维码」（= 先取消再重新开始）。

---

## 9. 卸载

同样走**桌面端的「插件」页**（`dsh plugin --profile desktop` 会被拒绝，见第 4 节）：
找到 `dsh-taskbar-progress` 删除即可。删依赖但那行 patch 还在时，
就在 `cordis.patch.yml` 里给它加 `disabled: true`，或者删掉那条 `insert` 行。

停用插件时 `ctx.effect` 注册的清理逻辑会调用 `SetProgressState(TBPF_NOPROGRESS)` 把进度条移除，
PowerShell 后端还会主动结束助手进程。浏览器半边（`lib/client.js`）注册的设置页也会随插件一起卸载，
插件页里那一行就不再带「配置」入口。

---

## 10. 文件结构

```
dsh-taskbar-progress/
├── package.json                    # dsh.bundle.patch 指向 cordis.patch.yml；dsh.client 声明浏览器半边
├── cordis.patch.yml                # 挂载声明（insert 一行插件）
├── LICENSE                         # MIT
├── docs/taskbar-states.png         # 五种状态实拍
├── lib/
│   ├── index.js                    # Cordis 插件入口：事件 → 状态机 → 控制器；四种通知的接线都在这里
│   │                               #   （`normalizeConfig` 也在此导出，供配置单测直接调用）
│   ├── status-map.js               # ★ 状态映射表（唯一事实来源，纯数据）
│   ├── machine.js                  # 相位状态机（纯逻辑，不依赖 DSH，可单测）
│   │                               #   v2.1：countWorkingSubagents / isRootAgent / setSubagentBusy
│   ├── taskbar.js                  # 后端选择 + 相位去重下发
│   ├── reminder.js                 # 延迟提醒计时（纯逻辑，定时器可注入）
│   ├── activity.js                 # 桌面活动探测：前台窗口 + 全系统输入空闲
│   ├── notify.js                   # Windows 系统通知（toast）发送
│   ├── wechat.js                   # v2.1 需求 4 新增 / v2.2.0 扩成两条通道：通道选择器（五道闸 /
│   │                               #   文案 / 联动发送 / 独立发送 / 独立控制面 / 二维码渲染）
│   ├── wechat-proto.js             # v2.2.0 新增：iLink Bot API 协议层（头 / 超时 / 三个端点）
│   ├── wechat-standalone.js        # v2.2.0 新增：独立连接状态机（扫码登录 / 验证码 / 发送 / 断开）
│   ├── wechat-store.js             # v2.2.0 新增：独立凭据读写（standalone.json，只读迁移 state.json）
│   ├── config-schema.js            # v2.0 新增：设置界面的 schema（唯一的 @deepseek-ai/* import）
│   ├── client.js                   # v2.0 新增：浏览器半边（设置界面，注册进 plugins.row.config）
│   ├── koffi-resolver.js           # 在 DSH 安装里定位随包发布的 koffi
│   ├── debug-log.js                # 可选的 JSONL 诊断日志（默认关闭）
│   └── backends/
│       ├── window-service.js       # 后端 1：DSH 窗口服务（当前版本通常不可用）
│       ├── win32-koffi.js          # 后端 2：koffi + COM（实际生效）
│       └── powershell.js           # 后端 3：常驻 PowerShell 助手兜底
└── test/
    ├── status-map.test.mjs         # 映射表单测（9 项）
    ├── plugin-state.test.mjs       # 状态机 + 子智能体判据单测（假时钟，44 项）
    ├── reminder.test.mjs           # 延迟提醒单测（假定时器，9 项）
    ├── notify.test.mjs             # 通知载荷单测（不 spawn 进程，5 项）
    ├── activity.test.mjs           # "没在操作 DSH" 判定单测（10 项）
    ├── config.test.mjs             # 配置规整 / volatile 盒子 / 子智能体与微信开关（19 项）
    ├── client.test.mjs             # 浏览器半边结构级回归（假 fetch 驱动四种状态，52 项）
    ├── plugin-wiring.test.mjs      # 事件接线 / 配置 / 四种通知 / 子智能体 / 微信 / 状态+动作路由（75 项）
    ├── wechat.test.mjs             # 微信提醒层 + 独立连接（含对真交付代码的联调，69 项）
    └── backend-smoke.mjs           # 后端实测工具（走真实任务栏）
```

补充两点：

* `lib/client.js` 是**打包好的浏览器半边**（`window.__ModuleLoader__.load({...})` 形态），
  `package.json` 的 `exports["./client"]` 与 `dsh.client` 段负责把它挂进桌面端；
  它内部按 locales / fields / groups / TaskbarCard / controller 几块组织
  （v2.1 的「子智能体工作显示」是 `SUBAGENT_SECTION` + `SubagentSection`，
  父开关关掉时把子开关 `disabled`，并挡住它的 `onChange`；
  需求 4 的「⑤ 微信提醒」是 `WECHAT_SECTION` + `WechatSection`，
  两行各自"开关 + 时长"，并在宿主报 `unavailable` 时把整节锁死 + 显示宿主给的原因），
  页面用 `@deepseek-ai/dsh-client-ui-primitives` 的 `SettingsForm` / `SettingsValueField` / `Switch`
  渲染，**不引入任何自己的前端依赖**；需求 4 里它还用一次同源 `fetch` 问宿主
  「微信联动插件能不能用」（见第 4 节，为什么不是 `host.call`）。
* `lib/config-schema.js` 是**唯一** `import '@deepseek-ai/*'` 的文件，而且是被
  `lib/index.js` 用动态 `import()` 拉起来的 —— 所以它出问题最多只是"没有设置界面"。

---

## 11. 实测记录（本机 DSH 0.2.0-rc.2 / Windows 11）

1. `cordis-inspect` 全量 Service 目录 → **无** window / BrowserWindow 服务。
2. 进程拓扑 → 插件宿主是 `dsh-desktop-host/lib/index.js` 子进程，父进程是 Electron 主进程。
3. 从**另一个进程**对 Electron 窗口调 `ITaskbarList3/4`：
   `HrInit` / `SetProgressValue` / `SetProgressState` 全部 `S_OK`；
   截图比对确认 error→红、normal→强调色、paused→**黄**、indeterminate→滚动、NOPROGRESS→清除；
   且**设置进程退出后状态保持**。
4. 完整接线后在**真实 DSH 宿主**里跑：
   - `apply` → `backend-ready`（`win32-koffi`）→ `resolveWindow HWND=329192` → `setProgress flags=1 hrState=0`；
   - 逐帧量到**滚动片段每帧位置都在变**（`1794..1800` → `1818..1829` → `1798..1812` → `1807..1829`）→ working 生效；
   - 一轮结束时 `api-session/status running=false` + `agent/status idle` → `phase done`，
     抓帧确认进度条变**整宽条**，**30.2 秒后**（`17:59:10` → `17:59:40`）转 `idle` 并清除 → done/idle 生效；
   - 下一轮 `running=true` → `phase working` → working 再次生效。
5. **等待状态**：只监听 `user-questions/request` 的旧版本**完全不亮**（早先几轮交互式问答里
   该事件一条都没送到插件）。改为在 `tools/execute` 上观察 `ask_user_question`
   （工具派发本身必经此处，且比 waterfall 更早），并保留 waterfall 与 `approval/request` 两条路径。
6. `koffi.proto()` 同名二次注册 → 实测抛 `Duplicate type name 'DshTbHrInit'`
   （这就是重载后降级到 PowerShell 的原因）；用 `WeakMap` 缓存类型后，同一进程连续创建两次
   koffi 后端都成功。
7. `link:` 安装 + `import '@deepseek-ai/schemastery'` → 实测 `ERR_MODULE_NOT_FOUND`，
   宿主报 `failed to import`；插件改为零依赖后加载正常。
   （**这是 v1.2.0 的结论**：当时只能"完全不 import"。v2.0 换了做法 ——
   那次 import 变成动态 `import()` + try/catch，解析不到只是没有设置界面，
   进度条与通知照常，见第 4 节与第 31 条。）
8. 单测：映射表 9 项、相位状态机 20 项、接线 18 项，全部通过。

### 重启后的终验（DSH 0.2.0-rc.2 / 宿主 PID 28620 / 窗口 HWND 853464）

9. **新配置被接受**：`apply` 的 `warnings` 为空，`waitingTools` / `reassertMs` / `debugLogFile` 都读到了。
10. **koffi 修复在真实宿主里生效**：重启后首次加载 = `win32-koffi`；
    **热重载（disable → enable）之后仍然是 `win32-koffi`** —— 修复前这一步必然掉成 `powershell`。
11. **启动竞态自愈**：宿主刚起来时窗口还不存在（`resolveWindow → null`），
    之后自动重解析到 `HWND=853464` 并正常下发。
12. **working**：`setProgress flags=1 hrState=0`；与 `NOPROGRESS` 截图逐像素比对，
    按钮底带 x `1794..1824`、y `75..82` 有差异（最大像素差 128），且 10 帧内**偏移质心持续移动**
    （33.8 → 29.4 → 36.6 → 29.0 → 33.4 …）→ 滚动条确实在动。
13. **waiting（本轮修复的重点）**：`ev tools/execute(waiting) tool=ask_user_question` →
    `phase waiting` → `setProgress flags=8 hrState=0`；抓帧显示 **2.4s ~ 44.8s 持续黄色，
    x `1794..1829` 满宽 36px**；用户目视确认「黄色条」。回答后 `settled` → 回落 `working`。
14. **自愈重发**：等待期间每 20s 各重发一次（`10:14:17 / 10:14:37 / 10:14:57`），确认 `reassertMs` 生效。
15. 补充：本次运行里 `user-questions/request` **也**在 `tools/execute` 之后 9ms 到达了，
    所以两条路径同时命中 —— 但正因为它不稳定，仍以 `tools/execute` 为准（见第 5 条）。
16. **done**：跨轮次抓帧（每 0.4s）看到 `working`（短段移动）→ **`done`（整宽条，f060~f098 约 24~39s）**
    → `idle`（收窄回灰点）→ 完成态确实点亮并按保持期清除。
17. **Windows 系统通知**：`Get-StartApps` 查到 DSH 的 AUMID = `com.deepseek.dsh`；
    用**插件自己的 `lib/notify.js`** 真机弹了一次，截图确认来源显示 "DeepSeek Harness"、
    标题「大肥鱼」、正文「老大请您做出决定」，**中文无乱码**。
18. **打包分发**：`pnpm pack` 产出 338.9 KB 的 tgz；在干净目录里 `pnpm add file:<tgz>` 安装成功，
    内容解包进该目录自己的 `node_modules/.pnpm/`；**删掉 tgz 后依旧能 `import` 且单测可跑**。
19. 单测总计：映射表 9 + 状态机 20 + 延迟提醒 9 + 通知载荷 5 + 活动判定 10 + 接线 28 = **81 项全部通过**。

### 超时提醒的终验（重启后 / 宿主 PID 21992 / Electron 17596）

20. 重启后宿主重新加载新代码（koffi 已加载 → 后端仍是 `win32-koffi`）。
    提问后每 0.75s 抓一帧右下角通知区，逐帧结果：
    28.5s 干净 → **30.0s 通知滑入** → **33.8s 完整显示（DeepSeek Harness / 大肥鱼 / 老大请您做出决定）**
    → 45.0s 仍在 → 75.0s 已消失。
    **弹出时刻与 `waitingNotifyDelayMs: 30000` 完全吻合**（当时这个键还叫
    `waitingReminderMs`，v2.0 改名），整段等待**只弹了一次**（没有重复刷屏），
    用户目视确认，中文无乱码。

### 逐相位取色（重启后 / 宿主 PID 2008 / Electron 18540 / 窗口 HWND 67356）

21. 直接给该窗口依次下发 5 个相位并取条区均值（x `1698..1728`、y `76..82`）：

    | 相位 | 条区均值 RGB | 宽度 |
    | --- | --- | --- |
    | `idle`（NOPROGRESS） | `(117, 126, 135)` | 窄（系统灰点） |
    | `working`（INDETERMINATE） | `(73, 77, 86)` | 滚动段 |
    | `waiting`（PAUSED） | `(218, 195, 9)` | 满宽 36px |
    | `error`（ERROR） | `(220, 135, 146)` | 满宽 36px |
    | `done`（NORMAL） | `(160, 174, 183)` | 满宽 36px |

22. **红色实拍确认**：`error` 档在 x `1695..1730`、y `76..80` 呈 `(255,153,164)` 粉红条（截图存档）。
23. **完成态不是绿色**：`normal` 实测为浅钢蓝 `(160,174,183)`，与"绿"无关；
    本机 `ColorPrevalence=0`（任务栏不使用强调色），`AccentColor` 为 `(81,92,107)`。——
    `ITaskbarList` 没有任何颜色参数，"完成=绿色"在原生进度条上做不到。

### 桌面活动探测的真机验证

24. **负例**：探测 DSH 进程（PID 18540）返回 `{foregroundIsDsh:false, idleMs:21422}`
    → 判定"没在操作 DSH" ✓（当时 DSH 不在前台、且 21 秒无键鼠输入）。
25. **正例**：取当前前台窗口所属 PID（10276）再探测，返回 `{foregroundIsDsh:true, idleMs:37750}`
    → 前台判定正确 ✓；同时因 37s 无输入，`isUserEngaged` 仍为 `false`
    —— 正是"DSH 在前台但人已经走开"这一档，会照常提醒。
26. `SetForegroundWindow` 被 Windows 前台锁拒绝（返回 `False`），
    所以正例改用"拿当前前台窗口的 PID 去探"来验证，效果等价。

### v2.0 的回归与新增验证

27. **旧测试一条没坏**：v2.0 改了宿主接线（新增故障/偏离纠正两条通知、配置键改名）之后，
    v1.2.0 那 81 项单测**全部照旧通过**（映射表 9 / 状态机 20 / 延迟提醒 9 /
    通知载荷 5 / 活动判定 10 / 接线 28）。
28. **新增用例后全绿**：接线上新增"故障立即弹且关不掉、连续工作到点提醒、
    中途停止就归零、三组开关各自能关、同一故障不重复刷屏"等用例，接线测试从 28 变成 **36 项**；
    另外多出两套：`test/config.test.mjs`（配置规整 / volatile 盒子，**10 项**）与
    `test/client.test.mjs`（浏览器半边结构级回归，**22 项**）。
    全仓库合计 **121 项**（9 + 20 + 9 + 5 + 10 + 10 + 22 + 36）**全部通过**。本机 `npm test` 实际输出：

    ```
    status-map: 9 项全部通过
    phase machine: 20 项全部通过
    delayed reminder: 9 项全部通过
    toast payload: 5 项全部通过
    desktop activity: 10 项全部通过
    config normalization: 10 项全部通过
    client: 22 项全部通过
    plugin wiring: 36 项全部通过
    ```
29. **配置键改名**：`waitingReminderMs` / `waitingReminderText` 与
    `completionNudgeMs` / `completionNudgeText` 已废弃，改为
    `waitingNotifyDelayMs` / `waitingNotifyText`（+ 新增开关 `waitingNotifyEnabled`）与
    `reviewNotifyDelayMs` / `reviewNotifyText`（+ 新增开关 `reviewNotifyEnabled`）；
    `driftNotify*` 三个键是 v2.0 全新的。旧键名现在会被 `normalizeConfig` 报
    「未知配置项 '…'（已忽略）」并回落默认值 —— 所以**照抄旧文档的配置不会报错，但也不会生效**。
30. **"故障关不掉"由测试钉住**：用例把 `waitingNotifyEnabled` / `reviewNotifyEnabled` /
    `driftNotifyEnabled` / `failureNotifyEnabled` 全部设为 `false`，还塞了
    `failureNotifyText: '不该出现'`，然后制造一次故障 —— 结果**仍恰好弹一条**，
    且正文严格等于 `FAILURE_NOTICE_TEXT`（`故障，请检查`）。也就是说"不可关闭、文案写死"
    不是靠注释约定，而是有断言守着。`test/config.test.mjs` 里还有一条从配置侧钉：
    `normalizeConfig({ failureNotifyText, failureNotifyEnabled })` 出来**根本不含这两个键**。
31. **设置界面的降级路径**：`grep` 全仓库，`import '@deepseek-ai/*'` **只出现在
    `lib/config-schema.js` 一个文件里**，而且只有被 `lib/index.js` 顶部那句
    `await import('./config-schema.js')` 包着 try/catch 时才加载（失败 → `Config = undefined`
    + 一条 warning）。所以"没有 schemastery"最坏的后果就是少一个设置界面。
32. **`notifyAumid` 不在设置界面上**：读 `lib/client.js` 可确认，字段清单（`createSpecs()`）
    与「通用」分组里都**没有** `notifyAumid`，代码注释写明理由是"它不是一个用户可调的值 ——
    必须是已注册的 AppUserModelID，否则 toast 会静默不显示"；宿主侧的
    `lib/config-schema.js` 同样没声明它。所以 AUMID 只能写 profile 的 patch。
33. **打包体积（当前工作树）**：`npm pack --dry-run` 报打包后 `377235 B`（≈368 KiB）、
    解包 `532806 B`、共 27 个条目，其中 `docs/taskbar-states.png` 独占 298 KB。
    增量就是 v2.0 新增的 `lib/client.js`（约 18.1 KB / 491 行）与 `lib/config-schema.js`（约 2.4 KB），
    加上变长的 README 与测试。⚠️ 这是 **npm** 的口径，v1.2.0 记录的 338.9 KB 是 **pnpm pack**
    的口径，两者不宜直接相减；而且当时还没有 `client.js` / `config-schema.js` / `config.test.mjs`。

### v2.0 尚未实测的部分（写在前面，免得被当成已验过）

34. 本节 27~33 条都是**可以在本机复现的**（跑单测、跑 `npm pack --dry-run`、读源码/grep）。
    下面这些**只有代码层面的结论，没有真机记录**：
    * **设置界面在真实桌面端里的渲染与保存流程**（`lib/client.js` 注册进
      `plugins.row.config`、`ctx.configForms` 暂存表单、保存写回 profile patch）——
      本次只做了代码审查，没有在 DSH 桌面端里点过那个「配置」页；
    * **`link:` / 目录安装时那条降级 warning** —— 代码路径清楚（动态 import 失败 → 打 warning），
      但没有真的用 `link:` 装一遍复现；
    * **③ 偏离纠正与 ④ 故障通知在真实宿主里的实际弹出** ——
      行为由单测（假 ctx + 假 toast 发送器）覆盖，真机弹窗截图尚未补。
    上面的"实测记录"标题只覆盖 1~33 条；34 条是**待验证清单**。

### v2.1 的核查与新增验证

35. **v2.0 的 121 项一条没坏**：v2.1 改了状态机（新增 `setSubagentBusy` / `awaitingSubagents`）、
    宿主接线（②的后缀与子选项门控）和浏览器半边（多一块配置区）之后，
    v2.0 那 121 项全部照旧通过；新增用例后合计 **151 项**全部通过
    （需求 4 落地后又涨到 **214 项**，见第 44 条）。
36. **"子智能体影不影响 done"现在是显式配置**：v2.0 的现状是"碰巧不影响"（`scope: 'roots'`
    把子代理的 `agent/status` 整条挡在状态机之外），v2.1 改成由 `subagentDisplayEnabled` 唯一决定，
    两种取值各有断言（`test/plugin-state.test.mjs` 35 项、`test/plugin-wiring.test.mjs` 当时 43 项 /
需求 4 后 59 项）。
37. **需求 1 的后缀"关不掉"由测试钉住**：`test/plugin-wiring.test.mjs` 里配了
    `subagentSuffix` / `subagentSuffixEnabled` / `subagentNoticeSuffixEnabled` 三个根本不存在的键，
    断言它**仍恰好弹一条**且正文以 `（还有 1 个子智能体仍在工作）` 结尾；
    `test/config.test.mjs` 从配置侧再钉一次（`normalizeConfig` 出来不含这些键）。
38. **`test/client.test.mjs` 同步到 12 个字段**（需求 4 后是 **16 个**）：它硬编码了字段清单文本，与
    `lib/config-schema.js` 的声明逐字段交叉比对（读文本、不 import，所以零依赖也能跑）。
    v2.1 补了 `subagentDisplayEnabled` / `subagentDoneNotifyEnabled`，
    需求 4 又补了四个 `wechat*` 键，并保持"关父开关 → 子开关/时长禁用 + 一行提示 +
    禁用态不解发编辑"的断言风格（微信那块是**逐行**适用同一条规则）。
39. **配置热更新的真实链路已用运行时源码验证过**（不是猜的）：见下节"§ 配置到底是不是快照"。

### 需求 3（`reviewNotifyDelayMs` 设了 1500 却等很久）的排查结论

**结论：两条重点怀疑都被证据否掉了；真正的机制是"②只在相位进入 `done` 时才计时"，
而 `done` 什么时候来由当时是否有子智能体在跑决定。** 详见下面两条。

40. **怀疑一（配置热更新是不是快照）——已排除，有证据。**
    用**真实运行时包**跑了一遍 loader 的 volatile 更新路径（脚本复刻了
    `cordis-plugin-loader` 的 `equalExceptVolatile()` 与 `Entry._commitVolatile()`，
    再用插件自己的 `normalizeConfig()` 去读）：

    * `resolveConfig()` 之后，volatile 字段确实是 **cosmokit 的 `Volatile` 盒子**
      （`JSON.stringify` 出来是 `{}`，`typeof` 是 `object`）——不是裸值；
    * 只有 volatile 变了时 `equalExceptVolatile` 判为 true → 走 `_commitVolatile()`，
      **不重载、不重跑 `apply()`**；
    * `_commitVolatile()` 调 `updateVolatile(ref, source)` **就地写入运行中的那个盒子**；
    * 写完立即现取，插件读到的是**新值 1500**（不是 15000）。
      对照组：裸值形态下确实读回旧值 15000 —— 也就是说"快照假说"的症状可以复现，
      但**本机的真实数据流不是那种形态**。

    另外 `cordis_inspect` 的 host `Config` provider 显示本插件的 `patchId` 是 `taskbar-progress`、
    `status: schema`，`reviewNotifyDelayMs` 的默认值 15000 与 `x-cordis.volatile: true` 都在，
    说明 schema 被正常加载（设置界面因此可用）。所以**不需要**再"在 `arm()` 时通过
    `configEditor.configuration()` 现取"——那会引入一个更脆的依赖，而现状已经是实时的。
41. **怀疑二（done 相位被"碰巧"拖住）——v2.0 里不成立，但 v2.1 把它变成显式的。**
    读 `@deepseek-ai/dsh-agent` 的 AgentRegistry 源码确认：`roots()` 就是
    `filter((entry) => entry.owner === void 0)`，而子 agent 是带 `parentAgent` 注册的
    （`loopCtx.agents.enter(agent, parentAgent)`），`list()` 才返回全部。
    于是 v2.0 的 `isTopLevel`（`scope: 'roots'`）**确实**把子代理的 `agent/status` 挡在状态机之外，
    子智能体**从来不会**让相位停在 `working`。也就是说 v2.0 的 `done` 不会被它拖住。

    真正会表现为"等了很久"的是**另一条**：② 只在 `phase === done` 时 `arm()`。
    主任务完成后如果还有子智能体在跑（`run_in_background` 默认 true，父会话可以先回 idle），
    而你又把 v2.1 的开关打开了，那么 `done` 会一直等到子智能体全部结束才出现 ——
    **这不是 bug，正是需求 2 要的行为**，而且现在由 `subagentDisplayEnabled` 显式控制。

    ⚠️ **本条要说清的是边界**：我没有在用户那台机器上复现过"设 1500 等很久"的现场，
    也**没有拿到当时的 `debugLogFile`**（`%USERPROFILE%` 下没有找到插件写的 JSONL）。
    我能确定的是"配置读取路径是实时的"和"v2.0 的相位不会被子智能体拖住"这两件事；
    "当时到底发生了什么"只能给出上面这条最可能的解释。**待验证**。

42. **顺手修掉的两个真 bug**（都是新测试抓出来的，写下来免得再犯）：
    * `completion: 'clear'` 时，子智能体跑完那一刻 `attachDone()` 直接早退，
      相位会**永远卡在 `working`**；现在 `attachDone()` 返回布尔值，早退时调用方回落普通 `recompute()`；
    * 一度写成 `awaitingSubagents = blocksCompletion()` —— 而 `blocksCompletion()`
      的第一个条件就是 `awaitingSubagents`，等于"用自己给自己赋值"，永远是 `false`
      （鸡生蛋）。现在判定"要不要开始等"只看 `subagentBusy && subagentDisplayOn()`。

### v2.1 尚未实测的部分（老实说）

43. 下面这些**只有单测/源码层面的结论，没有真机记录**：
    * **② 正文里的子智能体后缀在真实宿主里真的弹出来** —— 行为由 `test/plugin-wiring.test.mjs`
      （假 ctx + 假 toast 发送器 + 假 agents 注册表）覆盖，真机弹窗截图尚未补；
    * **子智能体工作显示在真实宿主里的相位表现**（真派一个后台子智能体，盯着任务栏看滚动→填满）——
      同样是单测覆盖，没有真机录像；
    * **设置界面里那块「④ 子智能体工作显示」的真实渲染与"父关子灰"交互** ——
      `test/client.test.mjs` 是**结构级**断言（假 React + 假原语），没有在 DSH 桌面端里点过；
    * **③/④ 与 v2.0 遗留的待验证项**（真机弹窗、`link:` 降级 warning）依旧没补。
    上面的"实测记录"标题只覆盖能复现的部分；本条是**待验证清单**。
    （需求 4 落地后总项数从 151 涨到 **214**，见第 44 条；v2.1.1 补第五道闸后是 **220**，见第 49 条；
    v2.1.2 修故障通知刷屏后是 **232**，见第 54 条；v2.1.3 修设置界面状态不刷新后是 **239**，见第 60 条；
    本清单 43 的这几条仍未补验。）

### v2.1 需求 4（微信提醒）的核查与新增验证

44. **v2.1 原有 151 项一条没坏**：需求 4 改了配置 schema（+4 个 volatile 键）、宿主接线
    （+2 个提醒器、+会话跟踪、+只读状态路由）与浏览器半边（+1 块配置区）之后，
    151 项全部照旧通过；新增用例后合计 **214 项**全部通过。本机实际输出：

    ```
    status-map: 9 项全部通过
    phase machine: 35 项全部通过
    delayed reminder: 9 项全部通过
    toast payload: 5 项全部通过
    desktop activity: 10 项全部通过
    config normalization: 19 项全部通过
    plugin wiring: 59 项全部通过
    client: 32 项全部通过
    wechat: 36 项全部通过
    ```

    > 这是 **v2.1 当时**的输出（`wechat` 36 项）。v2.1.1 给 `probe()` 补了第五道闸之后，
    > `wechat` 变成 **42 项**、全套合计 **220 项**，新的实际输出见第 49 条。

45. **`host.call` 走不通、改用宿主只读路由 —— 两条路的结论都有源码证据**（不是"试了一下没成"）：

    * `grep` 整个 `app.asar` 里的 `dsh/`，字符串 `"Package-private JSON RPC"` **只有一处**命中：
      `@deepseek-ai/dsh-cordis-client-runner/lib/client.js:6163`，而它所在的数组是
      `CLIENT_BUILTIN_INSPECTION`，注册给 Client Inspect provider 的名字叫
      **`Builtin`**，描述原文是 *"Plain-JavaScript symbols available to a **dynamic** Client half."*。
      同一文件顶部（第 32-70 行）说明这些符号是"被求值的 async 函数**形参**"
      （`React` / `console` / `styles` / `host`，以及 `fetch`/`setTimeout`/`require` 的教学陷阱）。
      **静态 bundle 不经过这个求值器**：`@deepseek-ai/dsh-client-modules` 的 README 写明
      浏览器半是 `window.__ModuleLoader__.load({...})` 注册的 factory（`factory(require) → exports`）。
    * 整个 `dsh/` 里搜 `provide("host")`：**0 命中**；搜 `get("host")`：1 命中，
      且是 `dsh-client-ui-plugin-manager` 里一个**同名局部变量**，与本议题无关。
      也就是说客户端 Cordis 服务表里**没有** `host` 这个服务可以拿。
    * `ctx.remote.*`（`dsh-api-remotes` 的 `ClientRemote`）是 typert **生成**的类型化 RPC，
      贡献由 `dsh-typert-registry` / `dsh-typert-loader` 装载 —— 本插件是零依赖手写 JS，接不进去。
    * 于是采用第三条：**宿主 `webServer.register()` + 浏览器同源 `fetch`**。
      这条不是我们发明的：`dsh-embedded-browser/lib/routes.js`（`/api/dsh-embedded-browser/*`，
      `kind: 'exact'`、`connection.requestRejection` 守卫）与 `dsh-embedded-browser/lib/client.js:227-237`
      （`fetch(url, { credentials: 'same-origin' })`）是现成的先例；`dsh-wechat-plugin/lib/host.js:2959`
      也注册了 `/.dsh-wechat-plugin` 前缀路由。用 `cordis_inspect` 查本机**运行中的**宿主
      Service 目录，`webServer` 服务在册，方法签名是
      `register(route: WebRoute): () => void`、`WebRoute = { kind: 'exact'|'prefix', path, handler(req,res) }`。

46. **需求 4 的行为由测试钉住**（`test/plugin-wiring.test.mjs` 新增 16 项、
    `test/config.test.mjs` 新增 4 项、`test/client.test.mjs` 新增 7 项）：
    * 默认两个开关都是 `false`，且**关着时连 `probe()` 都不会调**（不浪费五道闸）；
    * 完成后按 `wechatDoneDelayMs` 发、`sessionId`/`kind` 正确，发送前**必须**先问 `isWechatSession`；
    * 拿不到 `sessionId` → 不发，只记一条日志（不猜、不瞎发）；
    * 等待相位 arm、离开相位取消；`wechat*DelayMs = 0` 等于关闭；
    * **两套延迟互不取消**：`reviewNotifyDelayMs = 60` + `wechatDoneDelayMs = 420` 时，
      200ms 处"电脑端已弹、微信还没发"，600ms 处两条各自到齐；
    * 完成后"你在操作 DSH" → 不震手机（复用 ② 的活动探测）；探测失败 → fail-open 照发；
    * 微信会话不回声；插件不可用时不发且**同一原因只提示一次**（连续三段等待只留一行日志）；
    * 插件停用 → 取消计时并 `dispose()` 提醒器；
    * 只读状态路由：注册/注销、`{available, reason}` 应答、非 GET 405、
      有 `connection` 时 401 挡掉、没有 `webServer` 时只记一条 info 且进度条照常。

47. **`client.test.mjs` 里"插件缺失"的门控三种状态都有断言**（这是本任务最难的一点，
    所以专门写清"什么是**没有**验证的"）：
    * 宿主答 `available:false` + `reason` → 两个开关 + 两个时长框全 `disabled`、
      禁用态点击**不产生编辑**、页面原样显示宿主给的那句 `reason`；
    * `fetch` 抛异常 / 返回 401 → 状态 `unknown`，**不置灰、不显示"插件缺失"**；
    * 宿主答 `available:true` → 不显示原因、开关可点。
    断言用的 `fetch` 是**假的**（假 `window.__ModuleLoader__` 世界里的 stub），
    只验证"拿到这三种答复后界面怎么表现"，**不验证真实桌面端里那条请求能不能到达**。

### v2.1 需求 4 尚未实测的部分（老实说）

48. 下面这些**只有单测/源码层面的结论，没有真机记录** —— 上一节 44~47 条是"本机能复现的"，
    本条是**待验证清单**：

    * **微信消息真的发到手机上**：`lib/wechat.js` 的单测全部用**假 `ctx`**
      （假 `wechatChannel` / 假 `tools` / 假 `store`），**没有一次真的调用过 `notify_wechat`**，
      也没有连过真实微信。所以"文案对不对、门控严不严"有断言，**"手机上真的收到"没有**。
      —— v2.1.1 补了一条**真机日志**（第 49 条）：真实宿主里 `notify_wechat` 确实被调用了、
      也确实被插件拒发了（`tool-error`），但**"成功送达手机"依然没有被真机验证过**。
    * **真实宿主里 `sessionId` 取哪一个**：`api-session/status` 的第一个参数是 `sessionId` 这点
      来自事件签名；`agent/status` 的 `payload.agent.id` 与之同值是**本插件从 v2.0 起就有的用法**
      （`machine.setRunning` 把两者当同一个 id 空间用），**没有在真实宿主里打印比对过两个值**。
      万一它们不等值，插件的选择是"优先 api 的"，这是刻意的保守选择。
    * **设置界面那条 HTTP 路由在桌面端里真的通**：桌面端的渲染进程是不是由宿主 web 载体
      服务（而不是自定义 scheme / `file://`）**没有验证**。这一条决定了"整节置灰"能否生效；
      若不通，行为退化为"界面照常显示 4 个字段、感知不到插件缺失"，
      而**宿主侧的拦截不受影响**（三道门 + `wechat.js` 的五道闸仍然严格生效）。
      这不是"假装能探测的 UI"：探测不到时界面**不会**显示任何"插件缺失"的结论。
    * **`webServer.register` 与 GUI 守卫的实际配合**：`connection.requestRejection` 的分支由单测
      用假 `connection` 覆盖；真实请求带不带得上 cookie、会不会被判 401/403 没实测。
    * **"微信窗口关着时消息排队延后"与"多绑定拒发"**：这两条来自 `dsh-wechat-plugin` 自己的
      行为（其工具返回的错误文案里就写着"当前绑定了 N 个微信对话，无法确定发给哪一个"），
      本插件只是把失败记进日志、**不重试**；我们没有构造过这两种现场。
    * **③/④ 与 v2.0 遗留的待验证项**（真机弹窗、`link:` 降级 warning）依旧没补。

### v2.1.1 的真机证据（微信手机提醒静默失败 → 补上第五道闸）

49. **真机日志（下面两行是用户机器上 `debugLogFile` 里的原文，不是单测、不是模拟）**：
    第一行是宿主 `probe()` 当时的结论 —— **`available: true`**；第二行是随后**真实发送**的结果 ——
    插件把 `notify_wechat` 拒了：

    ```json
    {"event":"wechat:probe","available":true,"reason":""}
    {"event":"wechat:send-error","stage":"tool-error","kind":"done","detail":"还没有微信对话。请先在微信里给机器人发一条消息"}
    ```

    现场同时确认：`~/.dsh/wechat/state.json` 里 `accounts` 有一个已登录账号，
    而 **`bindings` 是 `{}`（空的）**。

    这正是第五道闸要堵的洞：`wechatChannel` 在、`notify_wechat` 在、跨会话通知开着、账号也连着 ——
    老版本的四道闸**全部通过**，于是设置界面显示"可用"、用户把开关打开，
    可 `notify_wechat` 找不到任何已绑定的对话 → 拒发 → **静默失败**（只有翻日志才知道）。
    v2.1.1 在账号闸**之后**补上 `bindings()` 非空这一道：这种情况现在会直接在界面上说
    `微信里还没有对话，请先用手机给机器人发一条消息`；读绑定出错 / 形状不对 / 插件版本过旧则说
    `读取微信会话绑定失败`。

    这条证据的**边界**（免得被当成已验过）：它证明"真实宿主里确实会走到发送、也确实会被插件拒发"，
    **不证明**"消息成功送达手机" —— 后者仍然没有真机验证（见第 48 条）。

50. **v2.1.1 的全套输出（本机实际运行，runtime node v24.21.0）**：补第五道闸 + 6 项新用例之后，
    原有 214 项一条没坏，合计 **220 项**：

    ```
    status-map: 9 项全部通过
    phase machine: 35 项全部通过
    delayed reminder: 9 项全部通过
    toast payload: 5 项全部通过
    desktop activity: 10 项全部通过
    config normalization: 19 项全部通过
    plugin wiring: 59 项全部通过
    client: 32 项全部通过
    wechat: 42 项全部通过
    ```

    `test/wechat.test.mjs` 新增的 6 项：有绑定 → `available: true`；`bindings: []` → 不可用且是
    "先用手机给机器人发一条消息"；`bindings()` 抛异常 / 返回非数组 / 方法缺失 → 不可用且是
    "读取微信会话绑定失败"（两条文案**分开**断言）；**账号闸优先**（账号没连时不读绑定，
    reason 仍是"微信插件未连接账号"，`bindings` 调用次数为 0）；第五道闸的结论同样进 30 秒缓存
    （连探两次只读一次 `bindings`）。

51. **v2.1.1 只改这一处**：`lib/wechat.js` 的 `probeUncached()` 里新增第五道闸
    （外加三处"四道闸 → 五道闸"的注释）、`test/wechat.test.mjs`（夹具默认形态 + 6 项新用例）、
    README 与 `package.json`（`2.1.0 → 2.1.1`）。
    `sendTaskNotice()` 里那句 `isWechatSession` 排除逻辑**没有动**；
    `lib/index.js` / `lib/client.js` / `lib/config-schema.js` 的**行为逻辑**一行没动
    （这几个文件里还有几处注释写着"四道闸"，属于描述性文字，按"不动这三个文件"的约定本次未改）。

### v2.1.2 的真机证据（故障提醒每 60 秒刷一条）

52. **真机证据（证据来源：Windows 通知中心的历史记录，不是单测、不是日志推断）**：
    用户机器上 DSH 的 toast **共 70 条，其中约 60 条是「故障，请检查」**（其余是「老大请验收」），
    而且**成簇出现**：先 4 条，随后连续几十条。**这就是 v2.1.2 的修改动机。**

    对着代码能把机制逐行还原出来：老逻辑把 ④ 挂在 `onPhase` 的"相位变成 error"上，
    而 `lib/machine.js` 的 `expireErrors()` 在 `errorHoldMs`（默认 60 秒）到期时
    **把内容签名 `errorSignature` 一起清掉**，于是**同一个会话只要停在故障态**，
    粘性错误每 60 秒就会被重新当成"新故障"：红条复亮一次（`changed === true`）+ 再发一条通知。
    这与"成簇 + 数量级"完全吻合。修复见 `lib/machine.js` 的 `failureAnnounced` /
    `consumeFailureAnnouncement()` 与 `lib/index.js` 的 `announceFailure()`：
    通知改成**按会话记账的事件型**，消退**只灭灯、不还提醒配额**。

    **这条证据的边界**（免得被当成已验过）：
    * 它证明"通知中心里确实堆了这么多条、而且形状是成簇的"，**不精确**到这 60 条里每一条
      都出自 60 秒刷屏这一条路径；
    * 另一条会往通知中心里塞「故障，请检查」的路径是**反复跑本仓库的单测**（见第 53 条），
      `plugin-wiring.test.mjs` 修复前每跑一次会真的弹 1 条 —— 也一并修掉了；
    * "会话停在故障态 → 每分钟一条"是本仓库里唯一能解释成簇刷屏的机制，且它在代码里可逐行验证，
      但**没有**在真机上做过"计时 60 秒观察是否只弹一条"的现场复现 —— 那台机器上的 70 条是历史记录，
      事后无法回放。

53. **v2.1.2 的变异验证（证明"60 秒消退后不再重复通知"这条被测试真正锁住）**：
    把改动**还原成旧逻辑**跑新用例，两处都如期变红（用"不抛错、只记账"的临时 harness 一次跑完全部用例）：

    | 变异（还原成旧逻辑） | 变红的用例 | 断言原文 |
    | --- | --- | --- |
    | A：`expireErrors()` 里连 `failureAnnounced` 一起清（= 老的"消退时连签名一起清"） | `plugin-state` 2 项 + `plugin-wiring` 1 项 | `5 轮消退/复亮只该提醒 1 条，实际 5 条`；`消退后复亮不得再弹（老逻辑这里会弹第 2 条），实际 2` |
    | B：把 ④ 挪回 `onPhase` 的"相位变成 error 就发" | `plugin-wiring` 2 项 | `每个会话各提醒一次：第二个会话也该弹`（实际 0）；`消退后复亮不得再弹…实际 2` |

    也就是说：**A 正是这次 bug 的 60 秒路径**（旧逻辑下一轮消退就多弹一条），
    **B 是"相位跳变"判据的两个方向**（既漏第二个会话、又在消退复亮时多弹）。
    改回正确实现后，九个文件全绿（第 54 条）。

54. **v2.1.2 的全套输出（本机实际运行，runtime node v24.21.0）**：原有 **220 项一条没坏**，
    新增 12 项（`plugin-state` 9 项 + `plugin-wiring` 3 项），合计 **232 项**：

    ```
    status-map: 9 项全部通过
    phase machine: 44 项全部通过
    delayed reminder: 9 项全部通过
    toast payload: 5 项全部通过
    desktop activity: 10 项全部通过
    config normalization: 19 项全部通过
    plugin wiring: 62 项全部通过
    client: 32 项全部通过
    wechat: 42 项全部通过
    ```

    新增用例（全部是真断言，没有一条是"跑过就算"）：
    `同一会话连续报错多次 → 只提醒一条`；`会话重新开跑后再次出错 → 再提醒一条`；
    `两个不同会话各自报错 → 各提醒一条`（并断言此刻 `phases.length === 0`，
    即相位回调**根本没发生**，所以通知不可能再挂在相位上）；
    `errorHoldMs 消退 → 相位离开 error 又重新进入 → 不再重复提醒`（回归保护）；
    `连续 5 轮「消退 → 复亮」也只提醒一条`（真机 60 条刷屏的模型）；
    `idle 不算"恢复正常"`；`轮询观察到 idle→running 翻转也算恢复正常`；
    `forgetSession 也清记账`；`子代理既不点灯也不提醒`；
    以及端到端三条（真定时器、真事件、假发送器）。

55. **v2.1.2 顺带修掉的一处"测试自己弹真通知"**：实测（临时给 `lib/notify.js` 的 `showToast`
    加一行探针、跑完即撤）发现 `plugin-wiring.test.mjs` 修复前**每跑一次会真的弹 1 条**
    「故障，请检查」—— 因为主场景（`api-session/error` → ④）在 `setToastTransport()`
    装上假发送器**之前**就跑了。所以把假发送器移到文件开头（第一次 `apply()` 之前），
    改完再测：**真实 `showToast` 调用次数 0**，62 项照旧全过。
    这条**只改了测试文件**，`lib/` 一行没动 —— 但它和 52 条是同一类"用户被故障通知刷屏"的来源，
    所以一并记在这里。

56. **v2.1.2 改动的文件**：`lib/machine.js`（新增 `failureAnnounced` 记账 +
    `consumeFailureAnnouncement()`；恢复点接在 `setRunning(id,true)` / `forgetSession` /
    `reconcileRunning` 的 idle→running 翻转上；`expireErrors()` **只灭灯**）、
    `lib/index.js`（新增 `announceFailure()` 出口，把 ④ 从 `onPhase` 挪到两条故障事件上）、
    `test/plugin-state.test.mjs`（+9）、`test/plugin-wiring.test.mjs`（+3，并把假发送器提前）、
    `README.md`、`package.json`（`2.1.1 → 2.1.2`）。
    **`lib/wechat.js` / `lib/client.js` / `lib/config-schema.js` 一行没动**；
    文案 `FAILURE_NOTICE_TEXT`、不可关闭、不进 schema、界面无选项**都没动**；
    红条按 `errorHoldMs` 消退的视觉行为**没动**。

### v2.1.3 的真机证据（设置界面永远停在"页面加载那一刻"）

57. **真机时间线（证据来源：用户机器上 `debugLogFile` 的原文，不是单测、不是推断）**：

    ```
    20:43:07  宿主重启（v2.1.1/2.1.2 生效）
    20:43:17  wechat:probe  available=False reason=微信里还没有对话，请先用手机给机器人发一条消息
    20:43:17  wechat-route  available=False reason=…
    21:01:35  wechat-session sessionId=session-bb71ed4f-…   ← 用户这时才发消息、绑定才建立
    ```

    而 `~/.dsh/wechat/state.json` 在事后查的时候**确实有绑定**
    （`session-bb71ed4f-bb71ed4f-a7f2-4a79-85ad-1a87a99e5d22`，标题「微信 bb71ed4f」）。
    也就是说：**21:01 之后宿主自己也知道"微信可用"，可设置界面还一直显示 20:43 那次的结论**
    —— 用户明明已经连上微信，看到的却是「未检测到可用的微信联动插件」。**这就是本次修改的动机。**

    对着代码能逐行还原出两条叠加的原因（不是猜的）：

    * **客户端只在构造时 `fetch` 一次**：`TaskbarCardController` 的构造发生在"插件行注册 /
      页面外壳加载"那一刻，之后就再不会重问（`grep 'invalidate|refresh' lib/client.js` 当时 **0 命中**）；
    * **宿主 `probe()` 有 30 秒缓存**（可用/不可用都缓存）：即便客户端再问一次，
      也可能拿到最长 30 秒前的旧结论。

    这条证据的**边界**（免得被当成已验过）：它证明"宿主 20:43 探到不可用、21:01 绑定才建立，
    而界面一直显示 20:43 的结论"这一串因果；**不证明**修复后的界面在真机上已经点过
    （见第 60 条：真机点按仍未验证），也**不证明**那条提醒消息已经成功送达手机。

58. **v2.1.3 改动的文件**（**没有 commit、没有打包**）：

    | 文件 | 改了什么 |
    | --- | --- |
    | `lib/client.js` | 新增 `require("react")` 并加一个 `useEffect`（`deps` 只有 `view`）：`view === 'page'` 时重新探测一次；微信那一节内新增「重新检测」按钮（走 `primitives.Button`）+ 说明文案；`checkWechat({ force })` 支持 `?refresh=1`；新增 `checking` 标志与 `checkSeq` 序号（只让最新一次答案落地）；`inject()` 多出 `recheckWechat` 把手 |
    | `lib/index.js` | 新增导出 `WECHAT_REFRESH_PARAM = 'refresh'` 与 `isRefreshRequest(req)`（用 `new URL` 解析，不用 `includes` 猜）；路由命中强刷时**先 `invalidate()` 再 `probe()`**，不带参数保持原样（走缓存）；诊断日志多一个 `refresh` 字段 |
    | `test/client.test.mjs` | 假世界补 `react` 的 `useEffect` 替身（真 React 的 deps/槽位语义）与 `Button` 原语替身；+5 项新用例；注入面 key 断言加 `recheckWechat`（32 → 37） |
    | `test/plugin-wiring.test.mjs` | 假提醒器开始记录**调用顺序**（`calls.order`）+ 2 项新用例（62 → 64） |
    | `README.md` / `package.json` | 本节与设置界面那一节；`2.1.2 → 2.1.3` |

    **`lib/wechat.js` 一行没动**（五道闸语义不变）、`lib/config-schema.js` 一行没动
    （重新检测不是配置项）、④ 故障提醒的事件型语义没动、宿主侧"发送前自己 probe 一次"
    的**权威拦截**也没动 —— 界面显示可用/不可用只影响"能不能在界面上开这个功能"。

59. **v2.1.3 的变异验证（证明新用例真的锁住了这次修复，不是"跑过就算"）**：
    每次把改动**还原成旧行为**跑用例，都在**预期的那一条**上变红（改回正确实现后 9 个文件全绿，见第 60 条）：

    | 变异（还原成旧行为） | 变红的用例 | 断言原文（实际输出） |
    | --- | --- | --- |
    | **M1**：客户端删掉打开页面时的那次重新探测（=修复前"只在构造时 fetch 一次"） | `client` 1 项 | `AssertionError: 打开配置页必须重新探测一次`，`1 !== 2`（fetch 调用数） |
    | **M2**：按钮忘了带强刷参数（`recheck({ force: false })`） | `client` 1 项 | `AssertionError: 「重新检测」必须带强刷参数…`，`actual '/api/dsh-taskbar-progress/wechat'` ≠ `expected '/api/dsh-taskbar-progress/wechat?refresh=1'` |
    | **M3**：宿主路由收到强刷参数却忘了 `invalidate()` | `plugin-wiring` 1 项 | `AssertionError: 强刷必须是"先作废缓存、再探测"这个顺序`，`actual ['probe']` ≠ `expected ['invalidate','probe']` |

    **M1 就是这次的 bug 本身**（界面状态停在页面加载那一刻）；M2 保证"强刷"这个动作没有
    悄悄退化成普通请求；M3 保证宿主那一侧的缓存真的被绕开。三次变异都只用临时改动 + 跑测试，
    验证完立刻还原，并用 SHA-256 核对过两个源文件与变异前**逐字节一致**
    （`lib/client.js` `bf2688c2…05ce`、`lib/index.js` `52783a17…e452`）。

60. **v2.1.3 的全套输出（本机实际运行，runtime node v24.21.0）**：原有 **232 项一条没坏**，
    新增 7 项（`client` 5 项 + `plugin-wiring` 2 项），合计 **239 项**：

    ```
    status-map: 9 项全部通过
    phase machine: 44 项全部通过
    delayed reminder: 9 项全部通过
    toast payload: 5 项全部通过
    desktop activity: 10 项全部通过
    config normalization: 19 项全部通过
    plugin wiring: 64 项全部通过
    client: 37 项全部通过
    wechat: 42 项全部通过
    ```

    **v2.1.3 尚未实测的部分（老实说）**：

    * 客户端那半边仍然是**结构级**断言（假 React + 假原语 + 假 `fetch`）：
      假 `useEffect` 是**同步排空**的（真 React 的 passive effect 在提交之后异步跑），
      假 `Button` 只是记录 props。所以"真机上点一下这个按钮、界面真的从灰变亮"
      **没有**在桌面端里点过；
    * "打开页面时那次重新探测"的时机依赖 `view === 'page'` 这个 prop ——
      这是从插件页 slot 契约读出来的，**没有**在真机上确认过页面何时切到 `page` 视图；
    * `require("react")` 是**读源码**确认可行（`dsh-web-frontend` 的启动种子
      `staticModules` 里有 `react` / `react/jsx-runtime` / `react-dom`，
      第一方 bundle 也这么 require），**没有**在真机客户端控制台里验过本插件的加载；
    * 宿主那一侧的强刷顺序与 `refresh=0` 的边界由假提醒器断言，**不是**真机抓包。

---

### v2.2.0：核查、联调与变异验证（本次新增，全部在本机实际跑过）

61. **v2.2.0 的全套输出（本机实际运行，runtime node v24.21.0）**：v2.1.3 的 239 项**一条没坏**，
    新增 53 项（`wechat` 27 项 + `client` 15 项 + `plugin-wiring` 11 项），合计 **292 项**：

    ```
    status-map: 9 项全部通过
    phase machine: 44 项全部通过
    delayed reminder: 9 项全部通过
    toast payload: 5 项全部通过
    desktop activity: 10 项全部通过
    config normalization: 19 项全部通过
    plugin wiring: 75 项全部通过
    client: 52 项全部通过
    wechat: 69 项全部通过
    ```

62. **二维码的真实格式：实测，不是猜的。** 写了个只读探针（`local_token_list: []`，
    不带任何凭据、不写任何本地状态）直接调 `fetchQRCode`，拿到：

    ```
    keys: [ 'qrcode', 'qrcode_img_content', 'ret' ]
    qrcode             = 957c551a7c95957e8434ddc183e95f70        (32 字符)
    qrcode_img_content = https://liteapp.weixin.qq.com/q/7GiQu1?qrcode=957c…&bot_type=3
    ```

    结论：`qrcode_img_content` 是一段**纯文本 URL**（既不是 data URL、也不是图片地址），
    必须被**编码成二维码**。据此选的渲染方式：宿主用 profile 里已 hoisted 的 `qrcode`
    做 `toDataURL(payload, {width:320, margin:2})` → `data:image/png;base64,…`（实测 4226 字节），
    界面直接 `<img src>`。**解析不到就回 `null`**，界面降级显示原始 payload + TODO 标注。

63. **联调（对着对方真交付的三个模块跑，不联网）**：`test/wechat.test.mjs` 末尾 5 项走的是
    **真实默认加载路径**（动态 import `wechat-standalone.js` + `wechat-store.js`）+ 真协议实现，
    只把 `fetchImpl` / `sleep` / store 的目录换成假的 / 临时的。验证到的事：
    工厂名与参数名对得上（**交付方导出的其实是 `createWechatStore`，不是契约里写的 `createStore`** ——
    本插件的加载器两个名字都认）、`startLogin()` 真的停在 `awaiting-scan` 且 `qrContent` 就是服务端给的 URL、
    扫码确认后进 `connected` 并把凭据写进 `standalone.json`、
    **发出去的正文与需求逐字一致**（`您在任务栏进度条对话中的任务 已完成，请及时处理。` /
    `… 等待选择，请及时处理。`，并逐字符校验 U+0020 / U+FF0C / U+3002）、
    断开只删自己的文件而共享 `state.json` 一个字节不变。

    **联调当场逮到两个"单测全绿也照样是坏的"问题**（都已修 + 补了回归用例）：

    * **① `startLogin()` 会 await 整条登录流程。** 交付代码的 `startLogin()` 是
      "扫码成功 / 失败 / 5 分钟超时" 才 settle 的。本插件最初 `await` 它 ——
      于是设置界面点完「连接微信」那个 `fetch` 会**一直挂着**，二维码永远显示不出来
      （界面只会一直显示"连接中…"）。改成**把登录挂起来、只等相位离开 `connecting`**
      （最多 `DEFAULT_LOGIN_KICK_WAIT_MS = 2.5s`），拿到二维码立刻返回。
    * **②「刷新二维码」会撞上还在收尾的旧登录。** `cancelLogin()` 到旧 Promise 的 `finally`
      之间隔着一个事件循环，这期间再调 `startLogin()` 会拿到 `{pending:true}`
      （通道拒绝起第二条轮询）—— 界面上就是"点了刷新没反应"。
      改成拿到 `pending` 后退让 150ms 再踢一次。

    另外在 `plugin-wiring.test.mjs` 里补了一条**跨层端到端**用例：真 `apply()` 的动作路由 →
    真 `createWechatNotifier` → 真独立通道 → 假服务端（store 指临时目录）。
    它断言 `POST /login` 的响应里直接带着 `awaiting-scan` + 二维码内容（界面不必再问一次），
    以及 `POST /disconnect` 之后本插件的凭据文件真的没了。

64. **变异验证（证明新测试真的会红）**：四处关键行为各改坏一次、跑测试、**立刻还原**
    （四次都只做临时改动，还原后 `node --check` + 全量测试再次全绿）：

    | 变异（还原成旧行为） | 变红的用例 | 断言原文（实际输出） |
    | --- | --- | --- |
    | **M1**：联动可用时**仍然**渲染独立连接块（`WechatSection` 里 `if (standaloneMode)` → `if (standaloneMode \|\| linkedMode)`） | `client` | `AssertionError: 联动可用时不该出现「连接微信」按钮` |
    | **M2**：`probe()` 在联动可用时**也去构造**独立通道（废掉 `if (linked.available === true) return …` 那一支） | `wechat` | 首个失败是前面那条既有用例 `五道闸全过 → available: true 且 reason 为空串`（`false !== true`）；我瞄准的新断言 `"有联动插件就委托它"：不许偷偷建第二条连接` 排在文件更后面，被前一个失败挡住了 —— 两者失败的原因是同一个（`probe()` 走错了分支） |
    | **M3**：动作路由把 `lastError` 丢掉（`toWireState` 不透传） | `plugin-wiring` | `AssertionError: 宿主侧异步发生的发送失败只能靠这个字段让界面看见`（`''` ≠ `'微信回信窗口已关闭…'`） |
    | **M4**：`/verify` 把请求 body 也打进诊断日志 | `plugin-wiring` | `AssertionError: 日志里不许出现验证码`（真读 `debugLogFile` 落盘的内容） |

    **M3 第一次跑的时候是"绿的"** —— 也就是说那条"最近一次发送失败要透传给界面"的行为
    **当时根本没有测试保护**（假提醒器不返回 `lastError`，透传与丢掉的结果都是 `''`）。
    于是补了一条专门的用例（假提醒器可配置 `lastError`，断言状态路由原样带回），
    再跑 M3 才变红。**这一条比任何"全绿"都更能说明变异验证的意义**：
    它把"我以为测到了"和"真的测到了"分开了。

    **M1 保的是需求的硬约束**（联动可用时不许出现第二个连接入口）；
    **M2** 保的是"有联动就绝不建独立"这条选择规则；**M3/M4** 保的是"错误要看得见、凭据不许进日志"。

65. **v2.2.0 尚未实测的部分（老实说）**：

    * **真机上没点过一次**：桌面端里点「连接微信」、看到二维码、手机上真的扫一次、
      输验证码、断开、重连 —— 这一整条流程**没有**在真实 DSH 桌面端里走过一遍。
      联调用的是假服务端（只认三个端点）+ 临时目录，所以"协议对不对"验过，
      "在真宿主里点起来是什么样"**没验过**；
    * **独立连接真的发到手机上**这件事**没有**端到端验过（同样因为联调是假服务端）。
      已经验到的是"请求内容与需求逐字一致、且确实发出去了"；
    * **`-14` 的实际触发条件**没有在真机上复现过（"还没给机器人发消息"那种现场），
      代码里的处理是读协议 + 读联动插件的实现得出的；
    * 路由的**动作请求**由假 `webServer` + 手搓 req/res 驱动，**不是**真机抓包；
      `connection.requestRejection` 那道守卫在动作路由上的行为同样是假服务。
    * 二维码渲染在**真机上**用的是 profile 里 hoisted 的 `qrcode`（本机实测可解析），
      但"安装到别的机器上时那个包一定在"**不敢保证** —— 它本来只是
      `dsh-wechat-plugin` 的依赖，所以代码里写的是"拿不到就降级显示原始 payload"。

---

### v2.2.1：真机联调抓到的"微信独立连接拿不到二维码"（本次新增，证据与改动都在这儿）

66. **真机证据（2026-10-13，本机实测，不是推断）**：对
    `POST https://ilinkai.weixin.qq.com/ilink/bot/get_bot_qrcode?bot_type=3`，
    body 是 `{"local_token_list":[…]}`，四种内容四种结果：

    | `local_token_list` 内容 | 服务端回复 |
    | --- | --- |
    | 空数组 | ✅ `{"qrcode":"b836…","qrcode_img_content":"https://liteapp.weixin.qq.com/q/…","ret":0}` |
    | 只放真实 **token** | ✅ 正常返回（同上） |
    | 只放 **accountId**（如 `c3259b90b378@im.bot`） | ❌ `{"err_msg":"batch verify bot token fail","ret":-3}` |
    | token + accountId（2 条） | ❌ 同样失败 `{"err_msg":"batch verify bot token fail","ret":-3}` |

    **结论：这个字段只认 token，混入任何非 token（尤其 accountId）会让整批校验失败。**

    用户在设置界面看到的原话是：

    ```
    最近一次错误：获取二维码失败：获取二维码失败：服务端未返回 qrcode
    ```

    这一句话里藏着**两个** bug：① 列表里混进了共享 `state.json` 的 accountId
    （v2.2.0 的 `collectLocalTokens()` 写的是"自己的 token → 共享 token → 共享 accountId"），
    服务端因此回 `ret:-3`；② `fetchQRCode()` 只看 `qrcode` 字段、**把服务端的 `ret`/`err_msg` 吞掉**，
    换成我们自己猜的"服务端未返回 qrcode"，并且前缀被**包了两层**（协议层一层 + 状态机一层）。
    结果就是：真正的原因（`batch verify bot token fail`）一个字都没露出来，排障只能抓包。

67. **改了什么（三件事，顺序不能反）**：

    * **① 只放 token**（`lib/wechat-standalone.js` 的 `collectLocalTokens()`）：
      列表只收"自己文件里的 token + 共享 `state.json` 里的 token"，accountId 一律不进；
      函数注释里贴了上面那张真机表（讲清**为什么**）。
      `lib/wechat-store.js` 的 `sharedAccountIds()` 因为**只被这个错误逻辑用着**，
      **已删除**（连带它的具名导出与 `status()` 无关部分）；测试里留了个"诱饵"
      （假 store 仍实现该方法 + 计数器），断言它**一次都不许被调用**。
    * **② 错误要看得见**（`lib/wechat-proto.js`）：
      `fetchQRCode()` 先看 `errcode ?? ret`，非 0 就抛
      `获取二维码失败：服务端返回 ret=-3 err_msg=batch verify bot token fail`
      （错误上挂 `errcode` / `errmsg` / `tokenRejected`）；
      只有在**既没有错误码、也没有 qrcode** 时才说"服务端未返回 qrcode"，
      而且**必须**把截断后的原始响应体带上。`pollQRStatus()` 缺 `status` 时同样带
      `ret`/`err_msg`/响应体（带着 `status` 的响应**照旧放行**：长轮询路径的
      `errcode` 另有含义 —— `-14` 是 token 失效 —— 在这里加错误码判据会把登录流程改坏）；
      `sendText()` 的错误文案也改成 `err_msg`（下划线）和 `errmsg` 都认，
      服务端一个字都没给时才退化成截断的响应体。
      **双层前缀**由 `lib/wechat-standalone.js` 的 `withActionPrefix()` 修掉：
      已经以 `获取二维码失败：` 开头就不再补一遍。

      前后对比（同一现场）：

      | | 文案 |
      | --- | --- |
      | 修前（真机原话） | `获取二维码失败：获取二维码失败：服务端未返回 qrcode` |
      | 修后（同样的失败） | `获取二维码失败：服务端返回 ret=-3 err_msg=batch verify bot token fail` |

    * **③ 失效 token 的兜底**（`lib/wechat-standalone.js` 的 `runLogin()`）：
      **先正确**（只放 token）→ 失败且是 `ret:-3`（`isTokenRejected()`）且**确实带了 token**
      时，**自动用空列表重试一次**；这一轮一旦降级，后续刷新二维码也直接走空列表
      （再带上只会又失败一遍），`state.tokenFallback` 置真。
      降级留痕：`debug('wechat-standalone', { event: 'qr-token-fallback', knownTokens, ret, errmsg })`
      + `log('info', '…本次改用空 token 列表重新取二维码；扫码后可能需要重新绑定。')`
      —— **只记"带了几个 token"和服务端的 `ret`/`err_msg`，绝不记 token 本身**。
      空列表也失败才判失败并显示错误。
      "旧绑定没能复用"这件事一路上浮到界面：`status().tokenFallback`
      → `lib/wechat.js` 的 `standaloneSnapshot()`（快照从九个字段变十个）
      → 状态路由 body 的 `standalone.tokenFallback`（`plugin-wiring` 有用例钉住）。

68. **v2.2.1 的全套输出（本机实际运行，runtime node v24.21.0）**：
    v2.2.0 的 389 项一条没坏，新增 11 项，合计 **400 项**：

    ```
    status-map: 9 项全部通过
    phase machine: 44 项全部通过
    delayed reminder: 9 项全部通过
    toast payload: 5 项全部通过
    desktop activity: 10 项全部通过
    config normalization: 19 项全部通过
    wechat: 69 项全部通过
    wechat-proto: 41 项全部通过
    wechat-standalone: 67 项全部通过
    client: 52 项全部通过
    plugin wiring: 75 项全部通过
    ```

    （v2.2.0 那次 README 只列了九个文件、总计 292 项 —— 因为 `wechat-proto` / `wechat-standalone`
    这两个新文件当时**没算进那个总数**，389 = 292 + 34 + 63。本次一并补齐。）

69. **变异验证（证明新测试真的会红）**：三处各改坏一次、跑测试、**立刻还原**
    （还原后 `node --check` + 全量 400 项再次全绿）：

    | 变异（还原成旧行为） | 变红的用例 | 断言原文（实际输出） |
    | --- | --- | --- |
    | **M1**：`collectLocalTokens()` 重新把 `store.sharedAccountIds()` 混进列表 | `wechat-standalone` | `AssertionError: ⚠️ accountId 绝不能进这个列表（本次真机 bug 的成因）`（`true !== false`） |
    | **M2**：`withActionPrefix()` 永远再加一遍前缀（v2.2.0 的双层包裹） | `wechat-standalone` | `AssertionError: 前缀只该出现一次：获取二维码失败：获取二维码失败：服务端返回 ret=-3 err_msg=batch verify bot token fail`（`2 !== 1`） |
    | **M3**：取消空列表兜底（`ret:-3` 直接判失败） | `wechat-standalone` | `AssertionError: 第一次带 token 失败、第二次空列表：**只重试一次**`（`1 !== 2`） |

    **M2 的报错原文就是真机上用户看到的那句话**（只是把末尾换成了真正的服务端原因）——
    这正好说明"双层前缀"和"吞掉 err_msg"是**同一个现场的两个症状**。

    M1 还另外用一个一次性探针（跑完即删）验了**行为层面**的后果：把 accountId 混回列表、
    用"照真机行为"的假服务端（只认 token，混进非 token 就回 `ret:-3`）驱动真实现，
    得到 ——

    ```
    qrLists: [["tk-shared","acct-shared"], []]        ← 第一次被整批拒绝，兜底又发了一次
    tokenFallback: true
    logs: ["info: 微信独立连接：旧的登录凭据已失效（服务端拒绝复用），本次改用空 token 列表重新取二维码；扫码后可能需要重新绑定。"]
    ```

    也就是说：**兜底会把 M1 这个 bug 掩盖成"能出码但旧绑定没了"**。所以"列表里只有 token"
    这条必须由测试**直接钉住列表内容**，不能只看"登录成没成功" —— 这正是本次回归保护的重点。

70. **v2.2.1 尚未实测的部分（老实说）**：

    * 这次修的是"取码请求组装 + 错误文案 + 兜底"这三件事，
      **真机上重扫一次二维码把整条流程走通**这件事仍然**没有**在桌面端里点过
      （真机证据是直接对服务端发请求拿到的，四条响应都是实测）；
    * **旧 token 失效 → `ret:-3`** 这个现场是用假服务端（照真机语义）构造的，
      没有真的等到某台机器上的 token 过期；
    * `pollQRStatus()` 那条改动只覆盖"缺 status"，**长轮询路径真实的错误响应形状**没有实测过，
      所以那里刻意**没有**加"错误码非 0 就判错"的判据（怕改坏 `-14` 的语义）；
    * `tokenFallback` 只做到"透传到界面可用"，**设置界面没有为它加一句专门的人话提示**
      （本次刻意不动与 bug 无关的界面文案）。



